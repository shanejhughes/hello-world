REM %windir%\System32\cmd.exe /k
E:
call conda activate swigbuild && cd E:\Shane\QuantLib\QuantLib-1.40\QuantLib-SWIG
set PATH=C:\Users\Shane2\Anaconda3;C:\Users\Shane2\Anaconda3\Scripts;C:\Shane\QuantLib\swigwin-4.2.1;E:\Shane\QuantLib\QuantLib-1.40\QuantLib\lib;%PATH%9
set QL_DIR=E:\Shane\QuantLib\QuantLib-1.40\QuantLib
set INCLUDE=C:\local\boost_1_82_0;%INCLUDE%
set LIB=C:\local\boost_1_82_0\lib64-msvc-14.3;%LIB%
echo [build] > setup.cfg && echo compiler=msvc>>setup.cfg
REM pause
cd Python
python -m build --wheel
pause &
call tox run

pip install E:\Shane\QuantLib\QuantLib-1.40\QuantLib-SWIG\Python\dist\quantlib-1.40-cp38-abi3-win_amd64.whl  --force-reinstall
pause
cmd /k
REM call pip install E:\Shane\QuantLib\QuantLib-1.37_noMods\QuantLib-SWIG\Python\dist\QuantLib-1.37-cp38-abi3-win_amd64.whl  --force-reinstall
REM pause
REM cmd /k
