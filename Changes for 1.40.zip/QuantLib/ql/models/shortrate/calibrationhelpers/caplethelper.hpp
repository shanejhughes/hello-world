/* -*- mode: c++; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*- */

/*
 Copyright (C) 2001, 2002, 2003 Sadruddin Rejeb

 This file is part of QuantLib, a free-software/open-source library
 for financial quantitative analysts and developers - http://quantlib.org/

 QuantLib is free software: you can redistribute it and/or modify it
 under the terms of the QuantLib license.  You should have received a
 copy of the license along with this program; if not, please email
 <quantlib-dev@lists.sf.net>. The license is also available online at
<https://www.quantlib.org/license.shtml>.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE.  See the license for more details.
*/

/*! \file caphelper.hpp
    \brief CapHelper calibration helper
*/

#ifndef quantlib_caplet_calibration_helper_hpp
#define quantlib_caplet_calibration_helper_hpp

#include <ql/models/calibrationhelper.hpp>
#include <ql/instruments/capfloor.hpp>
#include <ql/termstructures/volatility/volatilitytype.hpp>

namespace QuantLib {

    //! calibration helper for ATM cap

    class CapletHelper : public BlackCalibrationHelper {
      public:
        CapletHelper(const Period& length,
                  const Handle<Quote>& volatility,
                  const ext::shared_ptr<IborIndex>& index,
                  // data for ATM swap-rate calculation
                  Frequency fixedLegFrequency,
                  const DayCounter& fixedLegDayCounter,
                  const Handle<YieldTermStructure>& termStructure,
                  BlackCalibrationHelper::CalibrationErrorType errorType
                                    = BlackCalibrationHelper::RelativePriceError,
				const VolatilityType type = ShiftedLognormal,
				const Real shift = 0.0,
				const Real strike = Null< Real >());
        virtual void addTimesTo(std::list<Time>& times) const;
        virtual Real modelValue() const;
        virtual Real blackPrice(Volatility volatility) const;
        ext::shared_ptr<Cap> underlyingCap() const {
            calculate();
            return cap_;
        }

      private:
        void performCalculations() const;
        mutable ext::shared_ptr<Cap> cap_;
        const Period length_;
        const ext::shared_ptr<IborIndex> index_;
        const Handle<YieldTermStructure> termStructure_;
        const Frequency fixedLegFrequency_;
        const DayCounter fixedLegDayCounter_;
		const Real strike_;
		mutable Rate exerciseRate_;
    };

}

#endif
