/* -*- mode: c++; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*- */

/*
 Copyright (C) 2008, 2009 Jose Aparicio
 Copyright (C) 2008 Chris Kenyon
 Copyright (C) 2008 Roland Lichters
 Copyright (C) 2008 StatPro Italia srl
  Copyright (C) 2023 Andrea Pellegatta

 This file is part of QuantLib, a free-software/open-source library
 for financial quantitative analysts and developers - http://quantlib.org/

 QuantLib is free software: you can redistribute it and/or modify it
 under the terms of the QuantLib license.  You should have received a
 copy of the license along with this program; if not, please email
 <quantlib-dev@lists.sf.net>. The license is also available online at
 <https://www.quantlib.org/license.shtml>.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE.  See the license for more details.
*/

#include <ql/pricingengines/credit/isdacdsengine.hpp>
#include <ql/pricingengines/credit/integralcdsengine.hpp>
#include <ql/pricingengines/credit/midpointcdsengine.hpp>
#include <ql/pricingengines/credit/endpointcdsengine.hpp>
#include <ql/termstructures/credit/defaultprobabilityhelpers.hpp>
#include <ql/utilities/null_deleter.hpp>
#include <utility>

namespace QuantLib {

    CdsHelper::CdsHelper(const std::variant<Rate, Handle<Quote>>& quote,
                         const Period& tenor,
                         Integer settlementDays,
                         Calendar calendar,
                         Frequency frequency,
                         BusinessDayConvention paymentConvention,
                         DateGeneration::Rule rule,
                         DayCounter dayCounter,
                         Real recoveryRate,
                         const Handle<YieldTermStructure>& discountCurve,
                         bool settlesAccrual,
                         bool paysAtDefaultTime,
                         const Date& startDate,
                         DayCounter lastPeriodDayCounter,
                         const bool rebatesAccrual,
                         const CreditDefaultSwap::PricingModel model,
                         Integer cashSettlementDays,
                         Natural couponPaymentLagDays)
    : RelativeDateDefaultProbabilityHelper(quote), tenor_(tenor), settlementDays_(settlementDays),
      calendar_(std::move(calendar)), frequency_(frequency), paymentConvention_(paymentConvention),
      rule_(rule), dayCounter_(std::move(dayCounter)), recoveryRate_(recoveryRate),
      discountCurve_(discountCurve), settlesAccrual_(settlesAccrual),
      paysAtDefaultTime_(paysAtDefaultTime), lastPeriodDC_(std::move(lastPeriodDayCounter)),
      rebatesAccrual_(rebatesAccrual), model_(model), startDate_(startDate), 
      cashSettlementDays_(cashSettlementDays), couponPaymentLagDays_(couponPaymentLagDays) {

        CdsHelper::initializeDates();

        registerWith(discountCurve);
    }

    void CdsHelper::setTermStructure(DefaultProbabilityTermStructure* ts) {
        RelativeDateDefaultProbabilityHelper::setTermStructure(ts);

        probability_.linkTo(
            ext::shared_ptr<DefaultProbabilityTermStructure>(ts, null_deleter()),
            false);

        resetEngine();
    }

    void CdsHelper::update() {
        RelativeDateDefaultProbabilityHelper::update();
        resetEngine();
    }

    void CdsHelper::initializeDates() {

        protectionStart_ = evaluationDate_ + settlementDays_;

        Date startDate = startDate_ == Date() ? protectionStart_ : startDate_;
        // Only adjust start date if rule is not CDS or CDS2015. Unsure about OldCDS.
        if (rule_ != DateGeneration::CDS && rule_ != DateGeneration::CDS2015) {
            startDate = calendar_.adjust(startDate, paymentConvention_);
        }

        Date endDate;
        if (rule_ == DateGeneration::CDS2015 || rule_ == DateGeneration::CDS || rule_ == DateGeneration::OldCDS) {
            Date refDate = startDate_ == Date() ? evaluationDate_ : startDate_;
            endDate = cdsMaturity(refDate, tenor_, rule_);
        } else {
            // Keep the old logic here
            Date refDate = startDate_ == Date() ? protectionStart_ : startDate_ + settlementDays_;
            endDate = refDate + tenor_;
        }

        schedule_ =
            MakeSchedule().from(startDate)
                          .to(endDate)
                          .withFrequency(frequency_)
                          .withCalendar(calendar_)
                          .withConvention(paymentConvention_)
                          .withTerminationDateConvention(Unadjusted)
                          .withRule(rule_);
        earliestDate_ = schedule_.dates().front();
        latestDate_   = calendar_.adjust(schedule_.dates().back(),
                                         paymentConvention_);
        latestDate_ = calendar_.advance(latestDate_, Period(couponPaymentLagDays_, Days));
        if (model_ == CreditDefaultSwap::ISDA)
            ++latestDate_;
    }

    SpreadCdsHelper::SpreadCdsHelper(
                              const std::variant<Rate, Handle<Quote>>& runningSpread,
                              const Period& tenor,
                              Integer settlementDays,
                              const Calendar& calendar,
                              Frequency frequency,
                              BusinessDayConvention paymentConvention,
                              DateGeneration::Rule rule,
                              const DayCounter& dayCounter,
                              Real recoveryRate,
                              const Handle<YieldTermStructure>& discountCurve,
                              bool settlesAccrual,
                              bool paysAtDefaultTime,
                              const Date& startDate,
                              const DayCounter& lastPeriodDayCounter,
                              const bool rebatesAccrual,
                              const CreditDefaultSwap::PricingModel model,
                              Integer cashSettlementDays,
                              Natural couponPaymentLagDays)
    : CdsHelper(runningSpread, tenor, settlementDays, calendar,
                frequency, paymentConvention, rule, dayCounter,
                recoveryRate, discountCurve, settlesAccrual, paysAtDefaultTime,
                startDate, lastPeriodDayCounter, rebatesAccrual, model, cashSettlementDays, couponPaymentLagDays)
//                ,cashSettlementDays_(cashSettlementDays), couponPaymentLagDays_(couponPaymentLagDays),
                ,runningSpread_(std::holds_alternative<Rate>(runningSpread) ? 
                    std::get<Rate>(runningSpread) :std::get<Handle<Quote>>(runningSpread)->value())
    {}

    Real SpreadCdsHelper::impliedQuote() const {
        swap_->recalculate();
        return swap_->fairSpread();
    }

    void SpreadCdsHelper::resetEngine() {
        swap_ = ext::shared_ptr<CreditDefaultSwap>(new CreditDefaultSwap(
            Protection::Buyer, 100.0, 0.01, schedule_, paymentConvention_,
            dayCounter_, settlesAccrual_, paysAtDefaultTime_, protectionStart_,
            ext::shared_ptr<Claim>(), lastPeriodDC_, rebatesAccrual_, evaluationDate_,cashSettlementDays_,couponPaymentLagDays_));

        switch (model_) {
          case CreditDefaultSwap::ISDA:
            swap_->setPricingEngine(ext::make_shared<IsdaCdsEngine>(
                probability_, recoveryRate_, discountCurve_, false,
                IsdaCdsEngine::Taylor, IsdaCdsEngine::HalfDayBias,
                IsdaCdsEngine::Piecewise));
            break;
          case CreditDefaultSwap::Midpoint:
            swap_->setPricingEngine(ext::make_shared<MidPointCdsEngine>(
                probability_, recoveryRate_, discountCurve_));
            break;
          case CreditDefaultSwap::Endpoint:
              swap_->setPricingEngine(ext::make_shared<EndPointCdsEngine>(
                  probability_, recoveryRate_, discountCurve_));
              break;
          case CreditDefaultSwap::Integral:
              swap_->setPricingEngine(ext::make_shared<IntegralCdsEngine>(
                  QuantLib::Period(1, QuantLib::Days), probability_, recoveryRate_, discountCurve_));
              break;
          default:
            QL_FAIL("unknown CDS pricing model: " << model_);
        }
    }


    ext::shared_ptr<CreditDefaultSwap> SpreadCdsHelper::underlyingCDS() const {
        ext::shared_ptr<CreditDefaultSwap> swapOut_ = ext::shared_ptr<CreditDefaultSwap>(new CreditDefaultSwap(
            Protection::Buyer, 100.0, runningSpread_, schedule_, paymentConvention_,
            dayCounter_, settlesAccrual_, paysAtDefaultTime_, protectionStart_,
            ext::shared_ptr<Claim>(), lastPeriodDC_, rebatesAccrual_, evaluationDate_, cashSettlementDays_, couponPaymentLagDays_));

        switch (model_) {
        case CreditDefaultSwap::ISDA:
            swapOut_->setPricingEngine(ext::make_shared<IsdaCdsEngine>(
                probability_, recoveryRate_, discountCurve_, false,
                IsdaCdsEngine::Taylor, IsdaCdsEngine::HalfDayBias,
                IsdaCdsEngine::Piecewise));
            break;
        case CreditDefaultSwap::Midpoint:
            swapOut_->setPricingEngine(ext::make_shared<MidPointCdsEngine>(
                probability_, recoveryRate_, discountCurve_));
            break;
        case CreditDefaultSwap::Endpoint:
            swapOut_->setPricingEngine(ext::make_shared<EndPointCdsEngine>(
                probability_, recoveryRate_, discountCurve_));
            break;
        case CreditDefaultSwap::Integral:
            swapOut_->setPricingEngine(ext::make_shared<IntegralCdsEngine>(
                QuantLib::Period(1, QuantLib::Days), probability_, recoveryRate_, discountCurve_));
            break;
        default:
            QL_FAIL("unknown CDS pricing model: " << model_);
        }
        return swapOut_;
    }

    UpfrontCdsHelper::UpfrontCdsHelper(
                              const std::variant<Rate, Handle<Quote>>& upfront,
                              Rate runningSpread,
                              const Period& tenor,
                              Integer settlementDays,
                              const Calendar& calendar,
                              Frequency frequency,
                              BusinessDayConvention paymentConvention,
                              DateGeneration::Rule rule,
                              const DayCounter& dayCounter,
                              Real recoveryRate,
                              const Handle<YieldTermStructure>& discountCurve,
                              Natural upfrontSettlementDays,
                              bool settlesAccrual,
                              bool paysAtDefaultTime,
                              const Date& startDate,
                              const DayCounter& lastPeriodDayCounter,
                              const bool rebatesAccrual,
                              const CreditDefaultSwap::PricingModel model)
    : CdsHelper(upfront, tenor, settlementDays, calendar,
                frequency, paymentConvention, rule, dayCounter,
                recoveryRate, discountCurve, settlesAccrual, paysAtDefaultTime,
                startDate, lastPeriodDayCounter, rebatesAccrual, model),
      upfrontSettlementDays_(upfrontSettlementDays),
      upfrontDate_(upfrontDate()),
      runningSpread_(runningSpread) {}

    Date UpfrontCdsHelper::upfrontDate() {
        return calendar_.advance(evaluationDate_, upfrontSettlementDays_, Days, paymentConvention_);
    }

    void UpfrontCdsHelper::initializeDates() {
        CdsHelper::initializeDates();
        upfrontDate_ = upfrontDate();
    }

    void UpfrontCdsHelper::resetEngine() {
        swap_ = ext::make_shared<CreditDefaultSwap>(
            Protection::Buyer, 100.0, 0.01, runningSpread_, schedule_,
            paymentConvention_, dayCounter_, settlesAccrual_,
            paysAtDefaultTime_, protectionStart_, upfrontDate_,
            ext::shared_ptr<Claim>(), lastPeriodDC_, rebatesAccrual_,
            evaluationDate_);

        switch (model_) {
          case CreditDefaultSwap::ISDA:
            swap_->setPricingEngine(ext::make_shared<IsdaCdsEngine>(
                probability_, recoveryRate_, discountCurve_, false,
                IsdaCdsEngine::Taylor, IsdaCdsEngine::HalfDayBias,
                IsdaCdsEngine::Piecewise));
            break;
          case CreditDefaultSwap::Midpoint:
            swap_->setPricingEngine(ext::make_shared<MidPointCdsEngine>(
                probability_, recoveryRate_, discountCurve_));
            break;
          case CreditDefaultSwap::Endpoint:
              swap_->setPricingEngine(ext::make_shared<EndPointCdsEngine>(
                  probability_, recoveryRate_, discountCurve_));
              break;
          case CreditDefaultSwap::Integral:
              swap_->setPricingEngine(ext::make_shared<IntegralCdsEngine>(
                  QuantLib::Period(1, QuantLib::Days), probability_, recoveryRate_, discountCurve_));
          break;
        default:
            QL_FAIL("unknown CDS pricing model: " << model_);
        }
    }

    Real UpfrontCdsHelper::impliedQuote() const {
        SavedSettings backup;
        Settings::instance().includeTodaysCashFlows() = true;
        swap_->recalculate();
        return swap_->fairUpfront();
    }

}
