
/*
 Copyright (C) 2000, 2001, 2002, 2003 RiskMap srl
 Copyright (C) 2002, 2003 Ferdinando Ametrano
 Copyright (C) 2003, 2004, 2008 StatPro Italia srl
 Copyright (C) 2005 Dominic Thuillier
 Copyright (C) 2018, 2020 Matthias Lungwitz
 
 This file is part of QuantLib, a free-software/open-source library
 for financial quantitative analysts and developers - http://quantlib.org/

 QuantLib is free software: you can redistribute it and/or modify it
 under the terms of the QuantLib license.  You should have received a
 copy of the license along with this program; if not, please email
 <quantlib-dev@lists.sf.net>. The license is also available online at
 <https://www.quantlib.org/license.shtml>.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE.  See the license for more details.
*/

#ifndef quantlib_interpolation_i
#define quantlib_interpolation_i

%include linearalgebra.i
%include optimizers.i

%{
// safe versions which copy their arguments
template <class I>
class SafeInterpolation {
  public:
    SafeInterpolation(const Array& x, const Array& y)
    : x_(x), y_(y), f_(x_.begin(),x_.end(),y_.begin()) {}
    Real operator()(Real x, bool allowExtrapolation=false) {
        return f_(x, allowExtrapolation);
    }
    Array x_, y_;
    I f_;
};
%}

%define make_safe_interpolation(T,Alias)
%{
typedef SafeInterpolation<QuantLib::T> Safe##T;
%}
%rename(Alias) Safe##T;
class Safe##T {
    #if defined(SWIGCSHARP)
    %rename(call) operator();
    #endif
  public:
    Safe##T(const Array& x, const Array& y);
    Real operator()(Real x, bool allowExtrapolation=false);
};
%enddef

make_safe_interpolation(LinearInterpolation,LinearInterpolation);
make_safe_interpolation(LogLinearInterpolation,LogLinearInterpolation);

make_safe_interpolation(BackwardFlatInterpolation,BackwardFlatInterpolation);
make_safe_interpolation(ForwardFlatInterpolation,ForwardFlatInterpolation);

make_safe_interpolation(CubicNaturalSpline,CubicNaturalSpline);
make_safe_interpolation(LogCubicNaturalSpline,LogCubicNaturalSpline);
make_safe_interpolation(MonotonicCubicNaturalSpline,MonotonicCubicNaturalSpline);
make_safe_interpolation(MonotonicLogCubicNaturalSpline,MonotonicLogCubicNaturalSpline);

make_safe_interpolation(KrugerCubic,KrugerCubic);
make_safe_interpolation(KrugerLogCubic,KrugerLogCubic);

make_safe_interpolation(FritschButlandCubic,FritschButlandCubic);
make_safe_interpolation(FritschButlandLogCubic,FritschButlandLogCubic);

make_safe_interpolation(Parabolic,Parabolic);
make_safe_interpolation(LogParabolic,LogParabolic);
make_safe_interpolation(MonotonicParabolic,MonotonicParabolic);
make_safe_interpolation(MonotonicLogParabolic,MonotonicLogParabolic);

make_safe_interpolation(LagrangeInterpolation,LagrangeInterpolation); 

%define extend_spline(T)
%extend Safe##T {
    Real derivative(Real x, bool extrapolate = false) {
        return self->f_.derivative(x,extrapolate);
    }
    Real secondDerivative(Real x, bool extrapolate = false) {
        return self->f_.secondDerivative(x,extrapolate);
    }
    Real primitive(Real x, bool extrapolate = false) {
        return self->f_.primitive(x,extrapolate);
    }
}
%enddef

extend_spline(CubicNaturalSpline);
extend_spline(LogCubicNaturalSpline);
extend_spline(MonotonicCubicNaturalSpline);
extend_spline(MonotonicLogCubicNaturalSpline);

extend_spline(KrugerCubic);
extend_spline(KrugerLogCubic);

extend_spline(FritschButlandCubic);
extend_spline(FritschButlandLogCubic);

extend_spline(Parabolic);
extend_spline(LogParabolic);
extend_spline(MonotonicParabolic);
extend_spline(MonotonicLogParabolic);
// To be worked on 2023.07.16
make_safe_interpolation(HarmonicCubic,HarmonicCubic);
make_safe_interpolation(HarmonicLogCubic,HarmonicLogCubic);
extend_spline(HarmonicCubic);
extend_spline(HarmonicLogCubic);
make_safe_interpolation(QRMHarmonicCubic,QRMHarmonicCubic);
make_safe_interpolation(QRMHarmonicLogCubic,QRMHarmonicLogCubic);
extend_spline(QRMHarmonicCubic);
extend_spline(QRMHarmonicLogCubic);

//
%{
// safe versions which copy their arguments
template <class I>
class SafeInterpolation2D {
  public:
    SafeInterpolation2D(const Array& x, const Array& y, const Matrix& m)
    : x_(x), y_(y), m_(m), f_(x_.begin(),x_.end(),y_.begin(),y_.end(),m_) {}
    Real operator()(Real x, Real y, bool allowExtrapolation=false) {
        return f_(x,y, allowExtrapolation);
    }
  protected:
    Array x_, y_;
    Matrix m_;
    I f_;
};
%}

%define make_safe_interpolation2d(T,Alias)
%{
typedef SafeInterpolation2D<QuantLib::T> Safe##T;
%}
%rename(Alias) Safe##T;
class Safe##T {
    #if defined(SWIGCSHARP)
    %rename(call) operator();
    #endif
  public:
    Safe##T(const Array& x, const Array& y, const Matrix& m);
    Real operator()(Real x, Real y, bool allowExtrapolation=false);
};
%enddef

make_safe_interpolation2d(BilinearInterpolation,BilinearInterpolation);
make_safe_interpolation2d(BicubicSpline,BicubicSpline);


// interpolation traits

%{
using QuantLib::CubicInterpolation;
using QuantLib::MixedInterpolation;
using QuantLib::BackwardFlat;
using QuantLib::ForwardFlat;
using QuantLib::Linear;
using QuantLib::LogLinear;
using QuantLib::Cubic;
using QuantLib::Bicubic;
using QuantLib::ConvexMonotone;
using QuantLib::DefaultLogCubic;
using QuantLib::MonotonicLogCubic;
using QuantLib::KrugerLog;

class MonotonicCubic : public Cubic {
  public:
    MonotonicCubic()
    : Cubic(CubicInterpolation::Spline, true,
            CubicInterpolation::SecondDerivative, 0.0,
            CubicInterpolation::SecondDerivative, 0.0) {}
};

class SplineCubic : public Cubic {
  public:
    SplineCubic()
    : Cubic(CubicInterpolation::Spline, false,
            CubicInterpolation::SecondDerivative, 0.0,
            CubicInterpolation::SecondDerivative, 0.0) {}
};

class Kruger : public Cubic {
  public:
    Kruger()
    : Cubic(CubicInterpolation::Kruger) {}
};

class SplineLogCubic : public QuantLib::LogCubic {
  public:
    SplineLogCubic()
    : QuantLib::LogCubic(CubicInterpolation::Spline, false,
                         CubicInterpolation::SecondDerivative, 0.0,
                         CubicInterpolation::SecondDerivative, 0.0) {}
};

class LogMixedLinearCubic : public QuantLib::LogMixedLinearCubic {
  public:
    // We add defaults for all constructor arguments because wrappers for
    // InterpolatedDiscountCurve and PiecewiseYieldCurve assume that all
    // interpolators have default constructors.
    LogMixedLinearCubic(
        Size n = 0,
        MixedInterpolation::Behavior behavior = MixedInterpolation::ShareRanges,
        CubicInterpolation::DerivativeApprox da = CubicInterpolation::Spline,
        bool monotonic = true)
    : QuantLib::LogMixedLinearCubic(n, behavior, da, monotonic) {}
};

class ParabolicCubic : public QuantLib::Cubic {
  public:
    ParabolicCubic()
    : QuantLib::Cubic(CubicInterpolation::Parabolic, false,
                      CubicInterpolation::SecondDerivative, 0.0,
                      CubicInterpolation::SecondDerivative, 0.0) {}
};

class MonotonicParabolicCubic : public QuantLib::Cubic {
  public:
    MonotonicParabolicCubic()
    : QuantLib::Cubic(CubicInterpolation::Parabolic, true,
                      CubicInterpolation::SecondDerivative, 0.0,
                      CubicInterpolation::SecondDerivative, 0.0) {}
};

class LogParabolicCubic : public QuantLib::LogCubic {
  public:
    LogParabolicCubic()
    : QuantLib::LogCubic(CubicInterpolation::Parabolic, false,
                         CubicInterpolation::SecondDerivative, 0.0,
                         CubicInterpolation::SecondDerivative, 0.0) {}
};

class MonotonicLogParabolicCubic : public QuantLib::LogCubic {
  public:
    MonotonicLogParabolicCubic()
    : QuantLib::LogCubic(CubicInterpolation::Parabolic, true,
                         CubicInterpolation::SecondDerivative, 0.0,
                         CubicInterpolation::SecondDerivative, 0.0) {}
};
%}

%nodefaultctor CubicInterpolation;
struct CubicInterpolation {
    enum DerivativeApprox {
        Spline,
        SplineOM1,
        SplineOM2,
        FourthOrder,
        Parabolic,
        FritschButland,
        Akima,
        Kruger,
        Harmonic,
        QRMHarmonic,
    };
};

%nodefaultctor MixedInterpolation;
struct MixedInterpolation {
    enum Behavior { ShareRanges, SplitRanges };
};

struct BackwardFlat {};
struct ForwardFlat {};
struct Linear {};
struct LogLinear {};
struct Cubic {};
struct Bicubic {};
struct MonotonicCubic {};
struct DefaultLogCubic {};
struct MonotonicLogCubic {};
struct SplineCubic {};
struct SplineLogCubic {};
struct Kruger {};
struct KrugerLog {};
struct ConvexMonotone {
    ConvexMonotone(Real quadraticity = 0.3,
                   Real monotonicity = 0.7,
                   bool forcePositive = true);
};
struct ParabolicCubic {};
struct MonotonicParabolicCubic {};
struct LogParabolicCubic {};
struct MonotonicLogParabolicCubic {};

struct LogMixedLinearCubic {
    #if !defined(SWIGJAVA) && !defined(SWIGCSHARP)
    %feature("kwargs") LogMixedLinearCubic;
    #endif
    LogMixedLinearCubic(
        Size n = 0,
        MixedInterpolation::Behavior behavior = MixedInterpolation::ShareRanges,
        CubicInterpolation::DerivativeApprox da = CubicInterpolation::Spline,
        bool monotonic = true);
};


%{
using QuantLib::RichardsonExtrapolation;
%}

class RichardsonExtrapolation {
  public:
    Real operator()(Real t=2.0) const;
    Real operator()(Real t, Real s) const;
    
#if defined(SWIGPYTHON)
    %extend {
        RichardsonExtrapolation(
            PyObject* fct, Real delta_h, Real n = Null<Real>()) {
        
            UnaryFunction f(fct);
            return new RichardsonExtrapolation(f, delta_h, n); 
        }
    }
#elif defined(SWIGJAVA) || defined(SWIGCSHARP)
    %extend {
        RichardsonExtrapolation(
            UnaryFunctionDelegate* fct, Real delta_h, Real n = Null<Real>()) {
        
            UnaryFunction f(fct);
            return new RichardsonExtrapolation(f, delta_h, n); 
        }
    }
#else
  private:
    RichardsonExtrapolation();
#endif
};


%{
class SafeConvexMonotoneInterpolation {
  public:
    SafeConvexMonotoneInterpolation(const Array& x, const Array& y,
                                    Real quadraticity = 0.3,
                                    Real monotonicity = 0.7,
                                    bool forcePositive = true)
    : x_(x), y_(y), f_(x_.begin(), x_.end(), y_.begin(),
                       quadraticity, monotonicity, forcePositive) {}
    Real operator()(Real x, bool allowExtrapolation=false) {
        return f_(x, allowExtrapolation);
    }
    Array x_, y_;
    QuantLib::ConvexMonotoneInterpolation<Array::const_iterator, Array::const_iterator> f_;
};
%}


%{
using QuantLib::ChebyshevInterpolation;
%}

class ChebyshevInterpolation {
    #if defined(SWIGCSHARP)
    %rename(call) operator();
    #endif

  public:
    enum PointsType {FirstKind, SecondKind};
    ChebyshevInterpolation(const Array& f, PointsType pointsType = SecondKind);
#if defined(SWIGPYTHON)
    %extend {
        ChebyshevInterpolation(
            Size n, PyObject* fct, PointsType pointsType = SecondKind) {
        
            UnaryFunction f(fct);
            return new ChebyshevInterpolation(n, f, pointsType); 
        }
    }
#elif defined(SWIGJAVA) || defined(SWIGCSHARP)
    %extend {
        ChebyshevInterpolation(
            Size n, UnaryFunctionDelegate* fct, PointsType pointsType = SecondKind) {
        
            UnaryFunction f(fct);
            return new ChebyshevInterpolation(n, f, pointsType); 
        }
    }
#endif
    
    Real operator()(Real z, bool allowExtrapolation=false) const;
    static Array nodes(Size n, PointsType pointsType);
};


%rename(ConvexMonotoneInterpolation) SafeConvexMonotoneInterpolation;
class SafeConvexMonotoneInterpolation {
    #if defined(SWIGCSHARP)
    %rename(call) operator();
    #endif
  public:
    SafeConvexMonotoneInterpolation(const Array& x, const Array& y,
                                    Real quadraticity = 0.3,
                                    Real monotonicity = 0.7,
                                    bool forcePositive = true);
    Real operator()(Real x, bool allowExtrapolation=false);
};




%{
using QuantLib::Extrapolator;
using QuantLib::Interpolation;
using QuantLib::AbcdInterpolation;
using QuantLib::Real;
using QuantLib::Time;
using QuantLib::ZabrInterpolation;
using QuantLib::ZabrShortMaturityLognormal;
using QuantLib::ZabrShortMaturityNormal;
using QuantLib::ZabrLocalVolatility;
%}
%{
// safe versions which copy their arguments
template <class I>
class SabcdInterpolation
{
	public:
		SabcdInterpolation( const std::vector<Real>& x, const std::vector<Real>& y)
		: x_(x),y_(y),f_(x_.begin(),x_.end(),y_.begin()){}
		Real operator()(Real x, bool allowExtrapolation=false) {
        return f_(x, allowExtrapolation);
		}
		std::vector<Real> x_,y_;
//		QuantLib::AbcdInterpolation f_;
		I f_;
};
%}

%define make_sabcd_interpolation(T,Alias)
%{
typedef SabcdInterpolation<QuantLib::T> Sabcd##T;
%}
%rename(Alias) Sabcd##T;
class Sabcd##T {
    #if defined(SWIGMZSCHEME) || defined(SWIGGUILE) \
     || defined(SWIGCSHARP) || defined(SWIGPERL)
    %rename(call) operator();
    #endif
  public:
    Sabcd##T(const std::vector<Real>&  x, const std::vector<Real>&  y);
    Real operator()(Real x, bool allowExtrapolation=false);
};
%enddef

make_sabcd_interpolation(AbcdInterpolation,AbcdInterpolation);


%define extend_sabcd(T)
%extend Sabcd##T {
    Real a() {
 //       self->f_.update();
		return self->f_.a();
    }
    Real b() {
 //       self->f_.update();
		return self->f_.b();
    }
    Real c() {
 //       self->f_.update();
		return self->f_.c();
    }
    Real d() {
 //       self->f_.update();
		return self->f_.d();
    }
    Real rmsError() {
        self->f_.update();
		return self->f_.rmsError();
    }
    Real maxError() {
        self->f_.update();
		return self->f_.maxError();
    }
    void update() {
        return self->f_.update();
    }
}
%enddef

extend_sabcd(AbcdInterpolation);




%{
// safe versions which copy their arguments
template <class I>
class SsabrInterpolation
{
	public:
		SsabrInterpolation( const std::vector<Real>& x, const std::vector<Real>& y, QuantLib::Time t, QuantLib::Real forward, QuantLib::Rate shift)
		: x_(x),y_(y),t_(t),forward_(forward),shift_(shift),f_(x_.begin(),x_.end(),y_.begin(),t_,forward_,0.01,0.42,0.32,0.17,0,0,0,0,1,
		ext::shared_ptr<QuantLib::EndCriteria>(), ext::shared_ptr<QuantLib::OptimizationMethod>(), 0.0020, false, 50, shift_
		){}
		
		SsabrInterpolation( const std::vector<Real>& x, const std::vector<Real>& y, QuantLib::Time t, QuantLib::Real forward
		, Real alpha, Real beta, Real nu, Real rho, bool alphaIsFixed, bool betaIsFixed, bool nuIsFixed, bool rhoIsFixed
		, bool vegaWeighted,const Real errorAccept, const bool useMaxError, const Size maxGuesses,QuantLib::Rate shift)
		: x_(x),y_(y),t_(t),forward_(forward),shift_(shift),
		alpha_(alpha),beta_(beta),nu_(nu),rho_(rho),alphaIsFixed_(alphaIsFixed),betaIsFixed_(betaIsFixed),nuIsFixed_(nuIsFixed),rhoIsFixed_(rhoIsFixed),
		vegaWeighted_(vegaWeighted),errorAccept_(errorAccept),useMaxError_(useMaxError),maxGuesses_(maxGuesses),
		f_(x_.begin(),x_.end(),y_.begin(),t_,forward_,alpha_,beta_,nu_,rho_,alphaIsFixed_,betaIsFixed_,nuIsFixed_,rhoIsFixed_,vegaWeighted_,
		ext::shared_ptr<QuantLib::EndCriteria>(), ext::shared_ptr<QuantLib::OptimizationMethod>(), errorAccept_, useMaxError_, maxGuesses_, shift_
		){}
		Real operator()(Real x, bool allowExtrapolation=false) {
		return f_(x, allowExtrapolation);
		}
		std::vector<Real> x_,y_;
		Real alpha_,beta_,nu_,rho_,errorAccept_;
		bool alphaIsFixed_,betaIsFixed_,nuIsFixed_,rhoIsFixed_,vegaWeighted_,useMaxError_;
		QuantLib::Time t_;
		QuantLib::Real forward_;
		QuantLib::Rate shift_;
		QuantLib::Size maxGuesses_;
		I f_;
};
%}

%define make_ssabr_interpolation(T,Alias)
%{
typedef SsabrInterpolation<QuantLib::T> Ssabr##T;
%}
%rename(Alias) Ssabr##T;
class Ssabr##T {
    #if defined(SWIGMZSCHEME) || defined(SWIGGUILE) \
     || defined(SWIGCSHARP) || defined(SWIGPERL)
    %rename(call) operator();
    #endif
  public:
    Ssabr##T(const std::vector<Real>&  x, const std::vector<Real>&  y, QuantLib::Time t, QuantLib::Real forward, QuantLib::Rate shift);
    Real operator()(Real x, bool allowExtrapolation=false);
};
%enddef

%define make_ssabr_full_interpolation(T,Alias)
%{
typedef SsabrInterpolation<QuantLib::T> SsabrFull##T;
%}
%rename(Alias) SsabrFull##T;
class SsabrFull##T {
    #if defined(SWIGMZSCHEME) || defined(SWIGGUILE) \
     || defined(SWIGCSHARP) || defined(SWIGPERL)
    %rename(call) operator();
    #endif
  public:

    SsabrFull##T(const std::vector<Real>&  x, const std::vector<Real>&  y, QuantLib::Time t, QuantLib::Real forward,
	Real alpha, Real beta, Real nu, Real rho, bool alphaIsFixed, bool betaIsFixed, bool nuIsFixed, bool rhoIsFixed,
	bool vegaWeighted,const Real errorAccept, const bool useMaxError, const Size maxGuesses,
	QuantLib::Rate shift);
    Real operator()(Real x, bool allowExtrapolation=false);
};
%enddef

make_ssabr_interpolation(SABRInterpolation,SABRInterpolation);
make_ssabr_interpolation(NoArbSabrInterpolation,NoArbSabrInterpolation);
make_ssabr_full_interpolation(SABRInterpolation,SABRFullInterpolation);
make_ssabr_full_interpolation(NoArbSabrInterpolation,NoArbSabrFullInterpolation);

%define extend_ssabr(T)
%extend Ssabr##T {
    Real alpha() {
        self->f_.update();
		return self->f_.alpha();
    }
    Real beta() {
        self->f_.update();
		return self->f_.beta();
    }
    Real nu() {
        self->f_.update();
		return self->f_.nu();
    }
    Real rho() {
        self->f_.update();
		return self->f_.rho();
    }
    Real expiry() {
        self->f_.update();
		return self->f_.expiry();
    }
    Real forward() {
        self->f_.update();
		return self->f_.forward();
    }
    Real rmsError() {
        self->f_.update();
		return self->f_.rmsError();
    }
    Real maxError() {
        self->f_.update();
		return self->f_.maxError();
    }
    void update() {
        return self->f_.update();
    }
}
%enddef

%define extend_ssabr_full(T)
%extend SsabrFull##T {
    Real alpha() {
        self->f_.update();
		return self->f_.alpha();
    }
    Real beta() {
        self->f_.update();
		return self->f_.beta();
    }
    Real nu() {
        self->f_.update();
		return self->f_.nu();
    }
    Real rho() {
        self->f_.update();
		return self->f_.rho();
    }
    Real expiry() {
        self->f_.update();
		return self->f_.expiry();
    }
    Real forward() {
        self->f_.update();
		return self->f_.forward();
    }
    Real rmsError() {
        self->f_.update();
		return self->f_.rmsError();
    }
    Real maxError() {
        self->f_.update();
		return self->f_.maxError();
    }
    void update() {
        return self->f_.update();
    }
}
%enddef

extend_ssabr(SABRInterpolation);
extend_ssabr(NoArbSabrInterpolation);
extend_ssabr_full(SABRInterpolation);
extend_ssabr_full(NoArbSabrInterpolation);




%{
// safe versions which copy their arguments
class SzabrInterpolation
{
	public:
		SzabrInterpolation( 
			const std::vector<Real>& x,
			const std::vector<Real>& y,
			QuantLib::Time t,
			QuantLib::Real forward
			)
		: x_(x),y_(y),t_(t),forward_(forward),f_(x_.begin(),x_.end(),y_.begin(),t_,forward_,0.01,0.42,0.32,0.17,0.5,false,false,false,false,false
//		,1,ext::shared_ptr<QuantLib::EndCriteria>(), ext::shared_ptr<QuantLib::OptimizationMethod>(), 0.0020, false, 50
		){}
		Real operator()(Real x, bool allowExtrapolation=false) {
		return f_(x, allowExtrapolation);
		}
		std::vector<Real> x_,y_;
		QuantLib::Time t_;
		QuantLib::Real forward_;
		QuantLib::ZabrInterpolation<ZabrShortMaturityLognormal> f_;
};
%}

%define make_szabr_interpolation(T,Alias)
%{
typedef SzabrInterpolation Szabr##T;
%}
%rename(Alias) Szabr##T;
class Szabr##T {
    #if defined(SWIGMZSCHEME) || defined(SWIGGUILE) \
     || defined(SWIGCSHARP) || defined(SWIGPERL)
    %rename(call) operator();
    #endif
  public:
    Szabr##T(const std::vector<Real>&  x, const std::vector<Real>&  y, QuantLib::Time t, QuantLib::Real forward);
    Real operator()(Real x, bool allowExtrapolation=false);

};
%enddef


make_szabr_interpolation(Blah,ZabrShortMaturityLognormalInterpolation);

%define extend_szabr(T)
%extend Szabr##T {
    Real alpha() {
        self->f_.update();
		return self->f_.alpha();
    }
    Real beta() {
        self->f_.update();
		return self->f_.beta();
    }
    Real nu() {
        self->f_.update();
		return self->f_.nu();
    }
    Real rho() {
        self->f_.update();
		return self->f_.rho();
    }
    Real gamma() {
        self->f_.update();
		return self->f_.gamma();
    }
    Real expiry() {
        self->f_.update();
		return self->f_.expiry();
    }
    Real forward() {
        self->f_.update();
		return self->f_.forward();
    }
    Real rmsError() {
        self->f_.update();
		return self->f_.rmsError();
    }
    Real maxError() {
        self->f_.update();
		return self->f_.maxError();
    }
    void update() {
        return self->f_.update();
    }
}
%enddef
extend_szabr(Blah);


%{
// safe versions which copy their arguments
class SzabrNInterpolation
{
	public:
		SzabrNInterpolation( 
			const std::vector<Real>& x,
			const std::vector<Real>& y,
			QuantLib::Time t,
			QuantLib::Real forward
			)
		: x_(x),y_(y),t_(t),forward_(forward),f_(x_.begin(),x_.end(),y_.begin(),t_,forward_,0.01,0.42,0.32,0.17,0.5,false,false,false,false,false
//		,1,ext::shared_ptr<QuantLib::EndCriteria>(), ext::shared_ptr<QuantLib::OptimizationMethod>(), 0.0020, false, 50
		){}
		Real operator()(Real x, bool allowExtrapolation=false) {
		return f_(x, allowExtrapolation);
		}
		std::vector<Real> x_,y_;
		QuantLib::Time t_;
		QuantLib::Real forward_;
		QuantLib::ZabrInterpolation<ZabrShortMaturityNormal> f_;
};
%}

%define make_szabrn_interpolation(T,Alias)
%{
typedef SzabrNInterpolation SzabrN##T;
%}
%rename(Alias) SzabrN##T;
class SzabrN##T {
    #if defined(SWIGMZSCHEME) || defined(SWIGGUILE) \
     || defined(SWIGCSHARP) || defined(SWIGPERL)
    %rename(call) operator();
    #endif
  public:
    SzabrN##T(const std::vector<Real>&  x, const std::vector<Real>&  y, QuantLib::Time t, QuantLib::Real forward);
    Real operator()(Real x, bool allowExtrapolation=false);

};
%enddef


make_szabrn_interpolation(Blahn,ZabrShortMaturityNormalInterpolation);

%define extend_szabrn(T)
%extend SzabrN##T {
    Real alpha() {
        self->f_.update();
		return self->f_.alpha();
    }
    Real beta() {
        self->f_.update();
		return self->f_.beta();
    }
    Real nu() {
        self->f_.update();
		return self->f_.nu();
    }
    Real rho() {
        self->f_.update();
		return self->f_.rho();
    }
    Real gamma() {
        self->f_.update();
		return self->f_.gamma();
    }
    Real expiry() {
        self->f_.update();
		return self->f_.expiry();
    }
    Real forward() {
        self->f_.update();
		return self->f_.forward();
    }
    Real rmsError() {
        self->f_.update();
		return self->f_.rmsError();
    }
    Real maxError() {
        self->f_.update();
		return self->f_.maxError();
    }
    void update() {
        return self->f_.update();
    }
}
%enddef
extend_szabrn(Blahn);


%{
// safe versions which copy their arguments
class SzabrLocalInterpolation
{
	public:
		SzabrLocalInterpolation( 
			const std::vector<Real>& x,
			const std::vector<Real>& y,
			QuantLib::Time t,
			QuantLib::Real forward
			)
		: x_(x),y_(y),t_(t),forward_(forward),f_(x_.begin(),x_.end(),y_.begin(),t_,forward_,0.01,0.42,0.32,0.17,0.5,false,false,false,false,false
//		,1,ext::shared_ptr<QuantLib::EndCriteria>(), ext::shared_ptr<QuantLib::OptimizationMethod>(), 0.0020, false, 50
		){}
		Real operator()(Real x, bool allowExtrapolation=false) {
		return f_(x, allowExtrapolation);
		}
		std::vector<Real> x_,y_;
		QuantLib::Time t_;
		QuantLib::Real forward_;
		QuantLib::ZabrInterpolation<ZabrLocalVolatility> f_;
};
%}

%define make_szabrlocal_interpolation(T,Alias)
%{
typedef SzabrLocalInterpolation SzabrLocal##T;
%}
%rename(Alias) SzabrLocal##T;
class SzabrLocal##T {
    #if defined(SWIGMZSCHEME) || defined(SWIGGUILE) \
     || defined(SWIGCSHARP) || defined(SWIGPERL)
    %rename(call) operator();
    #endif
  public:
    SzabrLocal##T(const std::vector<Real>&  x, const std::vector<Real>&  y, QuantLib::Time t, QuantLib::Real forward);
    Real operator()(Real x, bool allowExtrapolation=false);
};
%enddef


make_szabrlocal_interpolation(Blahlocal,ZabrLocalVolatilityInterpolation);

%define extend_szabrlocal(T)
%extend SzabrLocal##T {
    Real alpha() {
        self->f_.update();
		return self->f_.alpha();
    }
    Real beta() {
        self->f_.update();
		return self->f_.beta();
    }
    Real nu() {
        self->f_.update();
		return self->f_.nu();
    }
    Real rho() {
        self->f_.update();
		return self->f_.rho();
    }
    Real gamma() {
        self->f_.update();
		return self->f_.gamma();
    }
    Real expiry() {
        self->f_.update();
		return self->f_.expiry();
    }
    Real forward() {
        self->f_.update();
		return self->f_.forward();
    }
    Real rmsError() {
        self->f_.update();
		return self->f_.rmsError();
    }
    Real maxError() {
        self->f_.update();
		return self->f_.maxError();
    }
    void update() {
        return self->f_.update();
    }
}
%enddef


extend_szabrlocal(Blahlocal);


#endif
