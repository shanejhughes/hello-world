Thses are the file file modification to get QuantLibXL 1.22 to comile with QuantLib 1.31.
It also includes the extension of qlSwapRateHelper and qlSwapRateHelper2 to allow for the use of indexed coupons

NB qlRiskyBonds is dropped as no longer in QuantLib

Also...I had to modify some code in QuantLib to undo the removal of QL code that was 
removed between 1.22 and 1.31 due to Deprecation in QuantLib (BlackCalibrationHelpers in calibrate)
Ideally I would solve in QuantLibAddin ... but this is easier for now

Also... adds HarmonicCubic and HarmonicLogCubic interpolation types
Also ...add oibasiswap and oiccbasisswap instruments, helpers and pricing endine
also...add ireland .hpp/cpp and dateutilities.hpp/cpp
