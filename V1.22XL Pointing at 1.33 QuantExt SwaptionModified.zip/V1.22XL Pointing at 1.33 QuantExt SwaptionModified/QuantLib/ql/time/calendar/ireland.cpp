/* -*- mode: c++; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*- */

/*
 Copyright (C) 2015 Paolo Mazzocchi
 Copyright (C) 2015 Riccardo Barone

 This file is part of QuantLib, a free-software/open-source library
 for financial quantitative analysts and developers - http://quantlib.org/

 QuantLib is free software: you can redistribute it and/or modify it
 under the terms of the QuantLib license.  You should have received a
 copy of the license along with this program; if not, please email
 <quantlib-dev@lists.sf.net>. The license is also available online at
 <http://quantlib.org/license.shtml>.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE.  See the license for more details.
*/

#include <ql/time/calendars/ireland.hpp>
#include <ql/errors.hpp>
#include <ql/time/dateutilities.hpp>

namespace QuantLib {

Ireland::Ireland(const Market market) {
    // all calendar instances on the same market share the same
    // implementation instance
    switch (market) {
    case IrishStockExchange:
        impl_ = boost::make_shared<Ireland::IrishStockExchangeImpl>();
        break;
    case BankHolidays:
        impl_ = boost::make_shared<Ireland::BankHolidaysImpl>();
        break;
    default:
        QL_FAIL("Internal error, unexpected market " << market);
    }
}

bool Ireland::IrishStockExchangeImpl::isBusinessDay(const Date& date) const {
    Weekday w = date.weekday();
    Day d = date.dayOfMonth(), dd = date.dayOfYear();
    Month m = date.month();
    Year y = date.year();
    Day em = easterMonday(y);

    if (isWeekend(w)
        // New Year's Day (possibly moved to Monday)
        || ((d == 1 || ((d == 2 || d == 3) && w == Monday)) && m == January)
        // St Brigid's Day (1st Feb if a Friday, first Monday of Fenruary otherise) Since 2023
        || ((d == 1 && w ==Friday) && m == February && y >= 2023)
        || ((d != 4) && m == February && d == Date::nthWeekday(1, Monday, February, y).dayOfMonth() && y >= 2023)
        // Good Friday
        || (dd == em - 3)
        // Easter Monday
        || (dd == em)
        // St. Patrick's Day (possibly moved to Monday)
        || (m == Mar && ((d == 17) || ((d == 18 || d == 19) && w == Monday)))
        // first Monday of May
        || (m == May && d == Date::nthWeekday(1, Monday, May, y).dayOfMonth())
        // first Monday of June
        || (m == June && d == Date::nthWeekday(1, Monday, June, y).dayOfMonth())
        // first Monday of August
        || (m == August && d == Date::nthWeekday(1, Monday, August, y).dayOfMonth())
        // last Monday of October
        || (m == October && d == DateUtilities::lastWeekday(Monday, October, y).dayOfMonth())
        // Christmas (possibly moved to Monday or Tuesday)
        || ((d == 25 || (d == 27 && (w == Monday || w == Tuesday))) && m == December)
        // St Stephen's Day (possibly moved to Monday or Tuesday)
        || ((d == 26 || (d == 28 && (w == Monday || w == Tuesday))) && m == December))
        return false; // NOLINT(readability-simplify-boolean-expr)
    return true;
}

bool Ireland::BankHolidaysImpl::isBusinessDay(const Date& date) const {
    Weekday w = date.weekday();
    Day d = date.dayOfMonth();
    Month m = date.month();
    if (!IrishStockExchangeImpl::isBusinessDay(date) ||
        (m == December && (d == 27 || (d == 29 && (w == Mon || w == Tue || w == Wed)) || (d == 28 && w == Wed))))
        return false;
    else
        return true;
}

}
