/* -*- mode: c++; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*- */

/*
 Copyright (C) 2016 Stefano Fondi
 Copyright (C) 2007, 2008 Ferdinando Ametrano
 Copyright (C) 2006 Marco Bianchetti
 Copyright (C) 2006, 2007 Eric Ehlers
 Copyright (C) 2006 Giorgio Facchinetti
 Copyright (C) 2006 Chiara Fornarola
 Copyright (C) 2007 Katiuscia Manzoni
 Copyright (C) 2005 Plamen Neykov

 This file is part of QuantLib, a free-software/open-source library
 for financial quantitative analysts and developers - http://quantlib.org/

 QuantLib is free software: you can redistribute it and/or modify it
 under the terms of the QuantLib license.  You should have received a
 copy of the license along with this program; if not, please email
 <quantlib-dev@lists.sf.net>. The license is also available online at
 <http://quantlib.org/license.shtml>.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE.  See the license for more details.
*/

#include <qlo/enumerations/constructors/enumeratedclasses.hpp>
#include <qlo/conversions/conversions.hpp>
#include <ql/indexes/ibor/euribor.hpp>
#include <ql/indexes/ibor/eurlibor.hpp>
#include <ql/indexes/swap/euriborswap.hpp>
#include <ql/indexes/swap/eurliborswap.hpp>

#include <ql/math/interpolations/backwardflatinterpolation.hpp>
#include <ql/math/interpolations/forwardflatinterpolation.hpp>
#include <ql/math/interpolations/loginterpolation.hpp>
#include <ql/math/interpolations/mixedinterpolation.hpp>
#include <ql/math/interpolations/abcdinterpolation.hpp>

#include <ql/math/interpolations/bilinearinterpolation.hpp>
#include <ql/math/interpolations/bicubicsplineinterpolation.hpp>
#include <ql/processes/blackscholesprocess.hpp>
#include <ql/instruments/vanillaoption.hpp>

namespace QuantLibAddin {

    /* *** StrikedTypePayoff *** */
    /* *** Option::Type + 1 parameter *** */
    QuantLib::ext::shared_ptr<QuantLib::Payoff> VANILLA_Payoff(
            const QuantLib::Option::Type& optionType,
            const double strike) {
        return QuantLib::ext::shared_ptr<QuantLib::Payoff> (
            new QuantLib::PlainVanillaPayoff(optionType, strike));
    }
    QuantLib::ext::shared_ptr<QuantLib::Payoff> ASSETORNOTHING_Payoff(
            const QuantLib::Option::Type& optionType,
            const double strike) {
        return QuantLib::ext::shared_ptr<QuantLib::Payoff> (
            new QuantLib::AssetOrNothingPayoff(optionType, strike));
    }
    QuantLib::ext::shared_ptr<QuantLib::Payoff> PERCENTAGESTRIKE_Payoff(
            const QuantLib::Option::Type& optionType,
            const double moneyness) {
        return QuantLib::ext::shared_ptr<QuantLib::Payoff> (
            new QuantLib::PercentageStrikePayoff(optionType, moneyness));
    }
    /* *** Option::Type + 2 parameters *** */
    QuantLib::ext::shared_ptr<QuantLib::Payoff> CASHORNOTHING_Payoff(
            const QuantLib::Option::Type& optionType,
            const double strike,
            const double cashPayoff) {
        return QuantLib::ext::shared_ptr<QuantLib::Payoff> (
            new QuantLib::CashOrNothingPayoff(optionType, strike, cashPayoff));
    }
    QuantLib::ext::shared_ptr<QuantLib::Payoff> GAP_Payoff(
            const QuantLib::Option::Type& optionType,
            const double strike,
            const double secondStrike) {
        return QuantLib::ext::shared_ptr<QuantLib::Payoff> (
            new QuantLib::GapPayoff(optionType, strike, secondStrike));
    }
    /* *** 2 parameters *** */
    QuantLib::ext::shared_ptr<QuantLib::Payoff> SUPERFUND_Payoff(
            const QuantLib::Option::Type&,
            const double strike,
            const double secondStrike) {
        return QuantLib::ext::shared_ptr<QuantLib::Payoff> (
            new QuantLib::SuperFundPayoff(strike, secondStrike));
    }
    /* *** 3 parameters *** */
    QuantLib::ext::shared_ptr<QuantLib::Payoff> SUPERSHARE_Payoff(
            const QuantLib::Option::Type&,
            const double strike,
            const double secondStrike,
            const double cashPayoff) {
        return QuantLib::ext::shared_ptr<QuantLib::Payoff> (
            new QuantLib::SuperSharePayoff(strike, secondStrike, cashPayoff));
    }

    /* *** PricingEngines - without timesteps *** */
    QuantLib::ext::shared_ptr<QuantLib::PricingEngine> AB_Engine(
        const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process) {
        return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
            new QuantLib::AnalyticBarrierEngine(process));
    }
    QuantLib::ext::shared_ptr<QuantLib::PricingEngine> AC_Engine(
        const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process) {
        return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
            new QuantLib::AnalyticCliquetEngine(process));
    }
    QuantLib::ext::shared_ptr<QuantLib::PricingEngine> ACGAPA_Engine(
        const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process) {
        return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
            new QuantLib::AnalyticContinuousGeometricAveragePriceAsianEngine(process));
    }
    QuantLib::ext::shared_ptr<QuantLib::PricingEngine> ADA_Engine(
        const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process) {
        return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
            new QuantLib::AnalyticDigitalAmericanEngine(process));
    }
    QuantLib::ext::shared_ptr<QuantLib::PricingEngine> ADE_Engine(
        const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process) {
        return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
            new QuantLib::AnalyticDividendEuropeanEngine(process));
    }
    QuantLib::ext::shared_ptr<QuantLib::PricingEngine> ADGAPA_Engine(
        const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process) {
        return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
            new QuantLib::AnalyticDiscreteGeometricAveragePriceAsianEngine(process));
    }
    QuantLib::ext::shared_ptr<QuantLib::PricingEngine> AE_Engine(
        const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process) {
        return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
            new QuantLib::AnalyticEuropeanEngine(process));
    }
    QuantLib::ext::shared_ptr<QuantLib::PricingEngine> AP_Engine(
        const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process) {
        return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
            new QuantLib::AnalyticPerformanceEngine(process));
    }
    QuantLib::ext::shared_ptr<QuantLib::PricingEngine> BAWA_Engine(
        const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process) {
        return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
            new QuantLib::BaroneAdesiWhaleyApproximationEngine(process));
    }
    QuantLib::ext::shared_ptr<QuantLib::PricingEngine> BSA_Engine(
        const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process) {
        return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
            new QuantLib::BjerksundStenslandApproximationEngine(process));
    }
    QuantLib::ext::shared_ptr<QuantLib::PricingEngine> I_Engine(
        const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process) {
        return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
            new QuantLib::IntegralEngine(process));
    }
    QuantLib::ext::shared_ptr<QuantLib::PricingEngine> PE_Engine(
        const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process) {
        return QuantLib::ext::shared_ptr<QuantLib::PricingEngine>();
    }
    QuantLib::ext::shared_ptr<QuantLib::PricingEngine> SE_Engine(
        const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process) {
        return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
            new QuantLib::StulzEngine(process, process, 0));//FIXME dummy inputs
    }
    // FIXME these seem not to work following pricing engines redesign?
    //QuantLib::ext::shared_ptr<QuantLib::PricingEngine> FE_Engine(
    //    const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process) {
    //    QuantLib::ext::shared_ptr<QuantLib::VanillaOption::engine>
    //        underlyingEngine(new QuantLib::AnalyticEuropeanEngine(process));
    //    return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
    //        new QuantLib::ForwardEngine<QuantLib::VanillaOption::arguments,
    //            QuantLib::VanillaOption::results>(underlyingEngine));
    //}
    //QuantLib::ext::shared_ptr<QuantLib::PricingEngine> FPE_Engine(
    //    const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process) {
    //    QuantLib::ext::shared_ptr<QuantLib::VanillaOption::engine>
    //        underlyingEngine(new QuantLib::AnalyticEuropeanEngine(process));
    //    return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
    //        new QuantLib::ForwardPerformanceEngine
    //            <QuantLib::VanillaOption::arguments,
    //            QuantLib::VanillaOption::results>(underlyingEngine));
    //}
    //QuantLib::ext::shared_ptr<QuantLib::PricingEngine> QE_Engine(
    //    const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process) {
    //    QuantLib::ext::shared_ptr<QuantLib::VanillaOption::engine>
    //        underlyingEngine(new QuantLib::AnalyticEuropeanEngine(process));
    //    return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
    //        new QuantLib::QuantoEngine<QuantLib::VanillaOption,
    //            QuantLib::PricingEngine>(underlyingEngine));
    //}
    //QuantLib::ext::shared_ptr<QuantLib::PricingEngine> QFE_Engine(
    //    const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process) {
    //    QuantLib::ext::shared_ptr<QuantLib::VanillaOption::engine>
    //        underlyingEngine(new QuantLib::AnalyticEuropeanEngine(process));
    //    QuantLib::ext::shared_ptr<QuantLib::ForwardVanillaOption::engine> forwardEngine(
    //            new QuantLib::ForwardEngine<QuantLib::VanillaOption::arguments,
    //            QuantLib::VanillaOption::results>(underlyingEngine));
    //    return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
    //        new QuantLib::QuantoEngine<QuantLib::ForwardVanillaOption::arguments,
    //            QuantLib::ForwardVanillaOption::results>(forwardEngine));
    //}

    /* *** PricingEngines - with timesteps *** */
    QuantLib::ext::shared_ptr<QuantLib::PricingEngine> AEQPB_Engine(
        const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process, const long& timeSteps) {
        return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
            new QuantLib::BinomialVanillaEngine<QuantLib::AdditiveEQPBinomialTree>(process, timeSteps));
    }
    QuantLib::ext::shared_ptr<QuantLib::PricingEngine> CRR_Engine(
        const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process, const long& timeSteps) {
        return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
            new QuantLib::BinomialVanillaEngine<QuantLib::CoxRossRubinstein>(process, timeSteps));
    }
    //QuantLib::ext::shared_ptr<QuantLib::PricingEngine> FDA_Engine(
    //    const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process, const long& timeSteps) {
    //    return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
    //        new QuantLib::FDAmericanEngine<>(process, timeSteps, timeSteps-1));
    //}
    //QuantLib::ext::shared_ptr<QuantLib::PricingEngine> FDB_Engine(
    //    const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process, const long& timeSteps) {
    //    return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
    //        new QuantLib::FDBermudanEngine<>(process, timeSteps, timeSteps-1));
   // }
   // QuantLib::ext::shared_ptr<QuantLib::PricingEngine> FDE_Engine(
   //     const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process, const long& timeSteps) {
   //     return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
   //         new QuantLib::FDEuropeanEngine<>(process, timeSteps, timeSteps-1));
   // }
    QuantLib::ext::shared_ptr<QuantLib::PricingEngine> JOSHI_Engine(
        const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process, const long& timeSteps) {
        return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
            new QuantLib::BinomialVanillaEngine<QuantLib::Joshi4>(process, timeSteps));
    }
    QuantLib::ext::shared_ptr<QuantLib::PricingEngine> JR_Engine(
        const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process, const long& timeSteps) {
        return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
            new QuantLib::BinomialVanillaEngine<QuantLib::JarrowRudd>(process, timeSteps));
    }
    QuantLib::ext::shared_ptr<QuantLib::PricingEngine> LR_Engine(
        const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process, const long& timeSteps) {
        return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
            new QuantLib::BinomialVanillaEngine<QuantLib::LeisenReimer>(process, timeSteps));
    }
    QuantLib::ext::shared_ptr<QuantLib::PricingEngine> TIAN_Engine(
        const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process, const long& timeSteps) {
        return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
            new QuantLib::BinomialVanillaEngine<QuantLib::Tian>(process, timeSteps));
    }
    QuantLib::ext::shared_ptr<QuantLib::PricingEngine> TRI_Engine(
        const QuantLib::ext::shared_ptr<QuantLib::GeneralizedBlackScholesProcess>& process, const long& timeSteps) {
        return QuantLib::ext::shared_ptr<QuantLib::PricingEngine> (
            new QuantLib::BinomialVanillaEngine<QuantLib::Trigeorgis>(process, timeSteps));
    }

    /* *** 1D Interpolation *** */
    QuantLib::ext::shared_ptr<QuantLib::Interpolation> BACKWARDFLAT_Interpolation(
                                            ObjectHandler::dbl_itr& xBegin,
                                            ObjectHandler::dbl_itr& xEnd,
                                            ObjectHandler::dbl_itr& yBegin) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new
            QuantLib::BackwardFlatInterpolation(xBegin, xEnd, yBegin));
    }
    QuantLib::ext::shared_ptr<QuantLib::Interpolation> FORWARDFLAT_Interpolation(
                                            ObjectHandler::dbl_itr& xBegin,
                                            ObjectHandler::dbl_itr& xEnd,
                                            ObjectHandler::dbl_itr& yBegin) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new
            QuantLib::ForwardFlatInterpolation(xBegin, xEnd, yBegin));
    }
    QuantLib::ext::shared_ptr<QuantLib::Interpolation> LINEAR_Interpolation(
                                            ObjectHandler::dbl_itr& xBegin,
                                            ObjectHandler::dbl_itr& xEnd,
                                            ObjectHandler::dbl_itr& yBegin) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new
            QuantLib::LinearInterpolation(xBegin, xEnd, yBegin));
    }
    QuantLib::ext::shared_ptr<QuantLib::Interpolation> LOGLINEAR_Interpolation(
                                            ObjectHandler::dbl_itr& xBegin,
                                            ObjectHandler::dbl_itr& xEnd,
                                            ObjectHandler::dbl_itr& yBegin) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new
            QuantLib::LogLinearInterpolation(xBegin, xEnd, yBegin));
    }
    QuantLib::ext::shared_ptr<QuantLib::Interpolation> CUBICNATURALSPLINE_Interpolation(
                                            ObjectHandler::dbl_itr& xBegin,
                                            ObjectHandler::dbl_itr& xEnd,
                                            ObjectHandler::dbl_itr& yBegin) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new
            QuantLib::CubicInterpolation(xBegin, xEnd, yBegin,
                                         QuantLib::CubicInterpolation::Spline, false,
                                         QuantLib::CubicInterpolation::SecondDerivative, 0.0,
                                         QuantLib::CubicInterpolation::SecondDerivative, 0.0));
    }
    QuantLib::ext::shared_ptr<QuantLib::Interpolation> MONOTONICCUBICNATURALSPLINE_Interpolation(
                                            ObjectHandler::dbl_itr& xBegin,
                                            ObjectHandler::dbl_itr& xEnd,
                                            ObjectHandler::dbl_itr& yBegin) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new
            QuantLib::CubicInterpolation(xBegin, xEnd, yBegin,
                                         QuantLib::CubicInterpolation::Spline, true,
                                         QuantLib::CubicInterpolation::SecondDerivative, 0.0,
                                         QuantLib::CubicInterpolation::SecondDerivative, 0.0));
    }
    QuantLib::ext::shared_ptr<QuantLib::Interpolation> LOGCUBICNATURALSPLINE_Interpolation(
                                            ObjectHandler::dbl_itr& xBegin,
                                            ObjectHandler::dbl_itr& xEnd,
                                            ObjectHandler::dbl_itr& yBegin) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new
            QuantLib::LogCubicInterpolation(xBegin, xEnd, yBegin,
                                            QuantLib::CubicInterpolation::Spline, false,
                                            QuantLib::CubicInterpolation::SecondDerivative, 0.0,
                                            QuantLib::CubicInterpolation::SecondDerivative, 0.0));
    }
    QuantLib::ext::shared_ptr<QuantLib::Interpolation> MONOTONICLOGCUBICNATURALSPLINE_Interpolation(
                                            ObjectHandler::dbl_itr& xBegin,
                                            ObjectHandler::dbl_itr& xEnd,
                                            ObjectHandler::dbl_itr& yBegin) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new
            QuantLib::LogCubicInterpolation(xBegin, xEnd, yBegin,
                                            QuantLib::CubicInterpolation::Spline, true,
                                            QuantLib::CubicInterpolation::SecondDerivative, 0.0,
                                            QuantLib::CubicInterpolation::SecondDerivative, 0.0));
    }
    QuantLib::ext::shared_ptr<QuantLib::Interpolation> KrugerCubic_Interpolation(
                                            ObjectHandler::dbl_itr& xBegin,
                                            ObjectHandler::dbl_itr& xEnd,
                                            ObjectHandler::dbl_itr& yBegin) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new
            QuantLib::CubicInterpolation(xBegin, xEnd, yBegin,
                                         QuantLib::CubicInterpolation::Kruger, false,
                                         QuantLib::CubicInterpolation::SecondDerivative, 0.0,
                                         QuantLib::CubicInterpolation::SecondDerivative, 0.0));
    }
    QuantLib::ext::shared_ptr<QuantLib::Interpolation> KrugerLogCubic_Interpolation(
                                            ObjectHandler::dbl_itr& xBegin,
                                            ObjectHandler::dbl_itr& xEnd,
                                            ObjectHandler::dbl_itr& yBegin) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new
            QuantLib::LogCubicInterpolation(xBegin, xEnd, yBegin,
                                            QuantLib::CubicInterpolation::Kruger, false,
                                            QuantLib::CubicInterpolation::SecondDerivative, 0.0,
                                            QuantLib::CubicInterpolation::SecondDerivative, 0.0));
    }
	QuantLib::ext::shared_ptr<QuantLib::Interpolation> HarmonicCubic_Interpolation(//added SH 2017.06.06
		ObjectHandler::dbl_itr& xBegin,
		ObjectHandler::dbl_itr& xEnd,
		ObjectHandler::dbl_itr& yBegin) {
		return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new
			QuantLib::CubicInterpolation(xBegin, xEnd, yBegin,
			QuantLib::CubicInterpolation::Harmonic, false,
			QuantLib::CubicInterpolation::SecondDerivative, 0.0,
			QuantLib::CubicInterpolation::SecondDerivative, 0.0));
	}
	QuantLib::ext::shared_ptr<QuantLib::Interpolation> HarmonicLogCubic_Interpolation(//added SH 2017.06.06
		ObjectHandler::dbl_itr& xBegin,
		ObjectHandler::dbl_itr& xEnd,
		ObjectHandler::dbl_itr& yBegin) {
		return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new
			QuantLib::LogCubicInterpolation(xBegin, xEnd, yBegin,
			QuantLib::CubicInterpolation::Harmonic, false,
			QuantLib::CubicInterpolation::SecondDerivative, 0.0,
			QuantLib::CubicInterpolation::SecondDerivative, 0.0));
	}
	QuantLib::ext::shared_ptr<QuantLib::Interpolation> FritschButlandCubic_Interpolation(
                                            ObjectHandler::dbl_itr& xBegin,
                                            ObjectHandler::dbl_itr& xEnd,
                                            ObjectHandler::dbl_itr& yBegin) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new
            QuantLib::CubicInterpolation(xBegin, xEnd, yBegin,
                                         QuantLib::CubicInterpolation::FritschButland, false,
                                         QuantLib::CubicInterpolation::SecondDerivative, 0.0,
                                         QuantLib::CubicInterpolation::SecondDerivative, 0.0));
    }
    QuantLib::ext::shared_ptr<QuantLib::Interpolation> FritschButlandLogCubic_Interpolation(
                                            ObjectHandler::dbl_itr& xBegin,
                                            ObjectHandler::dbl_itr& xEnd,
                                            ObjectHandler::dbl_itr& yBegin) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new
            QuantLib::LogCubicInterpolation(xBegin, xEnd, yBegin,
                                            QuantLib::CubicInterpolation::FritschButland, false,
                                            QuantLib::CubicInterpolation::SecondDerivative, 0.0,
                                            QuantLib::CubicInterpolation::SecondDerivative, 0.0));
    }
    QuantLib::ext::shared_ptr<QuantLib::Interpolation> Parabolic_Interpolation(
                                            ObjectHandler::dbl_itr& xBegin,
                                            ObjectHandler::dbl_itr& xEnd,
                                            ObjectHandler::dbl_itr& yBegin) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new
            QuantLib::CubicInterpolation(xBegin, xEnd, yBegin,
                                         QuantLib::CubicInterpolation::Parabolic, false,
                                         QuantLib::CubicInterpolation::SecondDerivative, 0.0,
                                         QuantLib::CubicInterpolation::SecondDerivative, 0.0));
    }
    QuantLib::ext::shared_ptr<QuantLib::Interpolation> MonotonicParabolic_Interpolation(
                                            ObjectHandler::dbl_itr& xBegin,
                                            ObjectHandler::dbl_itr& xEnd,
                                            ObjectHandler::dbl_itr& yBegin) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new
            QuantLib::CubicInterpolation(xBegin, xEnd, yBegin,
                                         QuantLib::CubicInterpolation::Parabolic, true,
                                         QuantLib::CubicInterpolation::SecondDerivative, 0.0,
                                         QuantLib::CubicInterpolation::SecondDerivative, 0.0));
    }
    QuantLib::ext::shared_ptr<QuantLib::Interpolation> LogParabolic_Interpolation(
                                            ObjectHandler::dbl_itr& xBegin,
                                            ObjectHandler::dbl_itr& xEnd,
                                            ObjectHandler::dbl_itr& yBegin) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new
            QuantLib::LogCubicInterpolation(xBegin, xEnd, yBegin,
                                            QuantLib::CubicInterpolation::Parabolic, false,
                                            QuantLib::CubicInterpolation::SecondDerivative, 0.0,
                                            QuantLib::CubicInterpolation::SecondDerivative, 0.0));
    }
    QuantLib::ext::shared_ptr<QuantLib::Interpolation> MonotonicLogParabolic_Interpolation(
                                            ObjectHandler::dbl_itr& xBegin,
                                            ObjectHandler::dbl_itr& xEnd,
                                            ObjectHandler::dbl_itr& yBegin) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new
            QuantLib::LogCubicInterpolation(xBegin, xEnd, yBegin,
                                            QuantLib::CubicInterpolation::Parabolic, true,
                                            QuantLib::CubicInterpolation::SecondDerivative, 0.0,
                                            QuantLib::CubicInterpolation::SecondDerivative, 0.0));
    }
    QuantLib::ext::shared_ptr<QuantLib::Interpolation> MixedLinearCubicNaturalSpline_Interpolation(
                                            ObjectHandler::dbl_itr& xBegin,
                                            ObjectHandler::dbl_itr& xEnd,
                                            ObjectHandler::dbl_itr& yBegin,
                                            QuantLib::MixedInterpolation::Behavior behavior,
                                            QuantLib::Size n) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new 
            QuantLib::MixedLinearCubicInterpolation(
                                            xBegin, xEnd, yBegin, n, behavior,
                                            QuantLib::CubicInterpolation::Spline, false,
                                            QuantLib::CubicInterpolation::SecondDerivative, 0.0,
                                            QuantLib::CubicInterpolation::SecondDerivative, 0.0));
    }
    QuantLib::ext::shared_ptr<QuantLib::Interpolation> LogMixedLinearCubicNaturalSpline_Interpolation(
                                            ObjectHandler::dbl_itr& xBegin,
                                            ObjectHandler::dbl_itr& xEnd,
                                            ObjectHandler::dbl_itr& yBegin,
                                            QuantLib::MixedInterpolation::Behavior behavior,
                                            QuantLib::Size n) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new
            QuantLib::LogMixedLinearCubicInterpolation(
                                            xBegin, xEnd, yBegin, n, behavior,
                                            QuantLib::CubicInterpolation::Spline, false,
                                            QuantLib::CubicInterpolation::SecondDerivative, 0.0,
                                            QuantLib::CubicInterpolation::SecondDerivative, 0.0));
    }
    QuantLib::ext::shared_ptr<QuantLib::Interpolation> MixedLinearMonotonicCubicNaturalSpline_Interpolation(
                                            ObjectHandler::dbl_itr& xBegin,
                                            ObjectHandler::dbl_itr& xEnd,
                                            ObjectHandler::dbl_itr& yBegin,
                                            QuantLib::MixedInterpolation::Behavior behavior,
                                            QuantLib::Size n) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new
            QuantLib::MixedLinearCubicInterpolation(
                                            xBegin, xEnd, yBegin, n, behavior,
                                            QuantLib::CubicInterpolation::Spline, true,
                                            QuantLib::CubicInterpolation::SecondDerivative, 0.0,
                                            QuantLib::CubicInterpolation::SecondDerivative, 0.0));
    }
    QuantLib::ext::shared_ptr<QuantLib::Interpolation> LogMixedLinearMonotonicCubicNaturalSpline_Interpolation(
                                            ObjectHandler::dbl_itr& xBegin,
                                            ObjectHandler::dbl_itr& xEnd,
                                            ObjectHandler::dbl_itr& yBegin,
                                            QuantLib::MixedInterpolation::Behavior behavior,
                                            QuantLib::Size n) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new
            QuantLib::LogMixedLinearCubicInterpolation(
                                            xBegin, xEnd, yBegin, n, behavior,
                                            QuantLib::CubicInterpolation::Spline, true,
                                            QuantLib::CubicInterpolation::SecondDerivative, 0.0,
                                            QuantLib::CubicInterpolation::SecondDerivative, 0.0));
    }
    QuantLib::ext::shared_ptr<QuantLib::Interpolation> MixedLinearKrugerCubic_Interpolation(
                                            ObjectHandler::dbl_itr& xBegin,
                                            ObjectHandler::dbl_itr& xEnd,
                                            ObjectHandler::dbl_itr& yBegin,
                                            QuantLib::MixedInterpolation::Behavior behavior,
                                            QuantLib::Size n) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new
            QuantLib::MixedLinearCubicInterpolation(
                                            xBegin, xEnd, yBegin, n, behavior,
                                            QuantLib::CubicInterpolation::Kruger, false,
                                            QuantLib::CubicInterpolation::SecondDerivative, 0.0,
                                            QuantLib::CubicInterpolation::SecondDerivative, 0.0));
    }
    QuantLib::ext::shared_ptr<QuantLib::Interpolation> LogMixedLinearKrugerCubic_Interpolation(
                                            ObjectHandler::dbl_itr& xBegin,
                                            ObjectHandler::dbl_itr& xEnd,
                                            ObjectHandler::dbl_itr& yBegin,
                                            QuantLib::MixedInterpolation::Behavior behavior,
                                            QuantLib::Size n) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new
            QuantLib::LogMixedLinearCubicInterpolation(
                                            xBegin, xEnd, yBegin, n, behavior,
                                            QuantLib::CubicInterpolation::Kruger, false,
                                            QuantLib::CubicInterpolation::SecondDerivative, 0.0,
                                            QuantLib::CubicInterpolation::SecondDerivative, 0.0));
    }
    QuantLib::ext::shared_ptr<QuantLib::Interpolation> ABCD_Interpolation(
                                            ObjectHandler::dbl_itr& xBegin,
                                            ObjectHandler::dbl_itr& xEnd,
                                            ObjectHandler::dbl_itr& yBegin) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation>(new
            QuantLib::AbcdInterpolation(xBegin, xEnd, yBegin));
    }


    /* *** Interpolation2D *** */
    QuantLib::ext::shared_ptr<QuantLib::Interpolation2D> BILINEAR_Interpolation(
            ObjectHandler::dbl_itr& xBegin, ObjectHandler::dbl_itr& xEnd, ObjectHandler::dbl_itr& yBegin, ObjectHandler::dbl_itr& yEnd,
            const QuantLib::Matrix& zData) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation2D>(
            new QuantLib::BilinearInterpolation(
                xBegin, xEnd, yBegin, yEnd, zData));
    }
    QuantLib::ext::shared_ptr<QuantLib::Interpolation2D> BICUBICSPLINE(
            ObjectHandler::dbl_itr& xBegin, ObjectHandler::dbl_itr& xEnd, ObjectHandler::dbl_itr& yBegin, ObjectHandler::dbl_itr& yEnd,
            const QuantLib::Matrix& zData) {
        return QuantLib::ext::shared_ptr<QuantLib::Interpolation2D>(
            new QuantLib::BicubicSpline(
                xBegin, xEnd, yBegin, yEnd, zData));
    }

    /* *** Pricers *** */
    /* *** IborCouponPricer *** */
    QuantLib::ext::shared_ptr<QuantLib::IborCouponPricer> IBOR_BY_BLACK_Pricer(
        const QuantLib::Handle<QuantLib::OptionletVolatilityStructure>& capletVol){
        return QuantLib::ext::shared_ptr<QuantLib::IborCouponPricer>(
            new QuantLib::BlackIborCouponPricer(capletVol));
    };
    /* *** CmsCouponPricer **** */
    QuantLib::ext::shared_ptr<QuantLib::CmsCouponPricer> CONUNDRUM_BY_BLACK_Pricer(
        const QuantLib::Handle<QuantLib::SwaptionVolatilityStructure>& swaptionVol,
        const QuantLib::GFunctionFactory::YieldCurveModel modelOfYieldCurve,
        const QuantLib::Handle<QuantLib::Quote>& meanReversion){
        return QuantLib::ext::shared_ptr<QuantLib::CmsCouponPricer>(
            new QuantLib::AnalyticHaganPricer(swaptionVol, modelOfYieldCurve, meanReversion));
    };
    QuantLib::ext::shared_ptr<QuantLib::CmsCouponPricer> CONUNDRUM_BY_NUMERICAL_INTEGRATION_Pricer(
        const QuantLib::Handle<QuantLib::SwaptionVolatilityStructure>& swaptionVol,
        const QuantLib::GFunctionFactory::YieldCurveModel modelOfYieldCurve,
        const QuantLib::Handle<QuantLib::Quote>& meanReversion){
        return QuantLib::ext::shared_ptr<QuantLib::CmsCouponPricer>(
            new QuantLib::NumericHaganPricer(swaptionVol, modelOfYieldCurve, meanReversion));
    };

}
