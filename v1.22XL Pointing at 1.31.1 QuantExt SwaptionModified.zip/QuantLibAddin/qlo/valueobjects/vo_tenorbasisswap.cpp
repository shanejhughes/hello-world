
/*  
 Copyright (C) 2005, 2006 Plamen Neykov
 Copyright (C) 2007 Eric Ehlers
 
 This file is part of QuantLib, a free-software/open-source library
 for financial quantitative analysts and developers - http://quantlib.org/

 QuantLib is free software: you can redistribute it and/or modify it
 under the terms of the QuantLib license.  You should have received a
 copy of the license along with this program; if not, please email
 <quantlib-dev@lists.sf.net>. The license is also available online at
 <http://quantlib.org/license.shtml>.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE.  See the license for more details.
*/

// This file was generated automatically by gensrc.py.  If you edit this file
// manually then your changes will be lost the next time gensrc runs.

// This source code file was generated from the following stub:
//      gensrc/gensrc/stubs/stub.vo.includes.body

#include <oh/ohdefines.hpp>
#include <qlo/tenorbasisswap.hpp>
#include <qlo/valueobjects/vo_tenorbasisswap.hpp>
#include <string>

namespace QuantLibAddin { namespace ValueObjects {

    const char* qlTenorBasisSwap::mPropertyNames[] = {
        // The two values below are not desired in the return value of ohObjectPropertyNames().
        // For now we just comment them out as this seems not to break anything.
        //"ClassName",
        //"ObjectId",
        "Nominal",
        "PayLongIndex",
        "LongIndexSchedule",
        "LongIborIndex",
        "LongIndexSpread",
        "ShortIndexSchedule",
        "ShortIborIndex",
        "ShortIndexSpread",
        "IncludeSpread",
        "AvergingCompounding",
        "Permanent"
    };

    std::set<std::string> qlTenorBasisSwap::mSystemPropertyNames(
        mPropertyNames, mPropertyNames + sizeof(mPropertyNames) / sizeof(const char*));

    const std::set<std::string>& qlTenorBasisSwap::getSystemPropertyNames() const {
        return mSystemPropertyNames;
    }

    std::vector<std::string> qlTenorBasisSwap::getPropertyNamesVector() const {
        std::vector<std::string> ret(
            mPropertyNames, mPropertyNames + sizeof(mPropertyNames) / sizeof(const char*));
        for (std::map<std::string, ObjectHandler::property_t>::const_iterator i = userProperties.begin();
            i != userProperties.end(); ++i)
            ret.push_back(i->first);
        return ret;
    }

    ObjectHandler::property_t qlTenorBasisSwap::getSystemProperty(const std::string& name) const {
        std::string nameUpper = boost::algorithm::to_upper_copy(name);
        if(strcmp(nameUpper.c_str(), "OBJECTID")==0)
            return objectId_;
        else if(strcmp(nameUpper.c_str(), "CLASSNAME")==0)
            return className_;
        else if(strcmp(nameUpper.c_str(), "NOMINAL")==0)
            return Nominal_;
        else if(strcmp(nameUpper.c_str(), "PAYLONGINDEX")==0)
            return PayLongIndex_;
        else if(strcmp(nameUpper.c_str(), "LONGINDEXSCHEDULE")==0)
            return LongIndexSchedule_;
        else if(strcmp(nameUpper.c_str(), "LONGIBORINDEX")==0)
            return LongIborIndex_;
        else if(strcmp(nameUpper.c_str(), "LONGINDEXSPREAD")==0)
            return LongIndexSpread_;
        else if(strcmp(nameUpper.c_str(), "SHORTINDEXSCHEDULE")==0)
            return ShortIndexSchedule_;
        else if(strcmp(nameUpper.c_str(), "SHORTIBORINDEX")==0)
            return ShortIborIndex_;
        else if(strcmp(nameUpper.c_str(), "SHORTINDEXSPREAD")==0)
            return ShortIndexSpread_;
        else if(strcmp(nameUpper.c_str(), "INCLUDESPREAD")==0)
            return IncludeSpread_;
        else if(strcmp(nameUpper.c_str(), "AVERGINGCOMPOUNDING")==0)
            return AvergingCompounding_;
        else if(strcmp(nameUpper.c_str(), "PERMANENT")==0)
            return Permanent_;
        else
            OH_FAIL("Error: attempt to retrieve non-existent Property: '" + name + "'");
    }

    void qlTenorBasisSwap::setSystemProperty(const std::string& name, const ObjectHandler::property_t& value) {
        std::string nameUpper = boost::algorithm::to_upper_copy(name);
        if(strcmp(nameUpper.c_str(), "OBJECTID")==0)
            objectId_ = boost::get<std::string>(value);
        else if(strcmp(nameUpper.c_str(), "CLASSNAME")==0)
            className_ = boost::get<std::string>(value);
        else if(strcmp(nameUpper.c_str(), "NOMINAL")==0)
            Nominal_ = ObjectHandler::convert2<double>(value);
        else if(strcmp(nameUpper.c_str(), "PAYLONGINDEX")==0)
            PayLongIndex_ = ObjectHandler::convert2<bool>(value);
        else if(strcmp(nameUpper.c_str(), "LONGINDEXSCHEDULE")==0)
            LongIndexSchedule_ = ObjectHandler::convert2<std::string>(value);
        else if(strcmp(nameUpper.c_str(), "LONGIBORINDEX")==0)
            LongIborIndex_ = ObjectHandler::convert2<std::string>(value);
        else if(strcmp(nameUpper.c_str(), "LONGINDEXSPREAD")==0)
            LongIndexSpread_ = ObjectHandler::convert2<double>(value);
        else if(strcmp(nameUpper.c_str(), "SHORTINDEXSCHEDULE")==0)
            ShortIndexSchedule_ = ObjectHandler::convert2<std::string>(value);
        else if(strcmp(nameUpper.c_str(), "SHORTIBORINDEX")==0)
            ShortIborIndex_ = ObjectHandler::convert2<std::string>(value);
        else if(strcmp(nameUpper.c_str(), "SHORTINDEXSPREAD")==0)
            ShortIndexSpread_ = ObjectHandler::convert2<double>(value);
        else if(strcmp(nameUpper.c_str(), "INCLUDESPREAD")==0)
            IncludeSpread_ = ObjectHandler::convert2<bool>(value);
        else if(strcmp(nameUpper.c_str(), "AVERGINGCOMPOUNDING")==0)
            AvergingCompounding_ = ObjectHandler::convert2<std::string>(value);
        else if(strcmp(nameUpper.c_str(), "PERMANENT")==0)
            Permanent_ = ObjectHandler::convert2<bool>(value);
        else
            OH_FAIL("Error: attempt to set non-existent Property: '" + name + "'");
    }

    qlTenorBasisSwap::qlTenorBasisSwap(
            const std::string& ObjectId,
            double Nominal,
            bool PayLongIndex,
            const std::string& LongIndexSchedule,
            const std::string& LongIborIndex,
            double LongIndexSpread,
            const std::string& ShortIndexSchedule,
            const std::string& ShortIborIndex,
            double ShortIndexSpread,
            bool IncludeSpread,
            const std::string& AvergingCompounding,
            bool Permanent) :
        ObjectHandler::ValueObject(ObjectId, "qlTenorBasisSwap", Permanent),
        Nominal_(Nominal),
        PayLongIndex_(PayLongIndex),
        LongIndexSchedule_(LongIndexSchedule),
        LongIborIndex_(LongIborIndex),
        LongIndexSpread_(LongIndexSpread),
        ShortIndexSchedule_(ShortIndexSchedule),
        ShortIborIndex_(ShortIborIndex),
        ShortIndexSpread_(ShortIndexSpread),
        IncludeSpread_(IncludeSpread),
        AvergingCompounding_(AvergingCompounding),
        Permanent_(Permanent) {
                  
            processPrecedentID(LongIndexSchedule);
            processPrecedentID(LongIborIndex);
            processPrecedentID(ShortIndexSchedule);
            processPrecedentID(ShortIborIndex);
            
    }

    const char* qlTenorBasisSwap2::mPropertyNames[] = {
        // The two values below are not desired in the return value of ohObjectPropertyNames().
        // For now we just comment them out as this seems not to break anything.
        //"ClassName",
        //"ObjectId",
        "EffectiveDate",
        "Nominal",
        "SwapTenor",
        "PayLongIndex",
        "LongIborIndex",
        "LongIndexSpread",
        "ShortIborIndex",
        "ShortIndexSpread",
        "ShortLegPaymentTenor",
        "DateGeneration",
        "IncludeSpread",
        "AvergingCompounding",
        "Permanent"
    };

    std::set<std::string> qlTenorBasisSwap2::mSystemPropertyNames(
        mPropertyNames, mPropertyNames + sizeof(mPropertyNames) / sizeof(const char*));

    const std::set<std::string>& qlTenorBasisSwap2::getSystemPropertyNames() const {
        return mSystemPropertyNames;
    }

    std::vector<std::string> qlTenorBasisSwap2::getPropertyNamesVector() const {
        std::vector<std::string> ret(
            mPropertyNames, mPropertyNames + sizeof(mPropertyNames) / sizeof(const char*));
        for (std::map<std::string, ObjectHandler::property_t>::const_iterator i = userProperties.begin();
            i != userProperties.end(); ++i)
            ret.push_back(i->first);
        return ret;
    }

    ObjectHandler::property_t qlTenorBasisSwap2::getSystemProperty(const std::string& name) const {
        std::string nameUpper = boost::algorithm::to_upper_copy(name);
        if(strcmp(nameUpper.c_str(), "OBJECTID")==0)
            return objectId_;
        else if(strcmp(nameUpper.c_str(), "CLASSNAME")==0)
            return className_;
        else if(strcmp(nameUpper.c_str(), "EFFECTIVEDATE")==0)
            return EffectiveDate_;
        else if(strcmp(nameUpper.c_str(), "NOMINAL")==0)
            return Nominal_;
        else if(strcmp(nameUpper.c_str(), "SWAPTENOR")==0)
            return SwapTenor_;
        else if(strcmp(nameUpper.c_str(), "PAYLONGINDEX")==0)
            return PayLongIndex_;
        else if(strcmp(nameUpper.c_str(), "LONGIBORINDEX")==0)
            return LongIborIndex_;
        else if(strcmp(nameUpper.c_str(), "LONGINDEXSPREAD")==0)
            return LongIndexSpread_;
        else if(strcmp(nameUpper.c_str(), "SHORTIBORINDEX")==0)
            return ShortIborIndex_;
        else if(strcmp(nameUpper.c_str(), "SHORTINDEXSPREAD")==0)
            return ShortIndexSpread_;
        else if(strcmp(nameUpper.c_str(), "SHORTLEGPAYMENTTENOR")==0)
            return ShortLegPaymentTenor_;
        else if(strcmp(nameUpper.c_str(), "DATEGENERATION")==0)
            return DateGeneration_;
        else if(strcmp(nameUpper.c_str(), "INCLUDESPREAD")==0)
            return IncludeSpread_;
        else if(strcmp(nameUpper.c_str(), "AVERGINGCOMPOUNDING")==0)
            return AvergingCompounding_;
        else if(strcmp(nameUpper.c_str(), "PERMANENT")==0)
            return Permanent_;
        else
            OH_FAIL("Error: attempt to retrieve non-existent Property: '" + name + "'");
    }

    void qlTenorBasisSwap2::setSystemProperty(const std::string& name, const ObjectHandler::property_t& value) {
        std::string nameUpper = boost::algorithm::to_upper_copy(name);
        if(strcmp(nameUpper.c_str(), "OBJECTID")==0)
            objectId_ = boost::get<std::string>(value);
        else if(strcmp(nameUpper.c_str(), "CLASSNAME")==0)
            className_ = boost::get<std::string>(value);
        else if(strcmp(nameUpper.c_str(), "EFFECTIVEDATE")==0)
            EffectiveDate_ = value;
        else if(strcmp(nameUpper.c_str(), "NOMINAL")==0)
            Nominal_ = ObjectHandler::convert2<double>(value);
        else if(strcmp(nameUpper.c_str(), "SWAPTENOR")==0)
            SwapTenor_ = ObjectHandler::convert2<std::string>(value);
        else if(strcmp(nameUpper.c_str(), "PAYLONGINDEX")==0)
            PayLongIndex_ = ObjectHandler::convert2<bool>(value);
        else if(strcmp(nameUpper.c_str(), "LONGIBORINDEX")==0)
            LongIborIndex_ = ObjectHandler::convert2<std::string>(value);
        else if(strcmp(nameUpper.c_str(), "LONGINDEXSPREAD")==0)
            LongIndexSpread_ = ObjectHandler::convert2<double>(value);
        else if(strcmp(nameUpper.c_str(), "SHORTIBORINDEX")==0)
            ShortIborIndex_ = ObjectHandler::convert2<std::string>(value);
        else if(strcmp(nameUpper.c_str(), "SHORTINDEXSPREAD")==0)
            ShortIndexSpread_ = ObjectHandler::convert2<double>(value);
        else if(strcmp(nameUpper.c_str(), "SHORTLEGPAYMENTTENOR")==0)
            ShortLegPaymentTenor_ = ObjectHandler::convert2<std::string>(value);
        else if(strcmp(nameUpper.c_str(), "DATEGENERATION")==0)
            DateGeneration_ = ObjectHandler::convert2<std::string>(value);
        else if(strcmp(nameUpper.c_str(), "INCLUDESPREAD")==0)
            IncludeSpread_ = ObjectHandler::convert2<bool>(value);
        else if(strcmp(nameUpper.c_str(), "AVERGINGCOMPOUNDING")==0)
            AvergingCompounding_ = ObjectHandler::convert2<std::string>(value);
        else if(strcmp(nameUpper.c_str(), "PERMANENT")==0)
            Permanent_ = ObjectHandler::convert2<bool>(value);
        else
            OH_FAIL("Error: attempt to set non-existent Property: '" + name + "'");
    }

    qlTenorBasisSwap2::qlTenorBasisSwap2(
            const std::string& ObjectId,
            const ObjectHandler::property_t& EffectiveDate,
            double Nominal,
            const std::string& SwapTenor,
            bool PayLongIndex,
            const std::string& LongIborIndex,
            double LongIndexSpread,
            const std::string& ShortIborIndex,
            double ShortIndexSpread,
            const std::string& ShortLegPaymentTenor,
            const std::string& DateGeneration,
            bool IncludeSpread,
            const std::string& AvergingCompounding,
            bool Permanent) :
        ObjectHandler::ValueObject(ObjectId, "qlTenorBasisSwap2", Permanent),
        EffectiveDate_(EffectiveDate),
        Nominal_(Nominal),
        SwapTenor_(SwapTenor),
        PayLongIndex_(PayLongIndex),
        LongIborIndex_(LongIborIndex),
        LongIndexSpread_(LongIndexSpread),
        ShortIborIndex_(ShortIborIndex),
        ShortIndexSpread_(ShortIndexSpread),
        ShortLegPaymentTenor_(ShortLegPaymentTenor),
        DateGeneration_(DateGeneration),
        IncludeSpread_(IncludeSpread),
        AvergingCompounding_(AvergingCompounding),
        Permanent_(Permanent) {
                  
            processPrecedentID(LongIborIndex);
            processPrecedentID(ShortIborIndex);
            
    }

 } }
