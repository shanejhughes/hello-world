/* -*- mode: c++; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*- */

/*
 Copyright (C) 2005, 2006 Eric Ehlers
 Copyright (C) 2006, 2011, 2015 Ferdinando Ametrano
 Copyright (C) 2005 Aurelien Chanudet
 Copyright (C) 2005 Plamen Neykov
 Copyright (C) 2006 Katiuscia Manzoni

 This file is part of QuantLib, a free-software/open-source library
 for financial quantitative analysts and developers - http://quantlib.org/

 QuantLib is free software: you can redistribute it and/or modify it
 under the terms of the QuantLib license.  You should have received a
 copy of the license along with this program; if not, please email
 <quantlib-dev@lists.sf.net>. The license is also available online at
 <http://quantlib.org/license.shtml>.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE.  See the license for more details.
*/

#if defined(HAVE_CONFIG_H)
    #include <qlo/config.hpp>
#endif

#include <qlo/oibasisswap.hpp>
#include <ql/instruments/oibasisswap.hpp>
#include <ql/instruments/oiccbasisswap.hpp>

using std::vector;
using boost::shared_ptr;
using ObjectHandler::ValueObject;
using ObjectHandler::property_t;

namespace QuantLibAddin {

	OvernightIndexedBasisSwap::OvernightIndexedBasisSwap(
		const boost::shared_ptr<ObjectHandler::ValueObject> properties,
		QuantLib::OvernightIndexedBasisSwap::Type type,
		QuantLib::Real nominal,
		const boost::shared_ptr<QuantLib::Schedule>& oisSchedule,
		const boost::shared_ptr<QuantLib::OvernightIndex>& oisIndex,
		const boost::shared_ptr<QuantLib::Schedule>& iborSchedule,
		const boost::shared_ptr<QuantLib::IborIndex>& iborIndex,
		QuantLib::Spread oisSpread,
		QuantLib::Spread iborSpread,
		bool permanent)
    : Swap(properties, permanent)
    {
        libraryObject_ = shared_ptr<QuantLib::Instrument>(new
            QuantLib::OvernightIndexedBasisSwap(
							type,
							nominal,
							*oisSchedule,
							oisIndex,
							*iborSchedule,
							iborIndex,
							oisSpread,
							iborSpread
			));
    }

	OvernightIndexedBasisSwap::OvernightIndexedBasisSwap(
		const boost::shared_ptr<ObjectHandler::ValueObject> properties,
		QuantLib::OvernightIndexedBasisSwap::Type type,
		std::vector<QuantLib::Real> nominals,
		const boost::shared_ptr<QuantLib::Schedule>& oisSchedule,
		const boost::shared_ptr<QuantLib::OvernightIndex>& oisIndex,
		const boost::shared_ptr<QuantLib::Schedule>& iborSchedule,
		const boost::shared_ptr<QuantLib::IborIndex>& iborIndex,
		QuantLib::Spread oisSpread,
		QuantLib::Spread iborSpread,
		bool permanent)
		: Swap(properties, permanent)
	{
		libraryObject_ = shared_ptr<QuantLib::Instrument>(new
			QuantLib::OvernightIndexedBasisSwap(
				type,
				nominals,
				*oisSchedule,
				oisIndex,
				*iborSchedule,
				iborIndex,
				oisSpread,
				iborSpread
			));
	}


	vector<vector<property_t> > OvernightIndexedBasisSwap::oisIndexLegAnalysis(
                                                    const QuantLib::Date& d) {
        return Swap::legAnalysis(0, d);
    }

    vector<vector<property_t> > OvernightIndexedBasisSwap::iborIndexLegAnalysis(
                                                    const QuantLib::Date& d) {
        return Swap::legAnalysis(1, d);
    }

	OvernightIndexedCrossCcyBasisSwap::OvernightIndexedCrossCcyBasisSwap(
		const boost::shared_ptr<ObjectHandler::ValueObject> properties,
		QuantLib::Real payNominal,
		QuantLib::Currency payCurrency,
		const boost::shared_ptr<QuantLib::Schedule>& paySchedule,
		const boost::shared_ptr<QuantLib::OvernightIndex>& payIndex,
		QuantLib::Real paySpread,
		QuantLib::Real recNominal,
		QuantLib::Currency recCurrency,
		const boost::shared_ptr<QuantLib::Schedule>& recSchedule,
		const boost::shared_ptr<QuantLib::OvernightIndex>& recIndex,
		QuantLib::Real recSpread,
		QuantLib::Natural paymentLag, 
		bool permanent)
		: Swap(properties, permanent)
	{
		libraryObject_ = boost::shared_ptr<QuantLib::Instrument>(new
			QuantLib::OvernightIndexedCrossCcyBasisSwap(
				payNominal,
				payCurrency,
				*paySchedule,
				payIndex,
				paySpread,
				recNominal,
				recCurrency,
				*recSchedule,
				recIndex,
				recSpread,
				paymentLag
			));
	}

	vector<vector<property_t> > OvernightIndexedCrossCcyBasisSwap::oisIndexPayLegAnalysis(
		const QuantLib::Date& d) {
		return Swap::legAnalysis(0, d);
	}

	vector<vector<property_t> > OvernightIndexedCrossCcyBasisSwap::oisIndexRecLegAnalysis(
		const QuantLib::Date& d) {
		return Swap::legAnalysis(1, d);
	}


}
