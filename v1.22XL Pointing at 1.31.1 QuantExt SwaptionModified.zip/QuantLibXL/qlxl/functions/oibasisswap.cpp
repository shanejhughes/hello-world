
/*  
 Copyright (C) 2006, 2007, 2011, 2015 Ferdinando Ametrano
 Copyright (C) 2005, 2006 Eric Ehlers
 Copyright (C) 2005 Plamen Neykov
 Copyright (C) 2005 Aurelien Chanudet
 
 This file is part of QuantLib, a free-software/open-source library
 for financial quantitative analysts and developers - http://quantlib.org/

 QuantLib is free software: you can redistribute it and/or modify it
 under the terms of the QuantLib license.  You should have received a
 copy of the license along with this program; if not, please email
 <quantlib-dev@lists.sf.net>. The license is also available online at
 <http://quantlib.org/license.shtml>.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE.  See the license for more details.
*/

// This file was generated automatically by gensrc.py.  If you edit this file
// manually then your changes will be lost the next time gensrc runs.

// This source code file was generated from the following stub:
//      QuantLibAddin/gensrc/stubs/stub.excel.includes

#include <qlo/qladdindefines.hpp>
#include <oh/enumerations/typefactory.hpp>
#include <qlo/oibasisswap.hpp>
#include <qlo/indexes/iborindex.hpp>
#include <qlo/schedule.hpp>
#include <qlo/pricingengines.hpp>
#include <qlo/termstructures.hpp>
#include <ql/indexes/iborindex.hpp>
#include <ql/termstructures/yield/ratehelpers.hpp>
#include <qlo/valueobjects/vo_oibasisswap.hpp>

#include <ohxl/objecthandlerxl.hpp>
#include <ohxl/callingrange.hpp>
#include <qlxl/session.hpp>
#include <qlxl/conversions/all.hpp>

#define XLL_DEC DLLEXPORT

XLL_DEC char *qlOvernightIndexedBasisAmortizingSwap(
        char *ObjectId,
        OPER *PayerReceiver,
        OPER *Nominal,
        char *OISIndexSchedule,
        char *OisIndex,
        char *IborIndexSchedule,
        char *IborIndex,
        OPER *OISIndexSpread,
        OPER *IborIndexSpread,
        OPER *Permanent,
        OPER *Trigger,
        bool *Overwrite) {

    // declare a shared pointer to the Function Call object

    boost::shared_ptr<ObjectHandler::FunctionCall> functionCall;

    try {

        // instantiate the Function Call object

        functionCall = boost::shared_ptr<ObjectHandler::FunctionCall>(
            new ObjectHandler::FunctionCall("qlOvernightIndexedBasisAmortizingSwap"));

        ObjectHandler::validateRange(Trigger, "Trigger");

        // initialize the session ID (if enabled)

        SET_SESSION_ID

        // convert input datatypes to C++ datatypes

        std::string PayerReceiverCpp = ObjectHandler::convert2<std::string>(
            ObjectHandler::ConvertOper(*PayerReceiver), "PayerReceiver", "Payer");

        std::vector<double> NominalCpp =
            ObjectHandler::operToVector<double>(*Nominal, "Nominal");

        double OISIndexSpreadCpp = ObjectHandler::convert2<double>(
            ObjectHandler::ConvertOper(*OISIndexSpread), "OISIndexSpread", 0.0);

        double IborIndexSpreadCpp = ObjectHandler::convert2<double>(
            ObjectHandler::ConvertOper(*IborIndexSpread), "IborIndexSpread", 0.0);

        bool PermanentCpp = ObjectHandler::convert2<bool>(
            ObjectHandler::ConvertOper(*Permanent), "Permanent", false);

        // convert input datatypes to QuantLib datatypes

        std::vector<QuantLib::Real> NominalLib =
            ObjectHandler::operToVector<QuantLib::Real>(*Nominal, "Nominal");

        // convert input datatypes to QuantLib enumerated datatypes

        QuantLib::OvernightIndexedBasisSwap::Type PayerReceiverEnum =
            ObjectHandler::Create<QuantLib::OvernightIndexedBasisSwap::Type>()(PayerReceiverCpp);

        // convert object IDs into library objects

        OH_GET_REFERENCE(OISIndexScheduleLibObjPtr, OISIndexSchedule,
            QuantLibAddin::Schedule, QuantLib::Schedule)

        OH_GET_REFERENCE(OisIndexLibObjPtr, OisIndex,
            QuantLibAddin::OvernightIndex, QuantLib::OvernightIndex)

        OH_GET_REFERENCE(IborIndexScheduleLibObjPtr, IborIndexSchedule,
            QuantLibAddin::Schedule, QuantLib::Schedule)

        OH_GET_REFERENCE(IborIndexLibObjPtr, IborIndex,
            QuantLibAddin::IborIndex, QuantLib::IborIndex)

        // Strip the Excel cell update counter suffix from Object IDs
        
        std::string ObjectIdStrip = ObjectHandler::CallingRange::getStub(ObjectId);
        std::string OISIndexScheduleStrip = ObjectHandler::CallingRange::getStub(OISIndexSchedule);
        std::string OisIndexStrip = ObjectHandler::CallingRange::getStub(OisIndex);
        std::string IborIndexScheduleStrip = ObjectHandler::CallingRange::getStub(IborIndexSchedule);
        std::string IborIndexStrip = ObjectHandler::CallingRange::getStub(IborIndex);

        // Construct the Value Object

        boost::shared_ptr<ObjectHandler::ValueObject> valueObject(
            new QuantLibAddin::ValueObjects::qlOvernightIndexedBasisAmortizingSwap(
                ObjectIdStrip,
                PayerReceiverCpp,
                NominalCpp,
                OISIndexScheduleStrip,
                OisIndexStrip,
                IborIndexScheduleStrip,
                IborIndexStrip,
                OISIndexSpreadCpp,
                IborIndexSpreadCpp,
                PermanentCpp));

        // Construct the Object
        
        boost::shared_ptr<ObjectHandler::Object> object(
            new QuantLibAddin::OvernightIndexedBasisSwap(
                valueObject,
                PayerReceiverEnum,
                NominalLib,
                OISIndexScheduleLibObjPtr,
                OisIndexLibObjPtr,
                IborIndexScheduleLibObjPtr,
                IborIndexLibObjPtr,
                OISIndexSpreadCpp,
                IborIndexSpreadCpp,
                PermanentCpp));

        // Store the Object in the Repository

        std::string returnValue =
            ObjectHandler::RepositoryXL::instance().storeObject(ObjectIdStrip, object, *Overwrite, valueObject);

        // Convert and return the return value

        static char ret[XL_MAX_STR_LEN];
        ObjectHandler::stringToChar(returnValue, ret);
        return ret;

    } catch (const std::exception &e) {
        ObjectHandler::RepositoryXL::instance().logError(e.what(), functionCall);
        return 0;
    } catch (...) {
        ObjectHandler::RepositoryXL::instance().logError("unkown error type", functionCall);
        return 0;
    }

}
XLL_DEC char *qlOvernightIndexedBasisSwap(
        char *ObjectId,
        OPER *PayerReceiver,
        OPER *Nominal,
        char *OISIndexSchedule,
        char *OisIndex,
        char *IborIndexSchedule,
        char *IborIndex,
        OPER *OISIndexSpread,
        OPER *IborIndexSpread,
        OPER *Permanent,
        OPER *Trigger,
        bool *Overwrite) {

    // declare a shared pointer to the Function Call object

    boost::shared_ptr<ObjectHandler::FunctionCall> functionCall;

    try {

        // instantiate the Function Call object

        functionCall = boost::shared_ptr<ObjectHandler::FunctionCall>(
            new ObjectHandler::FunctionCall("qlOvernightIndexedBasisSwap"));

        ObjectHandler::validateRange(Trigger, "Trigger");

        // initialize the session ID (if enabled)

        SET_SESSION_ID

        // convert input datatypes to C++ datatypes

        std::string PayerReceiverCpp = ObjectHandler::convert2<std::string>(
            ObjectHandler::ConvertOper(*PayerReceiver), "PayerReceiver", "Payer");

        double NominalCpp = ObjectHandler::convert2<double>(
            ObjectHandler::ConvertOper(*Nominal), "Nominal", 100);

        double OISIndexSpreadCpp = ObjectHandler::convert2<double>(
            ObjectHandler::ConvertOper(*OISIndexSpread), "OISIndexSpread", 0.0);

        double IborIndexSpreadCpp = ObjectHandler::convert2<double>(
            ObjectHandler::ConvertOper(*IborIndexSpread), "IborIndexSpread", 0.0);

        bool PermanentCpp = ObjectHandler::convert2<bool>(
            ObjectHandler::ConvertOper(*Permanent), "Permanent", false);

        // convert input datatypes to QuantLib datatypes

        QuantLib::Real NominalLib = ObjectHandler::convert2<QuantLib::Real>(
            ObjectHandler::ConvertOper(*Nominal), "Nominal", 100);

        // convert input datatypes to QuantLib enumerated datatypes

        QuantLib::OvernightIndexedBasisSwap::Type PayerReceiverEnum =
            ObjectHandler::Create<QuantLib::OvernightIndexedBasisSwap::Type>()(PayerReceiverCpp);

        // convert object IDs into library objects

        OH_GET_REFERENCE(OISIndexScheduleLibObjPtr, OISIndexSchedule,
            QuantLibAddin::Schedule, QuantLib::Schedule)

        OH_GET_REFERENCE(OisIndexLibObjPtr, OisIndex,
            QuantLibAddin::OvernightIndex, QuantLib::OvernightIndex)

        OH_GET_REFERENCE(IborIndexScheduleLibObjPtr, IborIndexSchedule,
            QuantLibAddin::Schedule, QuantLib::Schedule)

        OH_GET_REFERENCE(IborIndexLibObjPtr, IborIndex,
            QuantLibAddin::IborIndex, QuantLib::IborIndex)

        // Strip the Excel cell update counter suffix from Object IDs
        
        std::string ObjectIdStrip = ObjectHandler::CallingRange::getStub(ObjectId);
        std::string OISIndexScheduleStrip = ObjectHandler::CallingRange::getStub(OISIndexSchedule);
        std::string OisIndexStrip = ObjectHandler::CallingRange::getStub(OisIndex);
        std::string IborIndexScheduleStrip = ObjectHandler::CallingRange::getStub(IborIndexSchedule);
        std::string IborIndexStrip = ObjectHandler::CallingRange::getStub(IborIndex);

        // Construct the Value Object

        boost::shared_ptr<ObjectHandler::ValueObject> valueObject(
            new QuantLibAddin::ValueObjects::qlOvernightIndexedBasisSwap(
                ObjectIdStrip,
                PayerReceiverCpp,
                NominalCpp,
                OISIndexScheduleStrip,
                OisIndexStrip,
                IborIndexScheduleStrip,
                IborIndexStrip,
                OISIndexSpreadCpp,
                IborIndexSpreadCpp,
                PermanentCpp));

        // Construct the Object
        
        boost::shared_ptr<ObjectHandler::Object> object(
            new QuantLibAddin::OvernightIndexedBasisSwap(
                valueObject,
                PayerReceiverEnum,
                NominalLib,
                OISIndexScheduleLibObjPtr,
                OisIndexLibObjPtr,
                IborIndexScheduleLibObjPtr,
                IborIndexLibObjPtr,
                OISIndexSpreadCpp,
                IborIndexSpreadCpp,
                PermanentCpp));

        // Store the Object in the Repository

        std::string returnValue =
            ObjectHandler::RepositoryXL::instance().storeObject(ObjectIdStrip, object, *Overwrite, valueObject);

        // Convert and return the return value

        static char ret[XL_MAX_STR_LEN];
        ObjectHandler::stringToChar(returnValue, ret);
        return ret;

    } catch (const std::exception &e) {
        ObjectHandler::RepositoryXL::instance().logError(e.what(), functionCall);
        return 0;
    } catch (...) {
        ObjectHandler::RepositoryXL::instance().logError("unkown error type", functionCall);
        return 0;
    }

}
XLL_DEC double *qlOvernightIndexedBasisSwapIborLegBPS(
        char *ObjectId,
        OPER *Trigger) {

    // declare a shared pointer to the Function Call object

    boost::shared_ptr<ObjectHandler::FunctionCall> functionCall;

    try {

        // instantiate the Function Call object

        functionCall = boost::shared_ptr<ObjectHandler::FunctionCall>(
            new ObjectHandler::FunctionCall("qlOvernightIndexedBasisSwapIborLegBPS"));

        ObjectHandler::validateRange(Trigger, "Trigger");

        // initialize the session ID (if enabled)

        SET_SESSION_ID

        // convert object IDs into library objects

        OH_GET_REFERENCE(ObjectIdLibObjPtr, ObjectId,
            QuantLibAddin::OvernightIndexedBasisSwap, QuantLib::OvernightIndexedBasisSwap)

        // invoke the member function

        static double returnValue;
        returnValue = ObjectIdLibObjPtr->iborLegBPS();

        // convert and return the return value

        return &returnValue;

    } catch (const std::exception &e) {
        ObjectHandler::RepositoryXL::instance().logError(e.what(), functionCall);
        return 0;
    } catch (...) {
        ObjectHandler::RepositoryXL::instance().logError("unkown error type", functionCall);
        return 0;
    }

}
XLL_DEC double *qlOvernightIndexedBasisSwapIborLegFairOvernightSpread(
        char *ObjectId,
        OPER *Trigger) {

    // declare a shared pointer to the Function Call object

    boost::shared_ptr<ObjectHandler::FunctionCall> functionCall;

    try {

        // instantiate the Function Call object

        functionCall = boost::shared_ptr<ObjectHandler::FunctionCall>(
            new ObjectHandler::FunctionCall("qlOvernightIndexedBasisSwapIborLegFairOvernightSpread"));

        ObjectHandler::validateRange(Trigger, "Trigger");

        // initialize the session ID (if enabled)

        SET_SESSION_ID

        // convert object IDs into library objects

        OH_GET_REFERENCE(ObjectIdLibObjPtr, ObjectId,
            QuantLibAddin::OvernightIndexedBasisSwap, QuantLib::OvernightIndexedBasisSwap)

        // invoke the member function

        static double returnValue;
        returnValue = ObjectIdLibObjPtr->fairIborSpread();

        // convert and return the return value

        return &returnValue;

    } catch (const std::exception &e) {
        ObjectHandler::RepositoryXL::instance().logError(e.what(), functionCall);
        return 0;
    } catch (...) {
        ObjectHandler::RepositoryXL::instance().logError("unkown error type", functionCall);
        return 0;
    }

}
XLL_DEC double *qlOvernightIndexedBasisSwapIborLegNPV(
        char *ObjectId,
        OPER *Trigger) {

    // declare a shared pointer to the Function Call object

    boost::shared_ptr<ObjectHandler::FunctionCall> functionCall;

    try {

        // instantiate the Function Call object

        functionCall = boost::shared_ptr<ObjectHandler::FunctionCall>(
            new ObjectHandler::FunctionCall("qlOvernightIndexedBasisSwapIborLegNPV"));

        ObjectHandler::validateRange(Trigger, "Trigger");

        // initialize the session ID (if enabled)

        SET_SESSION_ID

        // convert object IDs into library objects

        OH_GET_REFERENCE(ObjectIdLibObjPtr, ObjectId,
            QuantLibAddin::OvernightIndexedBasisSwap, QuantLib::OvernightIndexedBasisSwap)

        // invoke the member function

        static double returnValue;
        returnValue = ObjectIdLibObjPtr->iborLegNPV();

        // convert and return the return value

        return &returnValue;

    } catch (const std::exception &e) {
        ObjectHandler::RepositoryXL::instance().logError(e.what(), functionCall);
        return 0;
    } catch (...) {
        ObjectHandler::RepositoryXL::instance().logError("unkown error type", functionCall);
        return 0;
    }

}
XLL_DEC double *qlOvernightIndexedBasisSwapIborSpread(
        char *ObjectId,
        OPER *Trigger) {

    // declare a shared pointer to the Function Call object

    boost::shared_ptr<ObjectHandler::FunctionCall> functionCall;

    try {

        // instantiate the Function Call object

        functionCall = boost::shared_ptr<ObjectHandler::FunctionCall>(
            new ObjectHandler::FunctionCall("qlOvernightIndexedBasisSwapIborSpread"));

        ObjectHandler::validateRange(Trigger, "Trigger");

        // initialize the session ID (if enabled)

        SET_SESSION_ID

        // convert object IDs into library objects

        OH_GET_REFERENCE(ObjectIdLibObjPtr, ObjectId,
            QuantLibAddin::OvernightIndexedBasisSwap, QuantLib::OvernightIndexedBasisSwap)

        // invoke the member function

        static double returnValue;
        returnValue = ObjectIdLibObjPtr->iborSpread();

        // convert and return the return value

        return &returnValue;

    } catch (const std::exception &e) {
        ObjectHandler::RepositoryXL::instance().logError(e.what(), functionCall);
        return 0;
    } catch (...) {
        ObjectHandler::RepositoryXL::instance().logError("unkown error type", functionCall);
        return 0;
    }

}
XLL_DEC double *qlOvernightIndexedBasisSwapNominal(
        char *ObjectId,
        OPER *Trigger) {

    // declare a shared pointer to the Function Call object

    boost::shared_ptr<ObjectHandler::FunctionCall> functionCall;

    try {

        // instantiate the Function Call object

        functionCall = boost::shared_ptr<ObjectHandler::FunctionCall>(
            new ObjectHandler::FunctionCall("qlOvernightIndexedBasisSwapNominal"));

        ObjectHandler::validateRange(Trigger, "Trigger");

        // initialize the session ID (if enabled)

        SET_SESSION_ID

        // convert object IDs into library objects

        OH_GET_REFERENCE(ObjectIdLibObjPtr, ObjectId,
            QuantLibAddin::OvernightIndexedBasisSwap, QuantLib::OvernightIndexedBasisSwap)

        // invoke the member function

        static double returnValue;
        returnValue = ObjectIdLibObjPtr->nominal();

        // convert and return the return value

        return &returnValue;

    } catch (const std::exception &e) {
        ObjectHandler::RepositoryXL::instance().logError(e.what(), functionCall);
        return 0;
    } catch (...) {
        ObjectHandler::RepositoryXL::instance().logError("unkown error type", functionCall);
        return 0;
    }

}
XLL_DEC double *qlOvernightIndexedBasisSwapOisLegBPS(
        char *ObjectId,
        OPER *Trigger) {

    // declare a shared pointer to the Function Call object

    boost::shared_ptr<ObjectHandler::FunctionCall> functionCall;

    try {

        // instantiate the Function Call object

        functionCall = boost::shared_ptr<ObjectHandler::FunctionCall>(
            new ObjectHandler::FunctionCall("qlOvernightIndexedBasisSwapOisLegBPS"));

        ObjectHandler::validateRange(Trigger, "Trigger");

        // initialize the session ID (if enabled)

        SET_SESSION_ID

        // convert object IDs into library objects

        OH_GET_REFERENCE(ObjectIdLibObjPtr, ObjectId,
            QuantLibAddin::OvernightIndexedBasisSwap, QuantLib::OvernightIndexedBasisSwap)

        // invoke the member function

        static double returnValue;
        returnValue = ObjectIdLibObjPtr->overnightLegBPS();

        // convert and return the return value

        return &returnValue;

    } catch (const std::exception &e) {
        ObjectHandler::RepositoryXL::instance().logError(e.what(), functionCall);
        return 0;
    } catch (...) {
        ObjectHandler::RepositoryXL::instance().logError("unkown error type", functionCall);
        return 0;
    }

}
XLL_DEC double *qlOvernightIndexedBasisSwapOisLegFairOvernightSpread(
        char *ObjectId,
        OPER *Trigger) {

    // declare a shared pointer to the Function Call object

    boost::shared_ptr<ObjectHandler::FunctionCall> functionCall;

    try {

        // instantiate the Function Call object

        functionCall = boost::shared_ptr<ObjectHandler::FunctionCall>(
            new ObjectHandler::FunctionCall("qlOvernightIndexedBasisSwapOisLegFairOvernightSpread"));

        ObjectHandler::validateRange(Trigger, "Trigger");

        // initialize the session ID (if enabled)

        SET_SESSION_ID

        // convert object IDs into library objects

        OH_GET_REFERENCE(ObjectIdLibObjPtr, ObjectId,
            QuantLibAddin::OvernightIndexedBasisSwap, QuantLib::OvernightIndexedBasisSwap)

        // invoke the member function

        static double returnValue;
        returnValue = ObjectIdLibObjPtr->fairOvernightSpread();

        // convert and return the return value

        return &returnValue;

    } catch (const std::exception &e) {
        ObjectHandler::RepositoryXL::instance().logError(e.what(), functionCall);
        return 0;
    } catch (...) {
        ObjectHandler::RepositoryXL::instance().logError("unkown error type", functionCall);
        return 0;
    }

}
XLL_DEC double *qlOvernightIndexedBasisSwapOisLegNPV(
        char *ObjectId,
        OPER *Trigger) {

    // declare a shared pointer to the Function Call object

    boost::shared_ptr<ObjectHandler::FunctionCall> functionCall;

    try {

        // instantiate the Function Call object

        functionCall = boost::shared_ptr<ObjectHandler::FunctionCall>(
            new ObjectHandler::FunctionCall("qlOvernightIndexedBasisSwapOisLegNPV"));

        ObjectHandler::validateRange(Trigger, "Trigger");

        // initialize the session ID (if enabled)

        SET_SESSION_ID

        // convert object IDs into library objects

        OH_GET_REFERENCE(ObjectIdLibObjPtr, ObjectId,
            QuantLibAddin::OvernightIndexedBasisSwap, QuantLib::OvernightIndexedBasisSwap)

        // invoke the member function

        static double returnValue;
        returnValue = ObjectIdLibObjPtr->overnightLegNPV();

        // convert and return the return value

        return &returnValue;

    } catch (const std::exception &e) {
        ObjectHandler::RepositoryXL::instance().logError(e.what(), functionCall);
        return 0;
    } catch (...) {
        ObjectHandler::RepositoryXL::instance().logError("unkown error type", functionCall);
        return 0;
    }

}
XLL_DEC double *qlOvernightIndexedBasisSwapOisSpread(
        char *ObjectId,
        OPER *Trigger) {

    // declare a shared pointer to the Function Call object

    boost::shared_ptr<ObjectHandler::FunctionCall> functionCall;

    try {

        // instantiate the Function Call object

        functionCall = boost::shared_ptr<ObjectHandler::FunctionCall>(
            new ObjectHandler::FunctionCall("qlOvernightIndexedBasisSwapOisSpread"));

        ObjectHandler::validateRange(Trigger, "Trigger");

        // initialize the session ID (if enabled)

        SET_SESSION_ID

        // convert object IDs into library objects

        OH_GET_REFERENCE(ObjectIdLibObjPtr, ObjectId,
            QuantLibAddin::OvernightIndexedBasisSwap, QuantLib::OvernightIndexedBasisSwap)

        // invoke the member function

        static double returnValue;
        returnValue = ObjectIdLibObjPtr->oisSpread();

        // convert and return the return value

        return &returnValue;

    } catch (const std::exception &e) {
        ObjectHandler::RepositoryXL::instance().logError(e.what(), functionCall);
        return 0;
    } catch (...) {
        ObjectHandler::RepositoryXL::instance().logError("unkown error type", functionCall);
        return 0;
    }

}
XLL_DEC char *qlOvernightIndexedBasisSwapType(
        char *ObjectId,
        OPER *Trigger) {

    // declare a shared pointer to the Function Call object

    boost::shared_ptr<ObjectHandler::FunctionCall> functionCall;

    try {

        // instantiate the Function Call object

        functionCall = boost::shared_ptr<ObjectHandler::FunctionCall>(
            new ObjectHandler::FunctionCall("qlOvernightIndexedBasisSwapType"));

        ObjectHandler::validateRange(Trigger, "Trigger");

        // initialize the session ID (if enabled)

        SET_SESSION_ID

        // convert object IDs into library objects

        OH_GET_REFERENCE(ObjectIdLibObjPtr, ObjectId,
            QuantLibAddin::OvernightIndexedBasisSwap, QuantLib::OvernightIndexedBasisSwap)

        // invoke the member function

        QuantLib::OvernightIndexedBasisSwap::Type returnValue = ObjectIdLibObjPtr->type();

        // convert and return the return value

        std::ostringstream os;
        os << returnValue;
        static char ret[XL_MAX_STR_LEN];
        ObjectHandler::stringToChar(os.str(), ret);
        return ret;

    } catch (const std::exception &e) {
        ObjectHandler::RepositoryXL::instance().logError(e.what(), functionCall);
        return 0;
    } catch (...) {
        ObjectHandler::RepositoryXL::instance().logError("unkown error type", functionCall);
        return 0;
    }

}
