#!/bin/bash
./instrument_in 40546 Swap Swap.xml MarketData.xml
