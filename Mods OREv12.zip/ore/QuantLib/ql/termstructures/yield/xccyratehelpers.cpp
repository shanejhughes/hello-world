/* -*- mode: c++; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*- */

/*
  Copyright (C) 2012 Andre Miemiec
  Copyright (C) 2012 Mehdi Bouassab
 

 This file is part of QuantLib, a free-software/open-source library
 for financial quantitative analysts and developers - http://quantlib.org/

 QuantLib is free software: you can redistribute it and/or modify it
 under the terms of the QuantLib license.  You should have received a
 copy of the license along with this program; if not, please email
 <quantlib-dev@lists.sf.net>. The license is also available online at
 <http://quantlib.org/license.shtml>.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE.  See the license for more details.
*/

//#include <C:\Work Here\QuantLib\Project\FX_Basis_Calibration\SH_xccyratehelper.hpp>
//#include <D:\Quantlib\Project\CurveConstruction\IntRateCurve\IntRateCurve\SH_xccyratehelper.hpp>
#include <ql/termstructures/yield/xccyratehelpers.hpp>
#include <ql/quote.hpp>
#include <ql/currency.hpp>
#include <ql/cashflows/cashflows.hpp>
//#include <ql/quantlib.hpp>
#include <ql/utilities/null_deleter.hpp>
using boost::shared_ptr;

namespace QuantLib {

//    namespace {
//       void no_deletion(YieldTermStructure*) {}
//    }


		XCCySwapRateHelper::XCCySwapRateHelper( const Handle<Quote>& spread,
		const Period& tenor,
		//floating leg...the leg that has the spread applied
		Rate   fxSpot, 
		const Currency& floatLegCurrency,
		const Calendar& floatLegCalendar,
		const BusinessDayConvention& floatLegConvention,
		const DayCounter& floatLegDayCount,
		const boost::shared_ptr<IborIndex>& floatLegIborIndex,

		//fixed leg...the leg that is IBOR flat...typically USD
		const Currency& fixedLegCurrency,
		const Calendar& fixedLegCalendar,
		const BusinessDayConvention& fixedLegConvention,
		const DayCounter& fixedLegDayCount,
		const boost::shared_ptr<IborIndex>& fixedLegIborIndex,
		//term structures...discountcurves
		const Handle<YieldTermStructure>& floatLegDiscTermStructureHandle,
		const Handle<YieldTermStructure>& fixedLegDiscTermStructureHandle,
		//Projection Curves
		const Handle<YieldTermStructure>& floatLegProjTermStructureHandle,
		const Handle<YieldTermStructure>& fixedLegProjTermStructureHandle,
		//general
		Type discCurveBootstrapType,
		const Period fwdStart,
		const Real fxFwd)
: RelativeDateRateHelper(spread), fwdStart_(fwdStart), swapTerm_(tenor),
  discCurveBootstrapType_(discCurveBootstrapType), fxSpot_(fxSpot),
  fxFwd_(fxFwd),
      
	  floatLegCurrency_(floatLegCurrency),
	floatLegCalendar_(floatLegCalendar),
	floatLegConvention_(floatLegConvention),
	  floatLegDayCount_(floatLegDayCount),
	  floatLegDiscTermStructureHandle_(floatLegDiscTermStructureHandle),
	  floatLegProjTermStructureHandle_(floatLegProjTermStructureHandle),

	  fixedLegCurrency_(fixedLegCurrency),
		fixedLegCalendar_(fixedLegCalendar),
  fixedLegConvention_(fixedLegConvention),
	  fixedLegDayCount_(fixedLegDayCount),
	  fixedLegDiscTermStructureHandle_(fixedLegDiscTermStructureHandle),
	  fixedLegProjTermStructureHandle_(fixedLegProjTermStructureHandle)

	{

	/*	fixedLegIborIndex_ = fixedLegIborIndex->clone(fixedLegDiscRelinkableHandle_);
		fixedLegIborIndex_->unregisterWith(fixedLegDiscRelinkableHandle_);
		

		floatLegIborIndex_ = floatLegIborIndex->clone(floatLegDiscRelinkableHandle_);
		floatLegIborIndex_->unregisterWith(floatLegDiscRelinkableHandle_);*/
		fixedLegIborIndex_ = fixedLegIborIndex->clone(fixedLegProjTermStructureHandle_);
		fixedLegIborIndex_->unregisterWith(fixedLegProjTermStructureHandle_);

		floatLegIborIndex_ = floatLegIborIndex->clone(floatLegProjTermStructureHandle_);
		floatLegIborIndex_->unregisterWith(floatLegProjTermStructureHandle_);
        
		//take fixing into account
        registerWith(floatLegIborIndex_);
		registerWith(floatLegProjTermStructureHandle_);

        registerWith(fixedLegIborIndex_);
		registerWith(fixedLegProjTermStructureHandle_);

        initializeDates();
    }

void XCCySwapRateHelper::initializeDates() {

			Calendar calendar = fixedLegCalendar_;
			Date today = Settings::instance().evaluationDate();
//Take dates from the fixed leg calendar...for now
			Date SpotDate = fixedLegCalendar_.advance(today, fixedLegIborIndex_->fixingDays(), Days, fixedLegConvention_, false);
//			Date StartDate = calendar.advance(SpotDate, fwdStart_);
			Date StartDate = SpotDate;
			Date EndDate = calendar.advance(StartDate, swapTerm_);
			//Date StartDate = SpotDate+fwdStart_;
			//      Date EndDate = StartDate + swapTerm_;

			Schedule floatLegSchedule(StartDate,
				EndDate,
				floatLegIborIndex_->tenor(),
				floatLegCalendar_,
				floatLegConvention_,
				floatLegConvention_,
				DateGeneration::Backward,
				false);

			//For a forward start xccy, notionals in the two currencies must be equivalent at the first time they are exchanged
			Real floatNotional = fwdStart_ != Period() ? 1000000 * fxFwd_ : 1000000 * fxSpot_;

			IborLeg floatLeg = IborLeg(floatLegSchedule, floatLegIborIndex_)
				.withNotionals(floatNotional)
				.withPaymentDayCounter(floatLegDayCount_)
				.withPaymentAdjustment(floatLegConvention_)
				.withFixingDays(floatLegIborIndex_->fixingDays())
				.withGearings(1.0)
				//.withSpreads(this->quote()->value())
				;


			floatLeg_ = boost::shared_ptr<IborLeg>(new IborLeg(floatLeg));

			Schedule sprdLegSchedule(StartDate,
				EndDate,
				fixedLegIborIndex_->tenor(),
				fixedLegCalendar_,
				fixedLegConvention_,
				fixedLegConvention_,
				DateGeneration::Backward,
				false);


			IborLeg sprdLeg = IborLeg(sprdLegSchedule, fixedLegIborIndex_)
				//.withNotionals(sprdNotionals)
				.withNotionals(1000000.0)
				.withPaymentDayCounter(fixedLegDayCount_)
				.withPaymentAdjustment(fixedLegConvention_)
				.withFixingDays(fixedLegIborIndex_->fixingDays())
				.withGearings(1.0);

			fixedLeg_ = boost::shared_ptr<IborLeg>(new IborLeg(sprdLeg));

			earliestDate_ = StartDate;
			latestDate_ = floatLegCalendar_.adjust(EndDate, fixedLegConvention_);
	
			
//			Date strtDate = CashFlows::startDate(*floatLeg_);
//			Date termDate = CashFlows::maturityDate(*floatLeg_);

//			Date strtDateUSD = CashFlows::startDate(*fixedLeg_);
//			Date termDateUSD = CashFlows::maturityDate(*fixedLeg_);
		}

		void XCCySwapRateHelper::setTermStructure(YieldTermStructure* t) {
			// do not set the relinkable handle as an observer -
			// force recalculation when needed
			bool observer = false;
			
			shared_ptr<YieldTermStructure> temp(t, null_deleter());
//			shared_ptr<YieldTermStructure> temp(t, no_deletion);

			if (discCurveBootstrapType_ == XCCySwapRateHelper::BootstrapFixedDiscCurve) {

				floatLegDiscRelinkableHandle_.linkTo(*floatLegDiscTermStructureHandle_, observer);
				fixedLegDiscRelinkableHandle_.linkTo(temp, observer);


			}
			else {

				floatLegDiscRelinkableHandle_.linkTo(temp, observer);
				fixedLegDiscRelinkableHandle_.linkTo(*fixedLegDiscTermStructureHandle_, observer);

			}

			RelativeDateRateHelper::setTermStructure(t);
		}

    Real XCCySwapRateHelper::impliedQuote() const {
		

		
		Date today = Settings::instance().evaluationDate();
		Date CCY_SpotDate= floatLegCalendar_.advance(today,floatLegIborIndex_->fixingDays(),Days,floatLegConvention_,false);
		Date USD_SpotDate= fixedLegCalendar_.advance(today,fixedLegIborIndex_->fixingDays(),Days,fixedLegConvention_,false);
//Try CCY_Spotdate= USD_SpotDate to solve USD/GBP issue?
		CCY_SpotDate = USD_SpotDate;

        Date strtDate = CashFlows::startDate(*floatLeg_);
        Date termDate = CashFlows::maturityDate(*floatLeg_);

		Date strtDateUSD = CashFlows::startDate(*fixedLeg_);
		Date termDateUSD = CashFlows::maturityDate(*fixedLeg_);
//Again try this tolve the USD/GBP issue
		strtDate = strtDateUSD;
		termDate = termDateUSD;

		//Setting fixedLegIborIndex_ and floatLegIborIndex_ term structure

		QL_REQUIRE(!(floatLegIborIndex_->forwardingTermStructure().empty()), "floatLegIborIndex_ TermStructure is empty");
		QL_REQUIRE(!(fixedLegIborIndex_->forwardingTermStructure().empty()), "fixedLegIborIndex_ TermStructure is empty");
		
		Real CCYNotional = fwdStart_!=Period() ? 1000000*fxFwd_ :  1000000*fxSpot_;



		Real npvCCYLegNotionalAtEnd = CCYNotional*
			(*floatLegDiscRelinkableHandle_)->discount(termDate)/
			(*floatLegDiscRelinkableHandle_)->discount(CCY_SpotDate);
		
		Real npvCCYLegNotionalAtStart = CCYNotional*
			(*floatLegDiscRelinkableHandle_)->discount(strtDate) /
			(*floatLegDiscRelinkableHandle_)->discount(CCY_SpotDate);


		Real npvCCYLeg = CashFlows::npv(*floatLeg_, **floatLegDiscRelinkableHandle_, true, CCY_SpotDate, CCY_SpotDate);

		Real npvCCYLegBPS = CashFlows::bps(*floatLeg_, **floatLegDiscRelinkableHandle_, true, CCY_SpotDate, CCY_SpotDate);


		Real npvUSDLegNotionalAtStart = 1000000 * (*fixedLegDiscRelinkableHandle_)->discount(strtDate) /
			(*fixedLegDiscRelinkableHandle_)->discount(USD_SpotDate);
	

		

		Real npvUSDLegNotionalAtEnd = 1000000 * (*fixedLegDiscRelinkableHandle_)->discount(termDate) /
			(*fixedLegDiscRelinkableHandle_)->discount(USD_SpotDate);


        Real npvUSDLeg  = CashFlows::npv(*fixedLeg_, **fixedLegDiscRelinkableHandle_, true, USD_SpotDate, USD_SpotDate);
		//Real npvUSDLegBPS = CashFlows::bps(*fixedLeg_, **fixedLegDiscRelinkableHandle_, true, USD_SpotDate, USD_SpotDate);

		Real npvUSDcomb = (npvUSDLeg + npvUSDLegNotionalAtEnd- npvUSDLegNotionalAtStart);
		Real npvCCYcomb_flat = (npvCCYLeg + npvCCYLegNotionalAtEnd - npvCCYLegNotionalAtStart);
		Real x=(npvUSDcomb / fxSpot_ - npvCCYcomb_flat) / npvCCYLegBPS;
		//x for constant Nominal Swap
//		Real y= (USDlegNPV / fxSpot_ - npvCCYcomb_flat) / npvCCYLegBPS;
		//y for mtm ccy Swap
		Real implicitQuote =x;

		return implicitQuote;
		 
    }

    void XCCySwapRateHelper::accept(AcyclicVisitor& v) {
        Visitor<XCCySwapRateHelper>* v1 =
            dynamic_cast<Visitor<XCCySwapRateHelper>*>(&v);
        if (v1 != 0)
            v1->visit(*this);
        else
            RateHelper::accept(v);
    }


	MtMXCCySwapRateHelper::MtMXCCySwapRateHelper(const Handle<Quote>& spread,
		const Period& tenor,
		//floating leg
		Rate   fxSpot,
		const Currency& floatLegCurrency,
		const Calendar& floatLegCalendar,
		const BusinessDayConvention& floatLegConvention,
		const DayCounter& floatLegDayCount,
		const boost::shared_ptr<IborIndex>& floatLegIborIndex,

		//fixed leg
		const Currency& fixedLegCurrency,
		const Calendar& fixedLegCalendar,
		const BusinessDayConvention& fixedLegConvention,
		const DayCounter& fixedLegDayCount,
		const boost::shared_ptr<IborIndex>& fixedLegIborIndex,
		//term structures...discountcurves
		const Handle<YieldTermStructure>& floatLegDiscTermStructureHandle,
		const Handle<YieldTermStructure>& fixedLegDiscTermStructureHandle,
		//Projection Curves
		const Handle<YieldTermStructure>& floatLegProjTermStructureHandle,
		const Handle<YieldTermStructure>& fixedLegProjTermStructureHandle,
		//general
		Type discCurveBootstrapType,
		const Period fwdStart,
		const Real fxFwd)
    : RelativeDateRateHelper(spread), fwdStart_(fwdStart), swapTerm_(tenor),
      discCurveBootstrapType_(discCurveBootstrapType), fxSpot_(fxSpot),
      fxFwd_(fxFwd),
		
		floatLegCurrency_(floatLegCurrency),
		floatLegCalendar_(floatLegCalendar),
		floatLegConvention_(floatLegConvention),
		floatLegDayCount_(floatLegDayCount),
		floatLegDiscTermStructureHandle_(floatLegDiscTermStructureHandle),
		floatLegProjTermStructureHandle_(floatLegProjTermStructureHandle),

		fixedLegCurrency_(fixedLegCurrency),
		fixedLegCalendar_(fixedLegCalendar), fixedLegConvention_(fixedLegConvention),
		fixedLegDayCount_(fixedLegDayCount),
		fixedLegDiscTermStructureHandle_(fixedLegDiscTermStructureHandle),
		fixedLegProjTermStructureHandle_(fixedLegProjTermStructureHandle)
	{

		/*	fixedLegIborIndex_ = fixedLegIborIndex->clone(fixedLegDiscRelinkableHandle_);
		fixedLegIborIndex_->unregisterWith(fixedLegDiscRelinkableHandle_);


		floatLegIborIndex_ = floatLegIborIndex->clone(floatLegDiscRelinkableHandle_);
		floatLegIborIndex_->unregisterWith(floatLegDiscRelinkableHandle_);*/
		fixedLegIborIndex_ = fixedLegIborIndex->clone(fixedLegProjTermStructureHandle_);
		fixedLegIborIndex_->unregisterWith(fixedLegProjTermStructureHandle_);

		floatLegIborIndex_ = floatLegIborIndex->clone(floatLegProjTermStructureHandle_);
		floatLegIborIndex_->unregisterWith(floatLegProjTermStructureHandle_);

		//take fixing into account
		registerWith(floatLegIborIndex_);
		registerWith(floatLegProjTermStructureHandle_);

		registerWith(fixedLegIborIndex_);
		registerWith(fixedLegProjTermStructureHandle_);

		initializeDates();
	}

	void MtMXCCySwapRateHelper::initializeDates() {
		Calendar calendar = fixedLegCalendar_;
		Date today = Settings::instance().evaluationDate();
		//Take dates from the fixed leg calendar...for now
		Date SpotDate = fixedLegCalendar_.advance(today, fixedLegIborIndex_->fixingDays(), Days, fixedLegConvention_, false);
		//			Date StartDate = calendar.advance(SpotDate, fwdStart_);
		Date StartDate = SpotDate;
		Date EndDate = calendar.advance(StartDate, swapTerm_);
		//Date StartDate = SpotDate+fwdStart_;
		//      Date EndDate = StartDate + swapTerm_;

		Schedule floatLegSchedule(StartDate,
			EndDate,
			floatLegIborIndex_->tenor(),
			floatLegCalendar_,
			floatLegConvention_,
			floatLegConvention_,
			DateGeneration::Backward,
			false);
		//Date TestDate(11, March, 2019);
		//if (EndDate == TestDate) {
		//	int x = 1;
		//	std::cout << "In XCCyHelper" << std::endl;
		//	//for (int j = 0; j < 14; j++) {
		//	//	std::cout << floatLegSchedule.dates_[j]<<std::endl;
		//	//	}// floatLegIborIndex_.operator*()->fixingDays() << std::endl;
		//}
		//For a forward start xccy, notionals in the two currencies must be equivalent at the first time they are exchanged
		Real floatNotional = fwdStart_ != Period() ? 1000000 * fxFwd_ : 1000000 * fxSpot_;

		IborLeg floatLeg = IborLeg(floatLegSchedule, floatLegIborIndex_)
			.withNotionals(floatNotional)
			.withPaymentDayCounter(floatLegDayCount_)
			.withPaymentAdjustment(floatLegConvention_)
			.withFixingDays(floatLegIborIndex_->fixingDays())
			.withGearings(1.0)
			//.withSpreads(this->quote()->value())
			;


		floatLeg_ = boost::shared_ptr<IborLeg>(new IborLeg(floatLeg));

		Schedule sprdLegSchedule(StartDate,
			EndDate,
			fixedLegIborIndex_->tenor(),
			fixedLegCalendar_,
			fixedLegConvention_,
			fixedLegConvention_,
			DateGeneration::Backward,
			false);




		//registerWith(floatLegDiscTermStructureHandle_);
		//registerWith(fixedLegDiscTermStructureHandle_);
		//Real discCCYstart = (*floatLegDiscTermStructureHandle_)->discount(StartDate);
		//Real discUSDstart = (*fixedLegDiscTermStructureHandle_)->discount(StartDate);
		//Real discCCYmat = discCCYstart;
		//Real discUSDmat = discUSDstart;
		//Date dd = StartDate;
		//std::vector<Real> sprdNotionals;

		////Holder to see when called
		//Date SpecificDate(30, December, 2036);
		//if (EndDate > SpecificDate) {
		//	std::cout << "20Yr Swap Setup " << std::endl;
		//	double  tempx = 1;
		//}


		//for (unsigned i = 1; i < sprdLegSchedule.size(); i++) {
		//	//sprdNotionals.push_back(1000000.0);
		//	discCCYmat = (*floatLegDiscTermStructureHandle_)->discount(dd);
		//	discUSDmat = (*fixedLegDiscTermStructureHandle_)->discount(dd);
		//	sprdNotionals.push_back(1000000.0*(discUSDmat / discUSDstart) / (discCCYmat / discCCYstart));
		//	dd = sprdLegSchedule.nextDate(dd + 1);
		//}

		IborLeg sprdLeg = IborLeg(sprdLegSchedule, fixedLegIborIndex_)
			//.withNotionals(sprdNotionals)
			.withNotionals(1000000.0)
			.withPaymentDayCounter(fixedLegDayCount_)
			.withPaymentAdjustment(fixedLegConvention_)
			.withFixingDays(fixedLegIborIndex_->fixingDays())
			.withGearings(1.0);

		fixedLeg_ = boost::shared_ptr<IborLeg>(new IborLeg(sprdLeg));

		earliestDate_ = StartDate;
		latestDate_ = floatLegCalendar_.adjust(EndDate, fixedLegConvention_);




//		Date strtDate = CashFlows::startDate(*floatLeg_);
//		Date termDate = CashFlows::maturityDate(*floatLeg_);

//		Date strtDateUSD = CashFlows::startDate(*fixedLeg_);
//		Date termDateUSD = CashFlows::maturityDate(*fixedLeg_);
	}

	void MtMXCCySwapRateHelper::setTermStructure(YieldTermStructure* t) {
		// do not set the relinkable handle as an observer -
		// force recalculation when needed
		bool observer = false;

		shared_ptr<YieldTermStructure> temp(t, null_deleter());
//		shared_ptr<YieldTermStructure> temp(t, no_deletion);

		if (discCurveBootstrapType_ == MtMXCCySwapRateHelper::BootstrapFixedDiscCurve) {

			floatLegDiscRelinkableHandle_.linkTo(*floatLegDiscTermStructureHandle_, observer);
			fixedLegDiscRelinkableHandle_.linkTo(temp, observer);


		}
		else {

			floatLegDiscRelinkableHandle_.linkTo(temp, observer);
			fixedLegDiscRelinkableHandle_.linkTo(*fixedLegDiscTermStructureHandle_, observer);

		}

		RelativeDateRateHelper::setTermStructure(t);
	}

	Real MtMXCCySwapRateHelper::impliedQuote() const {



		Date today = Settings::instance().evaluationDate();
		Date CCY_SpotDate = floatLegCalendar_.advance(today, floatLegIborIndex_->fixingDays(), Days, floatLegConvention_, false);
		Date USD_SpotDate = fixedLegCalendar_.advance(today, fixedLegIborIndex_->fixingDays(), Days, fixedLegConvention_, false);
		//Try CCY_Spotdate= USD_SpotDate to solve USD/GBP issue?
		CCY_SpotDate = USD_SpotDate;

		Date strtDate = CashFlows::startDate(*floatLeg_);
		Date termDate = CashFlows::maturityDate(*floatLeg_);

		Date strtDateUSD = CashFlows::startDate(*fixedLeg_);
		Date termDateUSD = CashFlows::maturityDate(*fixedLeg_);
		//Again try this tolve the USD/GBP issue
		strtDate = strtDateUSD;
		termDate = termDateUSD;


		//Setting fixedLegIborIndex_ and floatLegIborIndex_ term structure

		QL_REQUIRE(!(floatLegIborIndex_->forwardingTermStructure().empty()), "floatLegIborIndex_ TermStructure is empty");
		QL_REQUIRE(!(fixedLegIborIndex_->forwardingTermStructure().empty()), "fixedLegIborIndex_ TermStructure is empty");

		Real CCYNotional = fwdStart_ != Period() ? 1000000 * fxFwd_ : 1000000 * fxSpot_;



		Real npvCCYLegNotionalAtEnd = CCYNotional*
			(*floatLegDiscRelinkableHandle_)->discount(termDate) /
			(*floatLegDiscRelinkableHandle_)->discount(CCY_SpotDate);

		Real npvCCYLegNotionalAtStart = CCYNotional*
			(*floatLegDiscRelinkableHandle_)->discount(strtDate) /
			(*floatLegDiscRelinkableHandle_)->discount(CCY_SpotDate);


		Real npvCCYLeg = CashFlows::npv(*floatLeg_, **floatLegDiscRelinkableHandle_, true, CCY_SpotDate, CCY_SpotDate);

		Real npvCCYLegBPS = CashFlows::bps(*floatLeg_, **floatLegDiscRelinkableHandle_, true, CCY_SpotDate, CCY_SpotDate);


//		Real npvUSDLegNotionalAtStart = 1000000 * (*fixedLegDiscRelinkableHandle_)->discount(strtDate) /
//			(*fixedLegDiscRelinkableHandle_)->discount(USD_SpotDate);

		Real USDnotional = 1000000.0;
		Real USDnotional_prev = USDnotional;
		Real Discount_strt_ccy = ((*floatLegDiscRelinkableHandle_)->discount(strtDateUSD));
		Real Discount_strt_USD = ((*fixedLegDiscRelinkableHandle_)->discount(strtDateUSD));
		Real USDlegNPV = -USDnotional*Discount_strt_USD/ Discount_strt_USD;//2018.06.29 Need to bring MtM cashflow to value on Spot date

		Date RollDateUSD = CashFlows::nextCashFlowDate(*fixedLeg_, false, strtDateUSD);
		Real USDcoupon = CashFlows::nextCashFlowAmount(*fixedLeg_, false, strtDateUSD);
		Real Discount_USD = ((*fixedLegDiscRelinkableHandle_)->discount(RollDateUSD));
		Real Discount_ccy = ((*floatLegDiscRelinkableHandle_)->discount(RollDateUSD));

		while (RollDateUSD < termDateUSD) {

			USDnotional = 1000000 * (Discount_ccy / Discount_strt_ccy) / (Discount_USD / Discount_strt_USD);
			USDlegNPV = USDlegNPV + (USDnotional_prev / 1000000.0*USDcoupon - (USDnotional - USDnotional_prev))* Discount_USD / Discount_strt_USD;//2018.06.29 Need to bring MtM cashflow to value on Spot date

			USDnotional_prev = USDnotional;
			USDcoupon = CashFlows::nextCashFlowAmount(*fixedLeg_, false, RollDateUSD);
			RollDateUSD = CashFlows::nextCashFlowDate(*fixedLeg_, false, RollDateUSD);
			Discount_USD = ((*fixedLegDiscRelinkableHandle_)->discount(RollDateUSD));
			Discount_ccy = ((*floatLegDiscRelinkableHandle_)->discount(RollDateUSD));

		}
		USDlegNPV = USDlegNPV + USDnotional_prev / 1000000 * (USDcoupon + 1000000)*Discount_USD / Discount_strt_USD;//2018.06.29 Need to bring MtM cashflow to value on Spot date


//		Real npvUSDLegNotionalAtEnd = 1000000 * (*fixedLegDiscRelinkableHandle_)->discount(termDate) /
//			(*fixedLegDiscRelinkableHandle_)->discount(USD_SpotDate);


	//	Real npvUSDLeg = CashFlows::npv(*fixedLeg_, **fixedLegDiscRelinkableHandle_, true, USD_SpotDate, USD_SpotDate);
		//Real npvUSDLegBPS = CashFlows::bps(*fixedLeg_, **fixedLegDiscRelinkableHandle_, true, USD_SpotDate, USD_SpotDate);

		//Real npvUSDcomb = (npvUSDLeg + npvUSDLegNotionalAtEnd - npvUSDLegNotionalAtStart);
		Real npvCCYcomb_flat = (npvCCYLeg + npvCCYLegNotionalAtEnd - npvCCYLegNotionalAtStart);
		//Real x = (npvUSDcomb / fxSpot_ - npvCCYcomb_flat) / npvCCYLegBPS;
		//x for constant Nominal Swap
		Real y = (USDlegNPV / fxSpot_ - npvCCYcomb_flat) / npvCCYLegBPS;
		//y for mtm ccy Swap
		Real implicitQuote = y;

		return implicitQuote;

	}

	void MtMXCCySwapRateHelper::accept(AcyclicVisitor& v) {
		Visitor<MtMXCCySwapRateHelper>* v1 =
			dynamic_cast<Visitor<MtMXCCySwapRateHelper>*>(&v);
		if (v1 != 0)
			v1->visit(*this);
		else
			RateHelper::accept(v);
	}


}
