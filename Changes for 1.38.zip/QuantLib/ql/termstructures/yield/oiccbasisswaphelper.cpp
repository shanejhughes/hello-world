/*
 Copyright (C) 2016 Quaternion Risk Management Ltd
 All rights reserved.

 This file is part of ORE, a free-software/open-source library
 for transparent pricing and risk analysis - http://opensourcerisk.org

 ORE is free software: you can redistribute it and/or modify it
 under the terms of the Modified BSD License.  You should have received a
 copy of the license along with this program.
 The license is also available online at <http://opensourcerisk.org>

 This program is distributed on the basis that it will form a useful
 contribution to risk analytics and model standardisation, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 FITNESS FOR A PARTICULAR PURPOSE. See the license for more details.
*/

#include <ql/currencies/europe.hpp>
#include <ql/pricingengines/swap/discountingswapengine.hpp>
#include <ql/pricingengines/swap/oiccbasisswapengine.hpp>
#include <ql/termstructures/yield/oiccbasisswaphelper.hpp>
#include <ql/time/calendars/jointcalendar.hpp>

using boost::shared_ptr;

using namespace QuantLib;

namespace QuantLib {

    namespace {
        void no_deletion(YieldTermStructure*) {}
    } // namespace

    OICCBSHelper::OICCBSHelper(Natural settlementDays,
        const Period& term, // swap maturity
        const boost::shared_ptr<OvernightIndex>& payIndex, const Period& payTenor,
        const boost::shared_ptr<OvernightIndex>& recIndex,
        const Period& recTenor, // swap maturity
        const Handle<Quote>& spreadQuote, const Handle<YieldTermStructure>& fixedDiscountCurve,
        bool spreadQuoteOnPayLeg, bool fixedDiscountOnPayLeg, Natural paymentLag, Real fx)
        : RelativeDateRateHelper(spreadQuote),  //targetting the spread
        settlementDays_(settlementDays), term_(term), payIndex_(payIndex),
        payTenor_(payTenor), recIndex_(recIndex), recTenor_(recTenor), fixedDiscountCurve_(fixedDiscountCurve),
        spreadQuoteOnPayLeg_(spreadQuoteOnPayLeg), fixedDiscountOnPayLeg_(fixedDiscountOnPayLeg),
        paymentLag_(paymentLag), fx_(fx), spread_(spreadQuote->value()) {

        Date asof = Settings::instance().evaluationDate();
        calendar_ = QuantLib::JointCalendar(payIndex_->fixingCalendar(), recIndex_->fixingCalendar());
        settlementDate_ = calendar_.advance(asof, settlementDays_, Days);

        registerWith(payIndex_);
        registerWith(recIndex_);
        registerWith(fixedDiscountCurve_);
        initializeDates();
    }

    void OICCBSHelper::initializeDates() {
        Schedule paySchedule = MakeSchedule()
            .from(settlementDate_)
            .to(settlementDate_ + term_)
            .withTenor(payTenor_)
            .withCalendar(calendar_);
        Schedule recSchedule = MakeSchedule()
            .from(settlementDate_)
            .to(settlementDate_ + term_)
            .withTenor(recTenor_)
            .withCalendar(calendar_);
        //    Currency payCurrency = EURCurrency(); // arbitrary here
        //    Currency recCurrency = GBPCurrency(); // recCcy != payCcy, but FX=1
        Currency payCurrency = payIndex_->currency();
        Currency recCurrency = recIndex_->currency();
        boost::shared_ptr<Quote> fx(new SimpleQuote(1.0));
        fx_ = 1.0;
        //boost::shared_ptr<Quote> fx(new SimpleQuote(fx_));

        swap_ = boost::shared_ptr<OvernightIndexedCrossCcyBasisSwap>(
            new OvernightIndexedCrossCcyBasisSwap(1000000.0 * fx_, // arbitrary payNominal
                payCurrency, paySchedule, payIndex_,
                0.0,     // zero pay spread
                1000000.0, // recNominal consistent with FX rate used
                recCurrency, recSchedule, recIndex_,
                0.0, // target receive spread
                paymentLag_));

        // Spot FX rate quoted as 1 ccy2 = fx ccy1,
       // ccy1 is price currency, ccy 2 amounts to be multiplied by fx
        if (fixedDiscountOnPayLeg_) {
            boost::shared_ptr<PricingEngine> engine(new OvernightIndexedCrossCcyBasisSwapEngine(
                fixedDiscountCurve_, payCurrency, termStructureHandle_, recCurrency, Handle<Quote>(fx)));
            swap_->setPricingEngine(engine);
        }
        else {
            boost::shared_ptr<PricingEngine> engine(new OvernightIndexedCrossCcyBasisSwapEngine(
                termStructureHandle_, payCurrency, fixedDiscountCurve_, recCurrency, Handle<Quote>(fx)));
            swap_->setPricingEngine(engine);
        }

        earliestDate_ = swap_->startDate();
        maturityDate_ = swap_->maturityDate();

        Date lastPaymentDate = std::max(swap_->payLeg().back()->date(),
            swap_->recLeg().back()->date());
        latestRelevantDate_ = std::max(maturityDate_, lastPaymentDate);

        latestDate_ = std::max(maturityDate_, lastPaymentDate);
    }

    void OICCBSHelper::setTermStructure(YieldTermStructure* t) {
        // do not set the relinkable handle as an observer -
        // force recalculation when needed
        termStructureHandle_.linkTo(shared_ptr<YieldTermStructure>(t, no_deletion), false);
        RelativeDateRateHelper::setTermStructure(t);
    }

    Real OICCBSHelper::impliedQuote() const {
        QL_REQUIRE(termStructure_ != 0, "term structure not set");
        // we didn't register as observers - force calculation
        swap_->deepUpdate();
        if (spreadQuoteOnPayLeg_)
            //return swap_->fairPayLegSpread();
            if (fixedDiscountOnPayLeg_)
                return -(1.0 / 10000.0) * (swap_->payLegNPV() + swap_->recLegNPV() * fx_ * (fixedDiscountCurve_->discount(settlementDate_)) / (termStructureHandle_->discount(settlementDate_)))
                / swap_->payLegBPS();
            else
                return -(1.0 / 10000.0) * (swap_->payLegNPV() + swap_->recLegNPV() * fx_ * (termStructureHandle_->discount(settlementDate_)) / (fixedDiscountCurve_->discount(settlementDate_)))
                / swap_->payLegBPS();
        else
            if (fixedDiscountOnPayLeg_)
                return  -(1.0 / 10000.0) * (swap_->payLegNPV() / fx_ / (fixedDiscountCurve_->discount(settlementDate_)) * (termStructureHandle_->discount(settlementDate_)) + swap_->recLegNPV())
                / swap_->recLegBPS();
            else
                return  -(1.0 / 10000.0) * (swap_->payLegNPV() / fx_ / (termStructureHandle_->discount(settlementDate_)) * (fixedDiscountCurve_->discount(settlementDate_)) + swap_->recLegNPV())
                / swap_->recLegBPS();
        //return swap_->fairRecLegSpread();
    }

    void OICCBSHelper::accept(AcyclicVisitor& v) {
        Visitor<OICCBSHelper>* v1 = dynamic_cast<Visitor<OICCBSHelper>*>(&v);
        if (v1 != 0)
            v1->visit(*this);
        else
            RateHelper::accept(v);
    }
} // namespace QuantExt
