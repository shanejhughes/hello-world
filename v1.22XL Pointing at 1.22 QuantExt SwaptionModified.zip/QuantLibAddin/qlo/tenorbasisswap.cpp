/* -*- mode: c++; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*- */

/*
 Copyright (C) 2005, 2006 Eric Ehlers
 Copyright (C) 2006, 2011, 2015 Ferdinando Ametrano
 Copyright (C) 2005 Aurelien Chanudet
 Copyright (C) 2005 Plamen Neykov
 Copyright (C) 2006 Katiuscia Manzoni

 This file is part of QuantLib, a free-software/open-source library
 for financial quantitative analysts and developers - http://quantlib.org/

 QuantLib is free software: you can redistribute it and/or modify it
 under the terms of the QuantLib license.  You should have received a
 copy of the license along with this program; if not, please email
 <quantlib-dev@lists.sf.net>. The license is also available online at
 <http://quantlib.org/license.shtml>.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE.  See the license for more details.
*/

#if defined(HAVE_CONFIG_H)
    #include <qlo/config.hpp>
#endif

#include <qlo/tenorbasisswap.hpp>
//#include <ql/instruments/makevanillaswap.hpp>
//#include <ql/indexes/swapindex.hpp>
//#include <ql/termstructures/yield/ratehelpers.hpp>
//#include <ql/time/imm.hpp>

//using QuantLib::MakeVanillaSwap;
using std::vector;
using boost::shared_ptr;
using ObjectHandler::ValueObject;
using ObjectHandler::property_t;

namespace QuantLibAddin {

	TenorBasisSwap::TenorBasisSwap(const shared_ptr<ValueObject>& properties,
								QuantLib::Date effectiveDate,	
								QuantLib::Real nominal,
								QuantLib::Period swapTenor,
								bool payLongIndex,
								const boost::shared_ptr<QuantLib::IborIndex>& longIndex,
								QuantLib::Spread longSpread,
								const boost::shared_ptr<QuantLib::IborIndex>& shortIndex,
								QuantLib::Spread shortSpread,
								QuantLib::Period shortPayTenor,
								QuantLib::DateGeneration::Rule rule,
								bool includeSpread,
								QuantLib::SubPeriodsCouponQLE::Type type,
								bool permanent)
    : Swap(properties, permanent)
    {
        libraryObject_ = shared_ptr<QuantLib::Instrument>(new
            QuantLib::TenorBasisSwap(
							effectiveDate,
							nominal,
							swapTenor,
							payLongIndex,
							longIndex,
							longSpread,
							shortIndex,
							shortSpread,
							shortPayTenor,
							rule,
							includeSpread,
							type
			));
    }

	TenorBasisSwap::TenorBasisSwap(
		const boost::shared_ptr<ObjectHandler::ValueObject> properties,
		QuantLib::Real nominal,
		bool payLongIndex,
		const boost::shared_ptr<QuantLib::Schedule> & longSchedule,
		const boost::shared_ptr<QuantLib::IborIndex>& longIndex,
		QuantLib::Spread longSpread,
		const boost::shared_ptr<QuantLib::Schedule> & shortSchedule,
		const boost::shared_ptr<QuantLib::IborIndex>& shortIndex,
		QuantLib::Spread shortSpread,
		bool includeSpread,
		QuantLib::SubPeriodsCouponQLE::Type type,
		bool permanent)
		: Swap(properties, permanent)
	{
		libraryObject_ = shared_ptr<QuantLib::Instrument>(new
			QuantLib::TenorBasisSwap(nominal,
				payLongIndex,
				*longSchedule,
				longIndex,
				longSpread,
				*shortSchedule,
				shortIndex,
				shortSpread,
				includeSpread,
				type
			));
	}


	vector<vector<property_t> > TenorBasisSwap::longIndexLegAnalysis(
                                                    const QuantLib::Date& d) {
        return Swap::legAnalysis(0, d);
    }

    vector<vector<property_t> > TenorBasisSwap::shortIndexLegAnalysis(
                                                    const QuantLib::Date& d) {
        return Swap::legAnalysis(1, d);
    }

}
