/* -*- mode: c++; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*- */

/*
 Copyright (C) 2005, 2006 Eric Ehlers
 Copyright (C) 2005 Plamen Neykov
 Copyright (C) 2005 Aurelien Chanudet
 Copyright (C) 2011, 2015 Ferdinando Ametrano

 This file is part of QuantLib, a free-software/open-source library
 for financial quantitative analysts and developers - http://quantlib.org/

 QuantLib is free software: you can redistribute it and/or modify it
 under the terms of the QuantLib license.  You should have received a
 copy of the license along with this program; if not, please email
 <quantlib-dev@lists.sf.net>. The license is also available online at
 <http://quantlib.org/license.shtml>.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE.  See the license for more details.
*/

#ifndef qla_tenorbasisswap_hpp
#define qla_tenorbasisswap_hpp

#include <qlo/swap.hpp>

#include <ql/instruments/tenorbasisswap.hpp>

//namespace QuantLib {
//    class SwapRateHelper;
//}

namespace QuantLibAddin {

    class TenorBasisSwap : public Swap {
    public:
        TenorBasisSwap(
            const boost::shared_ptr<ObjectHandler::ValueObject>& properties,
			QuantLib::Date effectiveDate,
			QuantLib::Real nominal, 
			QuantLib::Period swapTenor,
			bool payLongIndex,
			const boost::shared_ptr<QuantLib::IborIndex>& longIndex,
			QuantLib::Spread longSpread,
			const boost::shared_ptr<QuantLib::IborIndex>& shortIndex,
			QuantLib::Spread shortSpread,
			QuantLib::Period shortPayTenor,
			QuantLib::DateGeneration::Rule rule,
			bool includeSpread,
			QuantLib::SubPeriodsCoupon1::Type type,
			bool permanent);
		
		TenorBasisSwap( 
            const boost::shared_ptr<ObjectHandler::ValueObject> properties,
			QuantLib::Real nominal,
			bool payLongIndex, 
			const boost::shared_ptr<QuantLib::Schedule>& longSchedule,
			const boost::shared_ptr<QuantLib::IborIndex>& longIndex, 
			QuantLib::Spread longSpread,
			const boost::shared_ptr<QuantLib::Schedule>& shortSchedule,
			const boost::shared_ptr<QuantLib::IborIndex>& shortIndex,
			QuantLib::Spread shortSpread,
			bool includeSpread,
			QuantLib::SubPeriodsCoupon1::Type type,
			bool permanent);

		std::vector<std::vector<ObjectHandler::property_t> >
                                    longIndexLegAnalysis(const QuantLib::Date& d);
        std::vector<std::vector<ObjectHandler::property_t> >
                                    shortIndexLegAnalysis(const QuantLib::Date&);
    };

}

#endif
