
/*  
 Copyright (C) 2007, 2008 Eric Ehlers
 Copyright (C) 2006 Plamen Neykov
 
 This file is part of QuantLib, a free-software/open-source library
 for financial quantitative analysts and developers - http://quantlib.org/

 QuantLib is free software: you can redistribute it and/or modify it
 under the terms of the QuantLib license.  You should have received a
 copy of the license along with this program; if not, please email
 <quantlib-dev@lists.sf.net>. The license is also available online at
 <http://quantlib.org/license.shtml>.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE.  See the license for more details.
*/

// This file was generated automatically by gensrc.py.  If you edit this file
// manually then your changes will be lost the next time gensrc runs.

// This source code file was generated from the following stub:
//      QuantLibAddin/gensrc/stubs/stub.serialization.includes

#include <qlo/serialization/create/create_tenorbasisswap.hpp>
#include <qlo/qladdindefines.hpp>
#include <qlo/handle.hpp>
#include <oh/enumerations/typefactory.hpp>
#include <qlo/tenorbasisswap.hpp>
#include <qlo/indexes/iborindex.hpp>
#include <qlo/schedule.hpp>
#include <qlo/pricingengines.hpp>
#include <qlo/termstructures.hpp>
#include <ql/indexes/iborindex.hpp>
#include <ql/termstructures/yield/ratehelpers.hpp>

#include <qlo/conversions/all.hpp>
#include <oh/property.hpp>

namespace QuantLibAddin {

    boost::shared_ptr<ObjectHandler::Object> create_qlTenorBasisSwap(
        const boost::shared_ptr<ObjectHandler::ValueObject> &valueObject) {

        // convert input datatypes to C++ datatypes

        ObjectHandler::property_t Nominal =
            valueObject->getProperty("Nominal");

        bool PayLongIndex =
            ObjectHandler::convert2<bool>(valueObject->getProperty("PayLongIndex"));

        std::string LongIndexSchedule =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("LongIndexSchedule"));

        std::string LongIborIndex =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("LongIborIndex"));

        double LongIndexSpread =
            ObjectHandler::convert2<double>(valueObject->getProperty("LongIndexSpread"));

        std::string ShortIndexSchedule =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("ShortIndexSchedule"));

        std::string ShortIborIndex =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("ShortIborIndex"));

        double ShortIndexSpread =
            ObjectHandler::convert2<double>(valueObject->getProperty("ShortIndexSpread"));

        bool IncludeSpread =
            ObjectHandler::convert2<bool>(valueObject->getProperty("IncludeSpread"));

        std::string AvergingCompounding =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("AvergingCompounding"));

        bool Permanent =
            ObjectHandler::convert2<bool>(valueObject->getProperty("Permanent"));

        // convert input datatypes to QuantLib datatypes

        QuantLib::Real NominalLib = Nominal;

        // convert input datatypes to QuantLib enumerated datatypes

        QuantLib::SubPeriodsCouponQLE::Type AvergingCompoundingEnum =
            ObjectHandler::Create<QuantLib::SubPeriodsCouponQLE::Type>()(AvergingCompounding);

        // convert object IDs into library objects

        OH_GET_REFERENCE(LongIndexScheduleLibObjPtr, LongIndexSchedule,
            QuantLibAddin::Schedule, QuantLib::Schedule)

        OH_GET_REFERENCE(LongIborIndexLibObjPtr, LongIborIndex,
            QuantLibAddin::IborIndex, QuantLib::IborIndex)

        OH_GET_REFERENCE(ShortIndexScheduleLibObjPtr, ShortIndexSchedule,
            QuantLibAddin::Schedule, QuantLib::Schedule)

        OH_GET_REFERENCE(ShortIborIndexLibObjPtr, ShortIborIndex,
            QuantLibAddin::IborIndex, QuantLib::IborIndex)

        // update value object precedent IDs (if any)

        valueObject->processPrecedentID(LongIndexSchedule);
        valueObject->processPrecedentID(LongIborIndex);
        valueObject->processPrecedentID(ShortIndexSchedule);
        valueObject->processPrecedentID(ShortIborIndex);

        // construct and return the object

        boost::shared_ptr<ObjectHandler::Object> object(
            new QuantLibAddin::TenorBasisSwap(
                valueObject,
                NominalLib,
                PayLongIndex,
                LongIndexScheduleLibObjPtr,
                LongIborIndexLibObjPtr,
                LongIndexSpread,
                ShortIndexScheduleLibObjPtr,
                ShortIborIndexLibObjPtr,
                ShortIndexSpread,
                IncludeSpread,
                AvergingCompoundingEnum,
                Permanent));
        return object;
    }

    boost::shared_ptr<ObjectHandler::Object> create_qlTenorBasisSwap2(
        const boost::shared_ptr<ObjectHandler::ValueObject> &valueObject) {

        // convert input datatypes to C++ datatypes

        ObjectHandler::property_t EffectiveDate =
            valueObject->getProperty("EffectiveDate");

        ObjectHandler::property_t Nominal =
            valueObject->getProperty("Nominal");

        std::string SwapTenor =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("SwapTenor"));

        bool PayLongIndex =
            ObjectHandler::convert2<bool>(valueObject->getProperty("PayLongIndex"));

        std::string LongIborIndex =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("LongIborIndex"));

        double LongIndexSpread =
            ObjectHandler::convert2<double>(valueObject->getProperty("LongIndexSpread"));

        std::string ShortIborIndex =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("ShortIborIndex"));

        double ShortIndexSpread =
            ObjectHandler::convert2<double>(valueObject->getProperty("ShortIndexSpread"));

        std::string ShortLegPaymentTenor =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("ShortLegPaymentTenor"));

        std::string DateGeneration =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("DateGeneration"));

        bool IncludeSpread =
            ObjectHandler::convert2<bool>(valueObject->getProperty("IncludeSpread"));

        std::string AvergingCompounding =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("AvergingCompounding"));

        bool Permanent =
            ObjectHandler::convert2<bool>(valueObject->getProperty("Permanent"));

        // convert input datatypes to QuantLib datatypes

        QuantLib::Date EffectiveDateLib = ObjectHandler::convert2<QuantLib::Date>(
            valueObject->getProperty("EffectiveDate"), "EffectiveDate");

        QuantLib::Real NominalLib = Nominal;

        QuantLib::Period SwapTenorLib;
        QuantLibAddin::cppToLibrary(SwapTenor, SwapTenorLib);

        QuantLib::Period ShortLegPaymentTenorLib;
        QuantLibAddin::cppToLibrary(ShortLegPaymentTenor, ShortLegPaymentTenorLib);

        // convert input datatypes to QuantLib enumerated datatypes

        QuantLib::DateGeneration::Rule DateGenerationEnum =
            ObjectHandler::Create<QuantLib::DateGeneration::Rule>()(DateGeneration);

        QuantLib::SubPeriodsCouponQLE::Type AvergingCompoundingEnum =
            ObjectHandler::Create<QuantLib::SubPeriodsCouponQLE::Type>()(AvergingCompounding);

        // convert object IDs into library objects

        OH_GET_REFERENCE(LongIborIndexLibObjPtr, LongIborIndex,
            QuantLibAddin::IborIndex, QuantLib::IborIndex)

        OH_GET_REFERENCE(ShortIborIndexLibObjPtr, ShortIborIndex,
            QuantLibAddin::IborIndex, QuantLib::IborIndex)

        // update value object precedent IDs (if any)

        valueObject->processPrecedentID(LongIborIndex);
        valueObject->processPrecedentID(ShortIborIndex);

        // construct and return the object

        boost::shared_ptr<ObjectHandler::Object> object(
            new QuantLibAddin::TenorBasisSwap(
                valueObject,
                EffectiveDateLib,
                NominalLib,
                SwapTenorLib,
                PayLongIndex,
                LongIborIndexLibObjPtr,
                LongIndexSpread,
                ShortIborIndexLibObjPtr,
                ShortIndexSpread,
                ShortLegPaymentTenorLib,
                DateGenerationEnum,
                IncludeSpread,
                AvergingCompoundingEnum,
                Permanent));
        return object;
    }

}
