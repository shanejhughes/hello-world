
/*  
 Copyright (C) 2007, 2008 Eric Ehlers
 Copyright (C) 2006 Plamen Neykov
 
 This file is part of QuantLib, a free-software/open-source library
 for financial quantitative analysts and developers - http://quantlib.org/

 QuantLib is free software: you can redistribute it and/or modify it
 under the terms of the QuantLib license.  You should have received a
 copy of the license along with this program; if not, please email
 <quantlib-dev@lists.sf.net>. The license is also available online at
 <http://quantlib.org/license.shtml>.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE.  See the license for more details.
*/

// This file was generated automatically by gensrc.py.  If you edit this file
// manually then your changes will be lost the next time gensrc runs.

// This source code file was generated from the following stub:
//      QuantLibAddin/gensrc/stubs/stub.serialization.includes

#include <qlo/serialization/create/create_subperiodsswap.hpp>
#include <qlo/qladdindefines.hpp>
#include <qlo/handle.hpp>
#include <oh/enumerations/typefactory.hpp>
#include <qlo/enumerations/factories/calendarfactory.hpp>
#include <qlo/subperiodsswap.hpp>
#include <qlo/indexes/iborindex.hpp>
#include <qlo/schedule.hpp>
#include <qlo/pricingengines.hpp>
#include <qlo/termstructures.hpp>
#include <ql/indexes/iborindex.hpp>
#include <ql/termstructures/yield/ratehelpers.hpp>

#include <qlo/conversions/all.hpp>
#include <oh/property.hpp>

namespace QuantLibAddin {

    boost::shared_ptr<ObjectHandler::Object> create_qlSubPeriodsSwap(
        const boost::shared_ptr<ObjectHandler::ValueObject> &valueObject) {

        // convert input datatypes to C++ datatypes

        ObjectHandler::property_t EffectiveDate =
            valueObject->getProperty("EffectiveDate");

        ObjectHandler::property_t Nominal =
            valueObject->getProperty("Nominal");

        std::string SwapTenor =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("SwapTenor"));

        bool IsPayer =
            ObjectHandler::convert2<bool>(valueObject->getProperty("IsPayer"));

        std::string FixedPayTenor =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("FixedPayTenor"));

        double FixedRate =
            ObjectHandler::convert2<double>(valueObject->getProperty("FixedRate"));

        std::string FixedCalendar =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("FixedCalendar"));

        std::string FixedDayCount =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("FixedDayCount"));

        std::string FixedDayConvention =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("FixedDayConvention"));

        std::string FloatLegPayTenor =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("FloatLegPayTenor"));

        std::string IborIndex =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("IborIndex"));

        std::string FloatLegCount =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("FloatLegCount"));

        std::string DateGeneration =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("DateGeneration"));

        std::string AvergingCompounding =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("AvergingCompounding"));

        bool Permanent =
            ObjectHandler::convert2<bool>(valueObject->getProperty("Permanent"));

        // convert input datatypes to QuantLib datatypes

        QuantLib::Date EffectiveDateLib = ObjectHandler::convert2<QuantLib::Date>(
            valueObject->getProperty("EffectiveDate"), "EffectiveDate");

        QuantLib::Real NominalLib = Nominal;

        QuantLib::Period SwapTenorLib;
        QuantLibAddin::cppToLibrary(SwapTenor, SwapTenorLib);

        QuantLib::Period FixedPayTenorLib;
        QuantLibAddin::cppToLibrary(FixedPayTenor, FixedPayTenorLib);

        QuantLib::Period FloatLegPayTenorLib;
        QuantLibAddin::cppToLibrary(FloatLegPayTenor, FloatLegPayTenorLib);

        // convert input datatypes to QuantLib enumerated datatypes

        QuantLib::Calendar FixedCalendarEnum =
            ObjectHandler::Create<QuantLib::Calendar>()(FixedCalendar);

        QuantLib::DayCounter FixedDayCountEnum =
            ObjectHandler::Create<QuantLib::DayCounter>()(FixedDayCount);

        QuantLib::BusinessDayConvention FixedDayConventionEnum =
            ObjectHandler::Create<QuantLib::BusinessDayConvention>()(FixedDayConvention);

        QuantLib::DayCounter FloatLegCountEnum =
            ObjectHandler::Create<QuantLib::DayCounter>()(FloatLegCount);

        QuantLib::DateGeneration::Rule DateGenerationEnum =
            ObjectHandler::Create<QuantLib::DateGeneration::Rule>()(DateGeneration);

        QuantLib::SubPeriodsCouponQLE::Type AvergingCompoundingEnum =
            ObjectHandler::Create<QuantLib::SubPeriodsCouponQLE::Type>()(AvergingCompounding);

        // convert object IDs into library objects

        OH_GET_REFERENCE(IborIndexLibObjPtr, IborIndex,
            QuantLibAddin::IborIndex, QuantLib::IborIndex)

        // update value object precedent IDs (if any)

        valueObject->processPrecedentID(IborIndex);

        // construct and return the object

        boost::shared_ptr<ObjectHandler::Object> object(
            new QuantLibAddin::SubPeriodsSwap(
                valueObject,
                EffectiveDateLib,
                NominalLib,
                SwapTenorLib,
                IsPayer,
                FixedPayTenorLib,
                FixedRate,
                FixedCalendarEnum,
                FixedDayCountEnum,
                FixedDayConventionEnum,
                FloatLegPayTenorLib,
                IborIndexLibObjPtr,
                FloatLegCountEnum,
                DateGenerationEnum,
                AvergingCompoundingEnum,
                Permanent));
        return object;
    }

}
