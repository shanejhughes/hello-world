
/*  
 Copyright (C) 2007, 2008 Eric Ehlers
 Copyright (C) 2006 Plamen Neykov
 
 This file is part of QuantLib, a free-software/open-source library
 for financial quantitative analysts and developers - http://quantlib.org/

 QuantLib is free software: you can redistribute it and/or modify it
 under the terms of the QuantLib license.  You should have received a
 copy of the license along with this program; if not, please email
 <quantlib-dev@lists.sf.net>. The license is also available online at
 <http://quantlib.org/license.shtml>.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE.  See the license for more details.
*/

// This file was generated automatically by gensrc.py.  If you edit this file
// manually then your changes will be lost the next time gensrc runs.

// This source code file was generated from the following stub:
//      QuantLibAddin/gensrc/stubs/stub.serialization.includes

#include <qlo/serialization/create/create_oibasisswap.hpp>
#include <qlo/qladdindefines.hpp>
#include <qlo/handle.hpp>
#include <oh/enumerations/typefactory.hpp>
#include <qlo/oibasisswap.hpp>
#include <qlo/indexes/iborindex.hpp>
#include <qlo/schedule.hpp>
#include <qlo/pricingengines.hpp>
#include <qlo/termstructures.hpp>
#include <ql/indexes/iborindex.hpp>
#include <ql/termstructures/yield/ratehelpers.hpp>

#include <qlo/conversions/all.hpp>
#include <oh/property.hpp>

namespace QuantLibAddin {

    boost::shared_ptr<ObjectHandler::Object> create_qlOvernightIndexedBasisAmortizingSwap(
        const boost::shared_ptr<ObjectHandler::ValueObject> &valueObject) {

        // convert input datatypes to C++ datatypes

        std::string PayerReceiver =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("PayerReceiver"));

        std::vector<double> Nominal =
            ObjectHandler::vector::convert2<double>(valueObject->getProperty("Nominal"), "Nominal");

        std::string OISIndexSchedule =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("OISIndexSchedule"));

        std::string OisIndex =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("OisIndex"));

        std::string IborIndexSchedule =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("IborIndexSchedule"));

        std::string IborIndex =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("IborIndex"));

        double OISIndexSpread =
            ObjectHandler::convert2<double>(valueObject->getProperty("OISIndexSpread"));

        double IborIndexSpread =
            ObjectHandler::convert2<double>(valueObject->getProperty("IborIndexSpread"));

        bool Permanent =
            ObjectHandler::convert2<bool>(valueObject->getProperty("Permanent"));

        // convert input datatypes to QuantLib datatypes

        std::vector<QuantLib::Real> NominalLib = 
            QuantLibAddin::convertVector<double, QuantLib::Real>(Nominal);

        // convert input datatypes to QuantLib enumerated datatypes

        QuantLib::OvernightIndexedBasisSwap::Type PayerReceiverEnum =
            ObjectHandler::Create<QuantLib::OvernightIndexedBasisSwap::Type>()(PayerReceiver);

        // convert object IDs into library objects

        OH_GET_REFERENCE(OISIndexScheduleLibObjPtr, OISIndexSchedule,
            QuantLibAddin::Schedule, QuantLib::Schedule)

        OH_GET_REFERENCE(OisIndexLibObjPtr, OisIndex,
            QuantLibAddin::OvernightIndex, QuantLib::OvernightIndex)

        OH_GET_REFERENCE(IborIndexScheduleLibObjPtr, IborIndexSchedule,
            QuantLibAddin::Schedule, QuantLib::Schedule)

        OH_GET_REFERENCE(IborIndexLibObjPtr, IborIndex,
            QuantLibAddin::IborIndex, QuantLib::IborIndex)

        // update value object precedent IDs (if any)

        valueObject->processPrecedentID(OISIndexSchedule);
        valueObject->processPrecedentID(OisIndex);
        valueObject->processPrecedentID(IborIndexSchedule);
        valueObject->processPrecedentID(IborIndex);

        // construct and return the object

        boost::shared_ptr<ObjectHandler::Object> object(
            new QuantLibAddin::OvernightIndexedBasisSwap(
                valueObject,
                PayerReceiverEnum,
                NominalLib,
                OISIndexScheduleLibObjPtr,
                OisIndexLibObjPtr,
                IborIndexScheduleLibObjPtr,
                IborIndexLibObjPtr,
                OISIndexSpread,
                IborIndexSpread,
                Permanent));
        return object;
    }

    boost::shared_ptr<ObjectHandler::Object> create_qlOvernightIndexedBasisSwap(
        const boost::shared_ptr<ObjectHandler::ValueObject> &valueObject) {

        // convert input datatypes to C++ datatypes

        std::string PayerReceiver =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("PayerReceiver"));

        ObjectHandler::property_t Nominal =
            valueObject->getProperty("Nominal");

        std::string OISIndexSchedule =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("OISIndexSchedule"));

        std::string OisIndex =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("OisIndex"));

        std::string IborIndexSchedule =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("IborIndexSchedule"));

        std::string IborIndex =
            ObjectHandler::convert2<std::string>(valueObject->getProperty("IborIndex"));

        double OISIndexSpread =
            ObjectHandler::convert2<double>(valueObject->getProperty("OISIndexSpread"));

        double IborIndexSpread =
            ObjectHandler::convert2<double>(valueObject->getProperty("IborIndexSpread"));

        bool Permanent =
            ObjectHandler::convert2<bool>(valueObject->getProperty("Permanent"));

        // convert input datatypes to QuantLib datatypes

        QuantLib::Real NominalLib = Nominal;

        // convert input datatypes to QuantLib enumerated datatypes

        QuantLib::OvernightIndexedBasisSwap::Type PayerReceiverEnum =
            ObjectHandler::Create<QuantLib::OvernightIndexedBasisSwap::Type>()(PayerReceiver);

        // convert object IDs into library objects

        OH_GET_REFERENCE(OISIndexScheduleLibObjPtr, OISIndexSchedule,
            QuantLibAddin::Schedule, QuantLib::Schedule)

        OH_GET_REFERENCE(OisIndexLibObjPtr, OisIndex,
            QuantLibAddin::OvernightIndex, QuantLib::OvernightIndex)

        OH_GET_REFERENCE(IborIndexScheduleLibObjPtr, IborIndexSchedule,
            QuantLibAddin::Schedule, QuantLib::Schedule)

        OH_GET_REFERENCE(IborIndexLibObjPtr, IborIndex,
            QuantLibAddin::IborIndex, QuantLib::IborIndex)

        // update value object precedent IDs (if any)

        valueObject->processPrecedentID(OISIndexSchedule);
        valueObject->processPrecedentID(OisIndex);
        valueObject->processPrecedentID(IborIndexSchedule);
        valueObject->processPrecedentID(IborIndex);

        // construct and return the object

        boost::shared_ptr<ObjectHandler::Object> object(
            new QuantLibAddin::OvernightIndexedBasisSwap(
                valueObject,
                PayerReceiverEnum,
                NominalLib,
                OISIndexScheduleLibObjPtr,
                OisIndexLibObjPtr,
                IborIndexScheduleLibObjPtr,
                IborIndexLibObjPtr,
                OISIndexSpread,
                IborIndexSpread,
                Permanent));
        return object;
    }

}
