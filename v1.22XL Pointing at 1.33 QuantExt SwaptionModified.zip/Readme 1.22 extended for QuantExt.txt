Note: need to add all new QuantLib functions to the QuantLib project
Also, don't forget to retarget the solution if using VS2022
You may need to get QuantLibObjects, OHxlib and xlsdk to build  targets with "v142" INSTEAD of platform name
Also, mayneed to remove OIBasisSwapHelper... it still needs work


https://www.quantlib.org/quantlibaddin/tutorials.html

Below is a list of tutorials relating to compilation of QuantLibAddin/QuantLibXL from source code.

Build QuantLibXL From Source Code
Build A QuantLibAddin C++ Environment on Windows and/or Linux
Build QuantLib Calc Addin on Windows and/or Linux
Expose QuantLib Enumerations to QuantLibXL
Expose QuantLib Classes to QuantLibXL
Expose QuantLib Template Classes to QuantLibXL
Serialization Demo

Expose QuantLib Template Classes to QuantLibXL:

This has to be done for new files added by SH
	subperiodsswap,oibasisswap & tenorbasisswap 
First add subperiodsswap,oibasisswap & tenorbasisswap .xml  from \QuantLibAddin\gensrc\metadata\functions to qlgensrc>functions
Then add subperiodsswap,oibasisswap & tenorbasisswap .cpp,hpp from \QuantLibAddin\qlo to  QuantLibObjects>Instruments


For purposes of this tutorial we ignore the new file for Doxygen. The other 8 files need to be added to the relevant projects as shown below:
Add file(s) 														...	To project 			...	In folder ...
QuantLibXL/qlxl/register/register_stock.cpp							... QuantLibXLStatic 	... register
QuantLibXL/qlxl/functions/stock.cpp									... QuantLibXLStatic 	... functions
QuantLibAddin/qlo/valueobjects/vo_stock.*pp							... QuantLibObjects	 	... valueobjects
QuantLibAddin/qlo/serialization/create/create_stock.*pp				... QuantLibObjects	 	... serialization/create
QuantLibAddin/qlo/serialization/register/serialization_stock.*pp	... QuantLibObjects		... serialization/register