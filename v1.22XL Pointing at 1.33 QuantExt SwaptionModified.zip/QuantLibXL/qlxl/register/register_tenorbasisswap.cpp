
/*  
 Copyright (C) 2004, 2005, 2006, 2007, 2008 Eric Ehlers
 
 This file is part of QuantLib, a free-software/open-source library
 for financial quantitative analysts and developers - http://quantlib.org/

 QuantLib is free software: you can redistribute it and/or modify it
 under the terms of the QuantLib license.  You should have received a
 copy of the license along with this program; if not, please email
 <quantlib-dev@lists.sf.net>. The license is also available online at
 <http://quantlib.org/license.shtml>.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE.  See the license for more details.
*/

// This file was generated automatically by gensrc.py.  If you edit this file
// manually then your changes will be lost the next time gensrc runs.

// This source code file was generated from the following stub:
//      gensrc/gensrc/stubs/stub.excel.register.file

#include <xlsdk/xlsdkdefines.hpp>

// register functions in category Tenorbasisswap with Excel

void registerTenorbasisswap(const XLOPER &xDll) {

        Excel(xlfRegister, 0, 24, &xDll,
            // function code name
            TempStrNoSize("\x10""qlTenorBasisSwap"),
            // parameter codes
            TempStrNoSize("\x10""CCPLCCPCCPLPPPL#"),
            // function display name
            TempStrNoSize("\x10""qlTenorBasisSwap"),
            // comma-delimited list of parameter names
            TempStrNoSize("\xBE""ObjectId,Nominal,PayLongIndex,LongIndexSchedule,LongIborIndex,LongIndexSpread,ShortIndexSchedule,ShortIborIndex,ShortIndexSpread,IncludeSpread,AvergingCompounding,Permanent,Trigger,Overwrite"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x3D""Construct an object of class TenorBasisSwap and return its id"),
            // parameter descriptions
            TempStrNoSize("\x1A""id of object to be created"),
            TempStrNoSize("\x25""Notional Amount. Default value = 100."),
            TempStrNoSize("\x13""Pay the Long Index."),
            TempStrNoSize("\x1E""long Index Schedule object ID."),
            TempStrNoSize("\x1F""long Index IborIndex object ID."),
            TempStrNoSize("\x2A""long indexleg spread. Default value = 0.0."),
            TempStrNoSize("\x1F""short Index Schedule object ID."),
            TempStrNoSize("\x20""short Index IborIndex object ID."),
            TempStrNoSize("\x2B""short indexleg spread. Default value = 0.0."),
            TempStrNoSize("\x1E""Include Spread in Compounding."),
            TempStrNoSize("\x5B""AVERAGING to average the ois rate, COMPOUNDING to compound it. Default value = Compounding."),
            TempStrNoSize("\x1D""object permanent/nonpermanent"),
            TempStrNoSize("\x1B""dependency tracking trigger"),
            TempStrNoSize("\x10""overwrite flag  "));

        Excel(xlfRegister, 0, 26, &xDll,
            // function code name
            TempStrNoSize("\x11""qlTenorBasisSwap2"),
            // parameter codes
            TempStrNoSize("\x12""CCPPCLCPCPCCLPPPL#"),
            // function display name
            TempStrNoSize("\x11""qlTenorBasisSwap2"),
            // comma-delimited list of parameter names
            TempStrNoSize("\xD5""ObjectId,EffectiveDate,Nominal,SwapTenor,PayLongIndex,LongIborIndex,LongIndexSpread,ShortIborIndex,ShortIndexSpread,ShortLegPaymentTenor,DateGeneration,IncludeSpread,AvergingCompounding,Permanent,Trigger,Overwrite"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x3D""Construct an object of class TenorBasisSwap and return its id"),
            // parameter descriptions
            TempStrNoSize("\x1A""id of object to be created"),
            TempStrNoSize("\x0F""effective date."),
            TempStrNoSize("\x25""Notional Amount. Default value = 100."),
            TempStrNoSize("\x0B""Swap Tenor."),
            TempStrNoSize("\x13""Pay the Long Index."),
            TempStrNoSize("\x1F""long Index IborIndex object ID."),
            TempStrNoSize("\x2A""long indexleg spread. Default value = 0.0."),
            TempStrNoSize("\x20""short Index IborIndex object ID."),
            TempStrNoSize("\x2B""short indexleg spread. Default value = 0.0."),
            TempStrNoSize("\x35""short index leg payment tenor (e.g. 1Y for one year)."),
            TempStrNoSize("\x29""Date Generateion Rule (Backward/Forward)."),
            TempStrNoSize("\x1E""Include Spread in Compounding."),
            TempStrNoSize("\x5B""AVERAGING to average the ois rate, COMPOUNDING to compound it. Default value = Compounding."),
            TempStrNoSize("\x1D""object permanent/nonpermanent"),
            TempStrNoSize("\x1B""dependency tracking trigger"),
            TempStrNoSize("\x10""overwrite flag  "));

        Excel(xlfRegister, 0, 13, &xDll,
            // function code name
            TempStrNoSize("\x24""qlTenorBasisSwapLongIndexLegAnalysis"),
            // parameter codes
            TempStrNoSize("\x05""PCPP#"),
            // function display name
            TempStrNoSize("\x24""qlTenorBasisSwapLongIndexLegAnalysis"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x1A""ObjectId,AfterDate,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x51""returns the long index leg cash flow analysis of the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x33""id of existing QuantLibAddin::TenorBasisSwap object"),
            TempStrNoSize("\x47""Shows only cashflows after given date Default value = QuantLib::Date()."),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x1F""qlTenorBasisSwapLongIndexLegBPS"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x1F""qlTenorBasisSwapLongIndexLegBPS"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x4A""returns the BPS of the long index leg for the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x2E""id of existing QuantLib::TenorBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x26""qlTenorBasisSwapLongIndexLegFairSpread"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x26""qlTenorBasisSwapLongIndexLegFairSpread"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x52""returns the Fair Spread of the long index leg for the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x2E""id of existing QuantLib::TenorBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x1F""qlTenorBasisSwapLongIndexLegNPV"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x1F""qlTenorBasisSwapLongIndexLegNPV"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x4A""returns the NPV of the long index leg for the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x2E""id of existing QuantLib::TenorBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x1F""qlTenorBasisSwapLongIndexSpread"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x1F""qlTenorBasisSwapLongIndexSpread"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x4D""returns the spread for the Long Index Leg of the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x2E""id of existing QuantLib::TenorBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x17""qlTenorBasisSwapNominal"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x17""qlTenorBasisSwapNominal"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x38""returns the nominal for the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x2E""id of existing QuantLib::TenorBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x1C""qlTenorBasisSwapPayLongIndex"),
            // parameter codes
            TempStrNoSize("\x04""LCP#"),
            // function display name
            TempStrNoSize("\x1C""qlTenorBasisSwapPayLongIndex"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x61""returns true/false for whether or not the Long Index is paid for the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x2E""id of existing QuantLib::TenorBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x27""qlTenorBasisSwapShortIndexIncludeSpread"),
            // parameter codes
            TempStrNoSize("\x04""LCP#"),
            // function display name
            TempStrNoSize("\x27""qlTenorBasisSwapShortIndexIncludeSpread"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x85""returns true/false depending on whether or not the Short Index Spread is included in compounding for the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x2E""id of existing QuantLib::TenorBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel(xlfRegister, 0, 13, &xDll,
            // function code name
            TempStrNoSize("\x25""qlTenorBasisSwapShortIndexLegAnalysis"),
            // parameter codes
            TempStrNoSize("\x05""PCPP#"),
            // function display name
            TempStrNoSize("\x25""qlTenorBasisSwapShortIndexLegAnalysis"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x1A""ObjectId,AfterDate,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x34""returns the short index rate leg cash flow analysis."),
            // parameter descriptions
            TempStrNoSize("\x33""id of existing QuantLibAddin::TenorBasisSwap object"),
            TempStrNoSize("\x47""Shows only cashflows after given date Default value = QuantLib::Date()."),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x20""qlTenorBasisSwapShortIndexLegBPS"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x20""qlTenorBasisSwapShortIndexLegBPS"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x4B""returns the BPS of the short index leg for the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x2E""id of existing QuantLib::TenorBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x27""qlTenorBasisSwapShortIndexLegFairSpread"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x27""qlTenorBasisSwapShortIndexLegFairSpread"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x53""returns the Fair Spread of the short index leg for the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x2E""id of existing QuantLib::TenorBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x20""qlTenorBasisSwapShortIndexLegNPV"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x20""qlTenorBasisSwapShortIndexLegNPV"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x4B""returns the NPV of the short index leg for the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x2E""id of existing QuantLib::TenorBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x22""qlTenorBasisSwapShortIndexPayTenor"),
            // parameter codes
            TempStrNoSize("\x04""CCP#"),
            // function display name
            TempStrNoSize("\x22""qlTenorBasisSwapShortIndexPayTenor"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x55""returns the payment tenor for the Short Index Leg of the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x2E""id of existing QuantLib::TenorBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x20""qlTenorBasisSwapShortIndexSpread"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x20""qlTenorBasisSwapShortIndexSpread"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x4E""returns the spread for the Short Index Leg of the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x2E""id of existing QuantLib::TenorBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));



}

// unregister functions in category Tenorbasisswap with Excel

void unregisterTenorbasisswap(const XLOPER &xDll) {

    XLOPER xlRegID;

    // Unregister each function.  Due to a bug in Excel's C API this is a
    // two-step process.  Thanks to Laurent Longre for discovering the
    // workaround implemented here.

        Excel(xlfRegister, 0, 24, &xDll,
            // function code name
            TempStrNoSize("\x10""qlTenorBasisSwap"),
            // parameter codes
            TempStrNoSize("\x10""CCPLCCPCCPLPPPL#"),
            // function display name
            TempStrNoSize("\x10""qlTenorBasisSwap"),
            // comma-delimited list of parameter names
            TempStrNoSize("\xBE""ObjectId,Nominal,PayLongIndex,LongIndexSchedule,LongIborIndex,LongIndexSpread,ShortIndexSchedule,ShortIborIndex,ShortIndexSpread,IncludeSpread,AvergingCompounding,Permanent,Trigger,Overwrite"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x3D""Construct an object of class TenorBasisSwap and return its id"),
            // parameter descriptions
            TempStrNoSize("\x1A""id of object to be created"),
            TempStrNoSize("\x25""Notional Amount. Default value = 100."),
            TempStrNoSize("\x13""Pay the Long Index."),
            TempStrNoSize("\x1E""long Index Schedule object ID."),
            TempStrNoSize("\x1F""long Index IborIndex object ID."),
            TempStrNoSize("\x2A""long indexleg spread. Default value = 0.0."),
            TempStrNoSize("\x1F""short Index Schedule object ID."),
            TempStrNoSize("\x20""short Index IborIndex object ID."),
            TempStrNoSize("\x2B""short indexleg spread. Default value = 0.0."),
            TempStrNoSize("\x1E""Include Spread in Compounding."),
            TempStrNoSize("\x5B""AVERAGING to average the ois rate, COMPOUNDING to compound it. Default value = Compounding."),
            TempStrNoSize("\x1D""object permanent/nonpermanent"),
            TempStrNoSize("\x1B""dependency tracking trigger"),
            TempStrNoSize("\x10""overwrite flag  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x10""qlTenorBasisSwap"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 26, &xDll,
            // function code name
            TempStrNoSize("\x11""qlTenorBasisSwap2"),
            // parameter codes
            TempStrNoSize("\x12""CCPPCLCPCPCCLPPPL#"),
            // function display name
            TempStrNoSize("\x11""qlTenorBasisSwap2"),
            // comma-delimited list of parameter names
            TempStrNoSize("\xD5""ObjectId,EffectiveDate,Nominal,SwapTenor,PayLongIndex,LongIborIndex,LongIndexSpread,ShortIborIndex,ShortIndexSpread,ShortLegPaymentTenor,DateGeneration,IncludeSpread,AvergingCompounding,Permanent,Trigger,Overwrite"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x3D""Construct an object of class TenorBasisSwap and return its id"),
            // parameter descriptions
            TempStrNoSize("\x1A""id of object to be created"),
            TempStrNoSize("\x0F""effective date."),
            TempStrNoSize("\x25""Notional Amount. Default value = 100."),
            TempStrNoSize("\x0B""Swap Tenor."),
            TempStrNoSize("\x13""Pay the Long Index."),
            TempStrNoSize("\x1F""long Index IborIndex object ID."),
            TempStrNoSize("\x2A""long indexleg spread. Default value = 0.0."),
            TempStrNoSize("\x20""short Index IborIndex object ID."),
            TempStrNoSize("\x2B""short indexleg spread. Default value = 0.0."),
            TempStrNoSize("\x35""short index leg payment tenor (e.g. 1Y for one year)."),
            TempStrNoSize("\x29""Date Generateion Rule (Backward/Forward)."),
            TempStrNoSize("\x1E""Include Spread in Compounding."),
            TempStrNoSize("\x5B""AVERAGING to average the ois rate, COMPOUNDING to compound it. Default value = Compounding."),
            TempStrNoSize("\x1D""object permanent/nonpermanent"),
            TempStrNoSize("\x1B""dependency tracking trigger"),
            TempStrNoSize("\x10""overwrite flag  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x11""qlTenorBasisSwap2"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 13, &xDll,
            // function code name
            TempStrNoSize("\x24""qlTenorBasisSwapLongIndexLegAnalysis"),
            // parameter codes
            TempStrNoSize("\x05""PCPP#"),
            // function display name
            TempStrNoSize("\x24""qlTenorBasisSwapLongIndexLegAnalysis"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x1A""ObjectId,AfterDate,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x51""returns the long index leg cash flow analysis of the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x33""id of existing QuantLibAddin::TenorBasisSwap object"),
            TempStrNoSize("\x47""Shows only cashflows after given date Default value = QuantLib::Date()."),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x24""qlTenorBasisSwapLongIndexLegAnalysis"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x1F""qlTenorBasisSwapLongIndexLegBPS"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x1F""qlTenorBasisSwapLongIndexLegBPS"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x4A""returns the BPS of the long index leg for the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x2E""id of existing QuantLib::TenorBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x1F""qlTenorBasisSwapLongIndexLegBPS"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x26""qlTenorBasisSwapLongIndexLegFairSpread"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x26""qlTenorBasisSwapLongIndexLegFairSpread"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x52""returns the Fair Spread of the long index leg for the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x2E""id of existing QuantLib::TenorBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x26""qlTenorBasisSwapLongIndexLegFairSpread"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x1F""qlTenorBasisSwapLongIndexLegNPV"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x1F""qlTenorBasisSwapLongIndexLegNPV"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x4A""returns the NPV of the long index leg for the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x2E""id of existing QuantLib::TenorBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x1F""qlTenorBasisSwapLongIndexLegNPV"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x1F""qlTenorBasisSwapLongIndexSpread"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x1F""qlTenorBasisSwapLongIndexSpread"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x4D""returns the spread for the Long Index Leg of the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x2E""id of existing QuantLib::TenorBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x1F""qlTenorBasisSwapLongIndexSpread"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x17""qlTenorBasisSwapNominal"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x17""qlTenorBasisSwapNominal"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x38""returns the nominal for the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x2E""id of existing QuantLib::TenorBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x17""qlTenorBasisSwapNominal"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x1C""qlTenorBasisSwapPayLongIndex"),
            // parameter codes
            TempStrNoSize("\x04""LCP#"),
            // function display name
            TempStrNoSize("\x1C""qlTenorBasisSwapPayLongIndex"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x61""returns true/false for whether or not the Long Index is paid for the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x2E""id of existing QuantLib::TenorBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x1C""qlTenorBasisSwapPayLongIndex"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x27""qlTenorBasisSwapShortIndexIncludeSpread"),
            // parameter codes
            TempStrNoSize("\x04""LCP#"),
            // function display name
            TempStrNoSize("\x27""qlTenorBasisSwapShortIndexIncludeSpread"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x85""returns true/false depending on whether or not the Short Index Spread is included in compounding for the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x2E""id of existing QuantLib::TenorBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x27""qlTenorBasisSwapShortIndexIncludeSpread"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 13, &xDll,
            // function code name
            TempStrNoSize("\x25""qlTenorBasisSwapShortIndexLegAnalysis"),
            // parameter codes
            TempStrNoSize("\x05""PCPP#"),
            // function display name
            TempStrNoSize("\x25""qlTenorBasisSwapShortIndexLegAnalysis"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x1A""ObjectId,AfterDate,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x34""returns the short index rate leg cash flow analysis."),
            // parameter descriptions
            TempStrNoSize("\x33""id of existing QuantLibAddin::TenorBasisSwap object"),
            TempStrNoSize("\x47""Shows only cashflows after given date Default value = QuantLib::Date()."),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x25""qlTenorBasisSwapShortIndexLegAnalysis"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x20""qlTenorBasisSwapShortIndexLegBPS"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x20""qlTenorBasisSwapShortIndexLegBPS"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x4B""returns the BPS of the short index leg for the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x2E""id of existing QuantLib::TenorBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x20""qlTenorBasisSwapShortIndexLegBPS"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x27""qlTenorBasisSwapShortIndexLegFairSpread"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x27""qlTenorBasisSwapShortIndexLegFairSpread"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x53""returns the Fair Spread of the short index leg for the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x2E""id of existing QuantLib::TenorBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x27""qlTenorBasisSwapShortIndexLegFairSpread"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x20""qlTenorBasisSwapShortIndexLegNPV"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x20""qlTenorBasisSwapShortIndexLegNPV"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x4B""returns the NPV of the short index leg for the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x2E""id of existing QuantLib::TenorBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x20""qlTenorBasisSwapShortIndexLegNPV"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x22""qlTenorBasisSwapShortIndexPayTenor"),
            // parameter codes
            TempStrNoSize("\x04""CCP#"),
            // function display name
            TempStrNoSize("\x22""qlTenorBasisSwapShortIndexPayTenor"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x55""returns the payment tenor for the Short Index Leg of the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x2E""id of existing QuantLib::TenorBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x22""qlTenorBasisSwapShortIndexPayTenor"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x20""qlTenorBasisSwapShortIndexSpread"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x20""qlTenorBasisSwapShortIndexSpread"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x4E""returns the spread for the Short Index Leg of the given TenorBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x2E""id of existing QuantLib::TenorBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x20""qlTenorBasisSwapShortIndexSpread"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);



}

