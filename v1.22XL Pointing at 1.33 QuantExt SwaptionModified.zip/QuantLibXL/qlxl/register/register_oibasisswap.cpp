
/*  
 Copyright (C) 2004, 2005, 2006, 2007, 2008 Eric Ehlers
 
 This file is part of QuantLib, a free-software/open-source library
 for financial quantitative analysts and developers - http://quantlib.org/

 QuantLib is free software: you can redistribute it and/or modify it
 under the terms of the QuantLib license.  You should have received a
 copy of the license along with this program; if not, please email
 <quantlib-dev@lists.sf.net>. The license is also available online at
 <http://quantlib.org/license.shtml>.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE.  See the license for more details.
*/

// This file was generated automatically by gensrc.py.  If you edit this file
// manually then your changes will be lost the next time gensrc runs.

// This source code file was generated from the following stub:
//      gensrc/gensrc/stubs/stub.excel.register.file

#include <xlsdk/xlsdkdefines.hpp>

// register functions in category Oibasisswap with Excel

void registerOibasisswap(const XLOPER &xDll) {

        Excel(xlfRegister, 0, 22, &xDll,
            // function code name
            TempStrNoSize("\x25""qlOvernightIndexedBasisAmortizingSwap"),
            // parameter codes
            TempStrNoSize("\x0E""CCPPCCCCPPPPL#"),
            // function display name
            TempStrNoSize("\x25""qlOvernightIndexedBasisAmortizingSwap"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x8F""ObjectId,PayerReceiver,Nominal,OISIndexSchedule,OisIndex,IborIndexSchedule,IborIndex,OISIndexSpread,IborIndexSpread,Permanent,Trigger,Overwrite"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x48""Construct an object of class OvernightIndexedBasisSwap and return its id"),
            // parameter descriptions
            TempStrNoSize("\x1A""id of object to be created"),
            TempStrNoSize("\x49""PAYER to pay the ois rate, RECEIVER to receive it. Default value = Payer."),
            TempStrNoSize("\x24""Nominal vector. Default value = 100."),
            TempStrNoSize("\x1E""long Index Schedule object ID."),
            TempStrNoSize("\x24""overnight Index IborIndex object ID."),
            TempStrNoSize("\x1F""short Index Schedule object ID."),
            TempStrNoSize("\x20""short Index IborIndex object ID."),
            TempStrNoSize("\x2B""short indexleg spread. Default value = 0.0."),
            TempStrNoSize("\x2B""short indexleg spread. Default value = 0.0."),
            TempStrNoSize("\x1D""object permanent/nonpermanent"),
            TempStrNoSize("\x1B""dependency tracking trigger"),
            TempStrNoSize("\x10""overwrite flag  "));

        Excel(xlfRegister, 0, 22, &xDll,
            // function code name
            TempStrNoSize("\x1B""qlOvernightIndexedBasisSwap"),
            // parameter codes
            TempStrNoSize("\x0E""CCPPCCCCPPPPL#"),
            // function display name
            TempStrNoSize("\x1B""qlOvernightIndexedBasisSwap"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x8F""ObjectId,PayerReceiver,Nominal,OISIndexSchedule,OisIndex,IborIndexSchedule,IborIndex,OISIndexSpread,IborIndexSpread,Permanent,Trigger,Overwrite"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x48""Construct an object of class OvernightIndexedBasisSwap and return its id"),
            // parameter descriptions
            TempStrNoSize("\x1A""id of object to be created"),
            TempStrNoSize("\x49""PAYER to pay the ois rate, RECEIVER to receive it. Default value = Payer."),
            TempStrNoSize("\x25""Notional Amount. Default value = 100."),
            TempStrNoSize("\x1E""long Index Schedule object ID."),
            TempStrNoSize("\x24""overnight Index IborIndex object ID."),
            TempStrNoSize("\x1F""short Index Schedule object ID."),
            TempStrNoSize("\x20""short Index IborIndex object ID."),
            TempStrNoSize("\x2B""short indexleg spread. Default value = 0.0."),
            TempStrNoSize("\x2B""short indexleg spread. Default value = 0.0."),
            TempStrNoSize("\x1D""object permanent/nonpermanent"),
            TempStrNoSize("\x1B""dependency tracking trigger"),
            TempStrNoSize("\x10""overwrite flag  "));

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x25""qlOvernightIndexedBasisSwapIborLegBPS"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x25""qlOvernightIndexedBasisSwapIborLegBPS"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x52""returns the spread for the IBOR leg of the given OvernightIndexedBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x39""id of existing QuantLib::OvernightIndexedBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x35""qlOvernightIndexedBasisSwapIborLegFairOvernightSpread"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x35""qlOvernightIndexedBasisSwapIborLegFairOvernightSpread"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x5C""returns the fair ibor spread for the IBOR leg of the given OvernightIndexedBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x39""id of existing QuantLib::OvernightIndexedBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x25""qlOvernightIndexedBasisSwapIborLegNPV"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x25""qlOvernightIndexedBasisSwapIborLegNPV"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x4B""returns the NPV the IBOR leg of the given OvernightIndexedBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x39""id of existing QuantLib::OvernightIndexedBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x25""qlOvernightIndexedBasisSwapIborSpread"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x25""qlOvernightIndexedBasisSwapIborSpread"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x52""returns the spread for the IBOR leg of the given OvernightIndexedBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x39""id of existing QuantLib::OvernightIndexedBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x22""qlOvernightIndexedBasisSwapNominal"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x22""qlOvernightIndexedBasisSwapNominal"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x43""returns the nominal for the given OvernightIndexedBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x39""id of existing QuantLib::OvernightIndexedBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x24""qlOvernightIndexedBasisSwapOisLegBPS"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x24""qlOvernightIndexedBasisSwapOisLegBPS"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x51""returns the spread for the OIS leg of the given OvernightIndexedBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x39""id of existing QuantLib::OvernightIndexedBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x34""qlOvernightIndexedBasisSwapOisLegFairOvernightSpread"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x34""qlOvernightIndexedBasisSwapOisLegFairOvernightSpread"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x60""returns the fair overnight spread for the OIS leg of the given OvernightIndexedBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x39""id of existing QuantLib::OvernightIndexedBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x24""qlOvernightIndexedBasisSwapOisLegNPV"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x24""qlOvernightIndexedBasisSwapOisLegNPV"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x4E""returns the NPV for the OIS leg of the given OvernightIndexedBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x39""id of existing QuantLib::OvernightIndexedBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x24""qlOvernightIndexedBasisSwapOisSpread"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x24""qlOvernightIndexedBasisSwapOisSpread"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x51""returns the spread for the OIS leg of the given OvernightIndexedBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x39""id of existing QuantLib::OvernightIndexedBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x1F""qlOvernightIndexedBasisSwapType"),
            // parameter codes
            TempStrNoSize("\x04""CCP#"),
            // function display name
            TempStrNoSize("\x1F""qlOvernightIndexedBasisSwapType"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""1"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x58""returns the swap type (Payer or Receiver) of the given OvernightIndexedBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x39""id of existing QuantLib::OvernightIndexedBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));



}

// unregister functions in category Oibasisswap with Excel

void unregisterOibasisswap(const XLOPER &xDll) {

    XLOPER xlRegID;

    // Unregister each function.  Due to a bug in Excel's C API this is a
    // two-step process.  Thanks to Laurent Longre for discovering the
    // workaround implemented here.

        Excel(xlfRegister, 0, 22, &xDll,
            // function code name
            TempStrNoSize("\x25""qlOvernightIndexedBasisAmortizingSwap"),
            // parameter codes
            TempStrNoSize("\x0E""CCPPCCCCPPPPL#"),
            // function display name
            TempStrNoSize("\x25""qlOvernightIndexedBasisAmortizingSwap"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x8F""ObjectId,PayerReceiver,Nominal,OISIndexSchedule,OisIndex,IborIndexSchedule,IborIndex,OISIndexSpread,IborIndexSpread,Permanent,Trigger,Overwrite"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x48""Construct an object of class OvernightIndexedBasisSwap and return its id"),
            // parameter descriptions
            TempStrNoSize("\x1A""id of object to be created"),
            TempStrNoSize("\x49""PAYER to pay the ois rate, RECEIVER to receive it. Default value = Payer."),
            TempStrNoSize("\x24""Nominal vector. Default value = 100."),
            TempStrNoSize("\x1E""long Index Schedule object ID."),
            TempStrNoSize("\x24""overnight Index IborIndex object ID."),
            TempStrNoSize("\x1F""short Index Schedule object ID."),
            TempStrNoSize("\x20""short Index IborIndex object ID."),
            TempStrNoSize("\x2B""short indexleg spread. Default value = 0.0."),
            TempStrNoSize("\x2B""short indexleg spread. Default value = 0.0."),
            TempStrNoSize("\x1D""object permanent/nonpermanent"),
            TempStrNoSize("\x1B""dependency tracking trigger"),
            TempStrNoSize("\x10""overwrite flag  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x25""qlOvernightIndexedBasisAmortizingSwap"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 22, &xDll,
            // function code name
            TempStrNoSize("\x1B""qlOvernightIndexedBasisSwap"),
            // parameter codes
            TempStrNoSize("\x0E""CCPPCCCCPPPPL#"),
            // function display name
            TempStrNoSize("\x1B""qlOvernightIndexedBasisSwap"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x8F""ObjectId,PayerReceiver,Nominal,OISIndexSchedule,OisIndex,IborIndexSchedule,IborIndex,OISIndexSpread,IborIndexSpread,Permanent,Trigger,Overwrite"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x48""Construct an object of class OvernightIndexedBasisSwap and return its id"),
            // parameter descriptions
            TempStrNoSize("\x1A""id of object to be created"),
            TempStrNoSize("\x49""PAYER to pay the ois rate, RECEIVER to receive it. Default value = Payer."),
            TempStrNoSize("\x25""Notional Amount. Default value = 100."),
            TempStrNoSize("\x1E""long Index Schedule object ID."),
            TempStrNoSize("\x24""overnight Index IborIndex object ID."),
            TempStrNoSize("\x1F""short Index Schedule object ID."),
            TempStrNoSize("\x20""short Index IborIndex object ID."),
            TempStrNoSize("\x2B""short indexleg spread. Default value = 0.0."),
            TempStrNoSize("\x2B""short indexleg spread. Default value = 0.0."),
            TempStrNoSize("\x1D""object permanent/nonpermanent"),
            TempStrNoSize("\x1B""dependency tracking trigger"),
            TempStrNoSize("\x10""overwrite flag  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x1B""qlOvernightIndexedBasisSwap"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x25""qlOvernightIndexedBasisSwapIborLegBPS"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x25""qlOvernightIndexedBasisSwapIborLegBPS"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x52""returns the spread for the IBOR leg of the given OvernightIndexedBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x39""id of existing QuantLib::OvernightIndexedBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x25""qlOvernightIndexedBasisSwapIborLegBPS"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x35""qlOvernightIndexedBasisSwapIborLegFairOvernightSpread"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x35""qlOvernightIndexedBasisSwapIborLegFairOvernightSpread"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x5C""returns the fair ibor spread for the IBOR leg of the given OvernightIndexedBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x39""id of existing QuantLib::OvernightIndexedBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x35""qlOvernightIndexedBasisSwapIborLegFairOvernightSpread"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x25""qlOvernightIndexedBasisSwapIborLegNPV"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x25""qlOvernightIndexedBasisSwapIborLegNPV"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x4B""returns the NPV the IBOR leg of the given OvernightIndexedBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x39""id of existing QuantLib::OvernightIndexedBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x25""qlOvernightIndexedBasisSwapIborLegNPV"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x25""qlOvernightIndexedBasisSwapIborSpread"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x25""qlOvernightIndexedBasisSwapIborSpread"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x52""returns the spread for the IBOR leg of the given OvernightIndexedBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x39""id of existing QuantLib::OvernightIndexedBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x25""qlOvernightIndexedBasisSwapIborSpread"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x22""qlOvernightIndexedBasisSwapNominal"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x22""qlOvernightIndexedBasisSwapNominal"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x43""returns the nominal for the given OvernightIndexedBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x39""id of existing QuantLib::OvernightIndexedBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x22""qlOvernightIndexedBasisSwapNominal"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x24""qlOvernightIndexedBasisSwapOisLegBPS"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x24""qlOvernightIndexedBasisSwapOisLegBPS"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x51""returns the spread for the OIS leg of the given OvernightIndexedBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x39""id of existing QuantLib::OvernightIndexedBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x24""qlOvernightIndexedBasisSwapOisLegBPS"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x34""qlOvernightIndexedBasisSwapOisLegFairOvernightSpread"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x34""qlOvernightIndexedBasisSwapOisLegFairOvernightSpread"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x60""returns the fair overnight spread for the OIS leg of the given OvernightIndexedBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x39""id of existing QuantLib::OvernightIndexedBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x34""qlOvernightIndexedBasisSwapOisLegFairOvernightSpread"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x24""qlOvernightIndexedBasisSwapOisLegNPV"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x24""qlOvernightIndexedBasisSwapOisLegNPV"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x4E""returns the NPV for the OIS leg of the given OvernightIndexedBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x39""id of existing QuantLib::OvernightIndexedBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x24""qlOvernightIndexedBasisSwapOisLegNPV"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x24""qlOvernightIndexedBasisSwapOisSpread"),
            // parameter codes
            TempStrNoSize("\x04""ECP#"),
            // function display name
            TempStrNoSize("\x24""qlOvernightIndexedBasisSwapOisSpread"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x51""returns the spread for the OIS leg of the given OvernightIndexedBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x39""id of existing QuantLib::OvernightIndexedBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x24""qlOvernightIndexedBasisSwapOisSpread"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);

        Excel(xlfRegister, 0, 12, &xDll,
            // function code name
            TempStrNoSize("\x1F""qlOvernightIndexedBasisSwapType"),
            // parameter codes
            TempStrNoSize("\x04""CCP#"),
            // function display name
            TempStrNoSize("\x1F""qlOvernightIndexedBasisSwapType"),
            // comma-delimited list of parameter names
            TempStrNoSize("\x10""ObjectId,Trigger"),
            // function type (0 = hidden, 1 = worksheet)
            TempStrNoSize("\x01""0"),
            // function category
            TempStrNoSize("\x14""QuantLib - Financial"),
            // shortcut text (command macros only)
            TempStrNoSize("\x00"""),
            // path to help file
            TempStrNoSize("\x00"""),
            // function description
            TempStrNoSize("\x58""returns the swap type (Payer or Receiver) of the given OvernightIndexedBasisSwap object."),
            // parameter descriptions
            TempStrNoSize("\x39""id of existing QuantLib::OvernightIndexedBasisSwap object"),
            TempStrNoSize("\x1D""dependency tracking trigger  "));

        Excel4(xlfRegisterId, &xlRegID, 2, &xDll,
            TempStrNoSize("\x1F""qlOvernightIndexedBasisSwapType"));
        Excel4(xlfUnregister, 0, 1, &xlRegID);



}

