
/*
 Copyright (C) 2004, 2005, 2007, 2008 StatPro Italia srl
 Copyright (C) 2010 Klaus Spanderen
 Copyright (C) 2015 Matthias Groncki
 Copyright (C) 2018, 2019 Matthias Lungwitz
 Copyright (C) 2019 Pedro Coelho

 This file is part of QuantLib, a free-software/open-source library
 for financial quantitative analysts and developers - http://quantlib.org/

 QuantLib is free software: you can redistribute it and/or modify it
 under the terms of the QuantLib license.  You should have received a
 copy of the license along with this program; if not, please email
 <quantlib-dev@lists.sf.net>. The license is also available online at
 <http://quantlib.org/license.shtml>.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE.  See the license for more details.
*/

#ifndef quantlib_stochastic_process_i
#define quantlib_stochastic_process_i

%include marketelements.i
%include termstructures.i
%include volatilities.i
%include observer.i
%include linearalgebra.i
%include vectors.i
%include parameter.i

%{
using QuantLib::StochasticProcess;
%}

%shared_ptr(StochasticProcess)
class StochasticProcess : public Observable {
  private:
    StochasticProcess();
  public:
    Size size() const;
    Size factors() const;
    Array initialValues() const;
    Array drift(Time t, const Array& x) const;
    Matrix diffusion(Time t, const Array& x) const;
    Array expectation(Time t0, const Array& x0, Time dt) const;
    Matrix stdDeviation(Time t0, const Array& x0, Time dt) const;
    Matrix covariance(Time t0, const Array& x0, Time dt) const;
    Array evolve(Time t0, const Array& x0,
                 Time dt, const Array& dw) const;
};

#if defined(SWIGCSHARP)
SWIG_STD_VECTOR_ENHANCED( ext::shared_ptr<StochasticProcess> )
#endif
%template(StochasticProcessVector)
std::vector<ext::shared_ptr<StochasticProcess> >;


%{
using QuantLib::StochasticProcess1D;
%}

%shared_ptr(StochasticProcess1D)
class StochasticProcess1D
    : public StochasticProcess {
  public:
      Real x0() const;
      Real drift(Time t, Real x) const;
      Real diffusion(Time t, Real x) const;
      Real expectation(Time t0, Real x0, Time dt) const;
      Real stdDeviation(Time t0, Real x0, Time dt) const;
      Real variance(Time t0, Real x0, Time dt) const;
      Real evolve(Time t0, Real x0, Time dt, Real dw) const;
      Real apply(Real x0, Real dx) const;
};

#if defined(SWIGCSHARP)
SWIG_STD_VECTOR_ENHANCED( ext::shared_ptr<StochasticProcess1D> )
#endif
%template(StochasticProcess1DVector)
std::vector<ext::shared_ptr<StochasticProcess1D> >;


%{
using QuantLib::GeneralizedBlackScholesProcess;
%}

%shared_ptr(GeneralizedBlackScholesProcess)
class GeneralizedBlackScholesProcess : public StochasticProcess1D {
  public:
      GeneralizedBlackScholesProcess(
                             const Handle<Quote>& s0,
                             const Handle<YieldTermStructure>& dividendTS,
                             const Handle<YieldTermStructure>& riskFreeTS,
                             const Handle<BlackVolTermStructure>& volTS);

      GeneralizedBlackScholesProcess(
            const Handle<Quote>& x0,
            const Handle<YieldTermStructure>& dividendTS,
            const Handle<YieldTermStructure>& riskFreeTS,
            const Handle<BlackVolTermStructure>& blackVolTS,
            const Handle<LocalVolTermStructure>& localVolTS);

      Handle<Quote> stateVariable();
      Handle<YieldTermStructure> dividendYield();
      Handle<YieldTermStructure> riskFreeRate();
      Handle<BlackVolTermStructure> blackVolatility();
      Handle<LocalVolTermStructure> localVolatility();
};

%{
using QuantLib::BlackScholesProcess;
%}

%shared_ptr(BlackScholesProcess)
class BlackScholesProcess : public GeneralizedBlackScholesProcess {
  public:
  BlackScholesProcess(const Handle<Quote>& s0,
                           const Handle<YieldTermStructure>& riskFreeTS,
                           const Handle<BlackVolTermStructure>& volTS);
};

%{
using QuantLib::BlackScholesMertonProcess;
%}

%shared_ptr(BlackScholesMertonProcess)
class BlackScholesMertonProcess : public GeneralizedBlackScholesProcess {
  public:
      BlackScholesMertonProcess(
                             const Handle<Quote>& s0,
                             const Handle<YieldTermStructure>& dividendTS,
                             const Handle<YieldTermStructure>& riskFreeTS,
                             const Handle<BlackVolTermStructure>& volTS);
};

%{
using QuantLib::BlackProcess;
%}

%shared_ptr(BlackProcess)
class BlackProcess : public GeneralizedBlackScholesProcess {
  public:
      BlackProcess(const Handle<Quote>& s0,
                      const Handle<YieldTermStructure>& riskFreeTS,
                      const Handle<BlackVolTermStructure>& volTS);
};

%{
using QuantLib::GarmanKohlagenProcess;
%}

%shared_ptr(GarmanKohlagenProcess)
class GarmanKohlagenProcess : public GeneralizedBlackScholesProcess {
  public:
      GarmanKohlagenProcess(
                         const Handle<Quote>& s0,
                         const Handle<YieldTermStructure>& foreignRiskFreeTS,
                         const Handle<YieldTermStructure>& domesticRiskFreeTS,
                         const Handle<BlackVolTermStructure>& volTS);
};



%{
using QuantLib::Merton76Process;
%}

%shared_ptr(Merton76Process)
class Merton76Process : public StochasticProcess1D {
  public:
      Merton76Process(const Handle<Quote>& stateVariable,
                         const Handle<YieldTermStructure>& dividendTS,
                         const Handle<YieldTermStructure>& riskFreeTS,
                         const Handle<BlackVolTermStructure>& volTS,
                         const Handle<Quote>& jumpIntensity,
                         const Handle<Quote>& meanLogJump,
                         const Handle<Quote>& jumpVolatility);
};

%{
using QuantLib::StochasticProcessArray;
%}
/*
%shared_ptr(StochasticProcessArray)
class StochasticProcessArray : public StochasticProcess {
  public:
      StochasticProcessArray(
               const std::vector<ext::shared_ptr<StochasticProcess1D> >&array,
               const Matrix &correlation);
};
*/

%{
using QuantLib::GeometricBrownianMotionProcess;
%}

%shared_ptr(GeometricBrownianMotionProcess)
class GeometricBrownianMotionProcess : public StochasticProcess1D {
  public:
      GeometricBrownianMotionProcess(Real initialValue,
                                        Real mu,
                                        Real sigma);
};

%{
using QuantLib::VarianceGammaProcess;
%}

%shared_ptr(VarianceGammaProcess)
class VarianceGammaProcess : public StochasticProcess1D {
  public:
      VarianceGammaProcess(const Handle<Quote>& s0,
            const Handle<YieldTermStructure>& dividendYield,
            const Handle<YieldTermStructure>& riskFreeRate,
            Real sigma, Real nu, Real theta);
};


%{
using QuantLib::HestonProcess;
%}

%shared_ptr(HestonProcess)
class HestonProcess : public StochasticProcess {
  public:
        enum Discretization { PartialTruncation,
                    FullTruncation,
                    Reflection,
                    NonCentralChiSquareVariance,
                    QuadraticExponential,
                    QuadraticExponentialMartingale,
                    BroadieKayaExactSchemeLobatto,
                    BroadieKayaExactSchemeLaguerre,
                    BroadieKayaExactSchemeTrapezoidal };

        HestonProcess(const Handle<YieldTermStructure>& riskFreeTS,
					   const Handle<YieldTermStructure>& dividendTS,
					   const Handle<Quote>& s0,
					   Real v0, Real kappa,
                       Real theta, Real sigma, Real rho,
                       Discretization d = QuadraticExponentialMartingale);

        Handle<Quote> s0();
        Handle<YieldTermStructure> dividendYield();
        Handle<YieldTermStructure> riskFreeRate();
        Real pdf(Real x, Real v, Time t, Real eps=1e-3) const;
};

%{
using QuantLib::BatesProcess;
%}

%shared_ptr(BatesProcess)
class BatesProcess : public HestonProcess {
  public:
      BatesProcess(const Handle<YieldTermStructure>& riskFreeRate,
                      const Handle<YieldTermStructure>& dividendYield,
                      const Handle<Quote>& s0,
                      Real v0, Real kappa,
                      Real theta, Real sigma, Real rho,
                      Real lambda, Real nu, Real delta);
};

%{
using QuantLib::HullWhiteProcess;
%}

%shared_ptr(HullWhiteProcess)
class HullWhiteProcess : public StochasticProcess1D {
  public:
      HullWhiteProcess(const Handle<YieldTermStructure>& riskFreeTS,
                          Real a, Real sigma);
};

%{
using QuantLib::HullWhiteForwardProcess;
%}

%shared_ptr(HullWhiteForwardProcess)
class HullWhiteForwardProcess : public StochasticProcess1D {
  public:
    HullWhiteForwardProcess(const Handle<YieldTermStructure>& riskFreeTS,
                             Real a,
                             Real sigma);
    Real alpha(Time t) const;
    Real M_T(Real s, Real t, Real T) const;
    Real B(Time t, Time T) const;
    void setForwardMeasureTime(Time t);
};

%{
using QuantLib::G2Process;
%}

%shared_ptr(G2Process)
class G2Process : public StochasticProcess {
  public:
    G2Process(Real a, Real sigma, Real b, Real eta, Real rho);
};

%{
using QuantLib::G2ForwardProcess;
%}

%shared_ptr(G2ForwardProcess)
class G2ForwardProcess : public StochasticProcess {
  public:
    G2ForwardProcess(Real a, Real sigma, Real b, Real eta, Real rho);
    void setForwardMeasureTime(Time t);
};

%{
using QuantLib::GsrProcess;
%}

%shared_ptr(GsrProcess)
class GsrProcess : public StochasticProcess1D {
    public:
    GsrProcess(const Array &times, const Array &vols,
               const Array &reversions, const Real T = 60.0);
    Real sigma(Time t);
    Real reversion(Time t);
    Real y(Time t);
    Real G(Time t, Time T, Real x);
    void setForwardMeasureTime(Time t);
};

%inline %{
    const ext::shared_ptr<GsrProcess> as_gsr_process(
                           const ext::shared_ptr<StochasticProcess>& proc) {
        return ext::dynamic_pointer_cast<GsrProcess>(proc);
    }
%}


%{
using QuantLib::OrnsteinUhlenbeckProcess;
%}

%shared_ptr(OrnsteinUhlenbeckProcess)
class OrnsteinUhlenbeckProcess : public StochasticProcess1D {
  public:
    OrnsteinUhlenbeckProcess(
    	Real speed, Volatility vol, Real x0 = 0.0, Real level = 0.0);
    	    	
    Real speed() const;
    Real volatility() const;
    Real level() const;
};


%{
using QuantLib::KlugeExtOUProcess;
using QuantLib::ExtendedOrnsteinUhlenbeckProcess;
using QuantLib::ExtOUWithJumpsProcess;
%}

%shared_ptr(ExtendedOrnsteinUhlenbeckProcess)
class ExtendedOrnsteinUhlenbeckProcess : public StochasticProcess1D {
  public:
    enum Discretization { MidPoint, Trapezodial, GaussLobatto };
    %extend{                            
        #if defined(SWIGPYTHON)    
        ExtendedOrnsteinUhlenbeckProcess(
            Real speed, Volatility sigma, Real x0, 
            PyObject* function, 
            Real intEps = 1e-4) {
            
            const UnaryFunction f(function);
            return new ExtendedOrnsteinUhlenbeckProcess(
            	    speed, sigma, x0, f, 
            	    ExtendedOrnsteinUhlenbeckProcess::MidPoint, intEps);
        }
        #elif defined(SWIGJAVA) || defined(SWIGCSHARP)
        ExtendedOrnsteinUhlenbeckProcess(
            Real speed, Volatility sigma, Real x0, 
            UnaryFunctionDelegate* function,
            Real intEps = 1e-4) {
            
            const UnaryFunction f(function);
            return new ExtendedOrnsteinUhlenbeckProcess(
            	    speed, sigma, x0, f, 
            	    ExtendedOrnsteinUhlenbeckProcess::MidPoint, intEps);
        }
		#endif
    }
};

%shared_ptr(ExtOUWithJumpsProcess)
class ExtOUWithJumpsProcess : public StochasticProcess {
  public:
    ExtOUWithJumpsProcess(
            const ext::shared_ptr<ExtendedOrnsteinUhlenbeckProcess>& process,
            Real Y0, Real beta, Real jumpIntensity, Real eta);
};

%shared_ptr(KlugeExtOUProcess)
class KlugeExtOUProcess : public StochasticProcess {
  public:
    KlugeExtOUProcess(
            Real rho,
            const ext::shared_ptr<ExtOUWithJumpsProcess>& kluge,
            const ext::shared_ptr<ExtendedOrnsteinUhlenbeckProcess>& extOU);
};

%{
using QuantLib::GJRGARCHProcess;
%}

%shared_ptr(GJRGARCHProcess)
class GJRGARCHProcess : public StochasticProcess {
  public:
      enum Discretization { PartialTruncation, FullTruncation, Reflection};

      GJRGARCHProcess(const Handle<YieldTermStructure>& riskFreeRate,
                      const Handle<YieldTermStructure>& dividendYield,
                      const Handle<Quote>& s0,
                      Real v0, Real omega, Real alpha, Real beta,
                      Real gamma, Real lambda, Real daysPerYear = 252.0,
                      Discretization d = FullTruncation);

  Handle<Quote> s0();
  Handle<YieldTermStructure> dividendYield();
  Handle<YieldTermStructure> riskFreeRate();
};


%{
using QuantLib::StochasticProcessArray;
using QuantLib::Array;
using QuantLib::Matrix;

using QuantLib::Size;
%}
%shared_ptr(StochasticProcessArray)
class StochasticProcessArray : public StochasticProcess {
  public:
        StochasticProcessArray(
                  const std::vector<ext::shared_ptr<StochasticProcess1D> >&,
                  const Matrix& correlation);
	    Size size () const;
	    Array  initialValues() const;
	    Array  drift (Time t, const Array &x);
	    Array  expectation (Time t0, const Array &x0, Time dt) const;
	    Matrix  diffusion (Time t, const Array &x) const;
	    Matrix  covariance (Time t0, const Array &x0, Time dt) const;
	    Matrix  stdDeviation (Time t0, const Array &x0, Time dt) const;
	    Array  apply (const Array &x0, const Array &dx) const;
	    Array  evolve (Time t0, const Array &x0, Time dt, const Array &dw) const;
	    Time time (const Date &d) const;
		const ext::shared_ptr<StochasticProcess1D> process(Size i);
	    Matrix 	correlation ();
};

%{
using QuantLib::LfmCovarianceParameterization;
%}
%shared_ptr(LfmCovarianceParameterization)
class LfmCovarianceParameterization {
  public:
    LfmCovarianceParameterization (Size size, Size factors);
	Size 	size () const; 
	Size 	factors () const;
	Matrix	diffusion (Time t, const Array &x=Null< Array >()) const =0;
	Matrix 	covariance (Time t, const Array &x=Null< Array >()) const;
	Matrix 	integratedCovariance (Time t, const Array &x=Null< Array >()) const;
};

%{
using QuantLib::LiborForwardModelProcess;
using QuantLib::IborIndex;
using QuantLib::Leg;
using QuantLib::DiscountFactor;
%}

%shared_ptr(LiborForwardModelProcess)
class LiborForwardModelProcess : public StochasticProcess {
  public:
    LiborForwardModelProcess(Size size,
                                 const ext::shared_ptr<IborIndex>& index);
	Array  initialValues() const;
	Array  drift (Time t, const Array &x) const;
	Matrix diffusion (Time t, const Array &x) const;
    Matrix covariance (Time t0, const Array &x0, Time dt) const;
    Array  apply (const Array &x0, const Array &dx) const;
    Array  evolve (Time t0, const Array &x0, Time dt, const Array &dw) const;
    Size size () const;
    Size factors () const;
	ext::shared_ptr<IborIndex> index() const;
	Leg cashFlows (Real amount=1.0) const;
    void setCovarParam(const ext::shared_ptr<LfmCovarianceParameterization>& param);
    ext::shared_ptr<LfmCovarianceParameterization> covarParam() const;	
	Size nextIndexReset (Time t) const;
    const std::vector< Time > & fixingTimes () const;
    const std::vector< Date > & fixingDates () const;
    const std::vector< Time > & accrualStartTimes () const ;
    const std::vector< Time > & accrualEndTimes () const;
    std::vector< DiscountFactor >  discountBond (const std::vector< Rate > &rates) const;
};


%{
using QuantLib::LfmCovarianceProxy;
using QuantLib::LmVolatilityModel;
using QuantLib::LmCorrelationModel;
%}
%{
using QuantLib::LmLinearExponentialVolatilityModel;
using QuantLib::LmExtLinearExponentialVolModel;
using QuantLib::Volatility;
%}
%{
using QuantLib::LmExponentialCorrelationModel;
using QuantLib::LmLinearExponentialCorrelationModel;
%}


%shared_ptr(LfmCovarianceProxy)
class LfmCovarianceProxy: public LfmCovarianceParameterization {
  public:
      LfmCovarianceProxy(const ext::shared_ptr< LmVolatilityModel > &volaModel, 
			const ext::shared_ptr< LmCorrelationModel > &corrModel);
    ext::shared_ptr<LmVolatilityModel>  volatilityModel() const;
    ext::shared_ptr<LmCorrelationModel> correlationModel() const;
	Matrix  diffusion (Time t, const Array &x=Null<Array>()) const;
	Matrix  covariance (Time t, const Array &x=Null<Array>()) const;
	virtual Real integratedCovariance (Size i, Size j, Time t, const Array &x=Null< Array >()) const; 
};


%shared_ptr(LmVolatilityModel)
class LmVolatilityModel  {
  public:
	LmVolatilityModel(Size size, Size nArguments);
	Size size() const;
	std::vector< Parameter > & 	params ();
	void 	setParams (const std::vector< Parameter > &arguments);
	virtual Array volatility (Time t, const Array &x=Null< Array >()) const =0;
	virtual Volatility volatility (Size i, Time t, const Array &x=Null< Array >()) const;
	virtual Real integratedVariance (Size i, Size j, Time u, const Array &x=Null< Array >()) const;
};



%shared_ptr(LmCorrelationModel)
class LmCorrelationModel{
//   private:
//    LmCorrelationModel();
  public:
	LmCorrelationModel(Size size, Size nArguments);
    virtual Size size() const;
    virtual Size factors() const;
	std::vector< Parameter > & 	params ();
	void setParams (const std::vector< Parameter > &arguments);
	virtual Matrix  correlation (Time t, const Array &x=Null<Array>()) const = 0;
    virtual Matrix  pseudoSqrt (Time t, const Array &x=Null<Array>()) const;
	virtual Real correlation(Size i, Size j, Time t, const Array &x)const;
    virtual bool isTimeIndependent() const;
};


%shared_ptr(LmExponentialCorrelationModel)
class LmExponentialCorrelationModel : public LmCorrelationModel {
  public:
      LmExponentialCorrelationModel(Size size,
										Real rho);

    Matrix  correlation (Time t, const Array &x=Null<Array>()) const;
    Matrix  pseudoSqrt (Time t, const Array &x=Null<Array>()) const;
	Real correlation(Size i, Size j, Time t, const Array &x)const;
    bool isTimeIndependent() const;
};

%shared_ptr(LmLinearExponentialCorrelationModel)
class LmLinearExponentialCorrelationModel : public LmCorrelationModel {
  public:
      LmLinearExponentialCorrelationModel(Size size,Real rho,Real beta,Size factors=Null< Size >());

    Matrix  correlation (Time t, const Array &x=Null<Array>()) const;
    Matrix  pseudoSqrt (Time t, const Array &x=Null<Array>()) const;
	Real correlation(Size i, Size j, Time t, const Array &x)const;
	Size 	factors () const;
    bool isTimeIndependent() const;
};


%shared_ptr(LmLinearExponentialVolatilityModel)
class LmLinearExponentialVolatilityModel : public LmVolatilityModel {
  public:
      LmLinearExponentialVolatilityModel(const std::vector< Time > &fixingTimes, Real a, Real b, Real c, Real d);

    Array  volatility (Time t, const Array &x=Null<Array>()) const ;
	Volatility volatility(Size i, Time t, const Array &x=Null<Array>())const;
    Real integratedVariance(Size i, Size j, Time u, const Array &x=Null< Array >()) const;
};

%shared_ptr(LmExtLinearExponentialVolModel)
class LmExtLinearExponentialVolModel : public LmLinearExponentialVolatilityModel {
  public:
      LmExtLinearExponentialVolModel(const std::vector< Time > &fixingTimes, Real a, Real b, Real c, Real d);

    Array  volatility (Time t, const Array &x=Null<Array>()) const ;
	Volatility volatility(Size i, Time t, const Array &x=Null<Array>())const;
    Real integratedVariance(Size i, Size j, Time u, const Array &x=Null< Array >()) const;
};

%{
using QuantLib::LfmHullWhiteParameterization;
using QuantLib::OptionletVolatilityStructure;
using QuantLib::CapletVarianceCurve;
%}

%shared_ptr(LfmHullWhiteParameterization)
class LfmHullWhiteParameterization : public LfmCovarianceParameterization {
  public:
      LfmHullWhiteParameterization(
				const ext::shared_ptr<LiborForwardModelProcess > &process, 
				const ext::shared_ptr<OptionletVolatilityStructure > &capletVol, 
				const Matrix &correlation=Matrix(), 
				Size factors=1);
      LfmHullWhiteParameterization(
				const ext::shared_ptr<LiborForwardModelProcess> &processPtr, 
				const ext::shared_ptr< CapletVarianceCurve> &capletVolPtr, 
				const Matrix &correlation=Matrix(), 
				Size factors=1);
		
    Matrix  diffusion (Time t, const Array &x=Null< Array >()) const;
    Matrix  covariance (Time t, const Array &x=Null< Array >()) const;
    Matrix  integratedCovariance (Time t, const Array &x=Null< Array >()) const ;
};


%{
using QuantLib::LmFixedVolatilityModel;
%}
%shared_ptr(LmFixedVolatilityModel)
class LmFixedVolatilityModel : public LmVolatilityModel{
  public:
        LmFixedVolatilityModel(const Array& volatilities,
                               const std::vector<Time>& startTimes);

        Array volatility(
             Time t, const Array& x = Null<Array>()) const;
        Volatility volatility(Size i, Time t, const Array& x) const;
};


#endif
