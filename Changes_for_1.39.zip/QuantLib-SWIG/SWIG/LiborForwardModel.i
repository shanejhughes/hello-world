
/*
 Copyright (C) 2014 Matthias Groncki

 This file is part of QuantLib, a free-software/open-source library
 for financial quantitative analysts and developers - http://quantlib.org/

 QuantLib is free software: you can redistribute it and/or modify it
 under the terms of the QuantLib license.  You should have received a
 copy of the license along with this program; if not, please email
 <quantlib-dev@lists.sf.net>. The license is also available online at
 <http://quantlib.org/license.shtml>.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE.  See the license for more details.
*/

#ifndef quantlib_LiborForwardModel_i
#define quantlib_LiborForwardModel_i

%include stochasticprocess.i
%include date.i
%include options.i
%include indexes.i
%include optimizers.i
%include volatilities.i

%{
using QuantLib::CalibratedModel;
using QuantLib::LiborForwardModel; 
using QuantLib::AffineModel; 
%}

/*
%shared_ptr(AffineModel)
class AffineModel : public Observable {
      public:
        //! Implied discount curve
        virtual DiscountFactor discount(Time t) const = 0;

        virtual Real discountBond(Time now,
                                  Time maturity,
                                  Array factors) const = 0;

        virtual Real discountBondOption(Option::Type type,
                                        Real strike,
                                        Time maturity,
                                        Time bondMaturity) const = 0;

        virtual Real discountBondOption(Option::Type type,
                                        Real strike,
                                        Time maturity,
                                        Time bondStart,
                                        Time bondMaturity) const;
};
*/
%shared_ptr(LiborForwardModel)
class LiborForwardModel : public CalibratedModel{//, public AffineModel {
  public:
	LiborForwardModel(
			const ext::shared_ptr<LiborForwardModelProcess> & process,
			const ext::shared_ptr<LmVolatilityModel> & volaModel,
			const ext::shared_ptr<LmCorrelationModel> & corrModel);

	
	Rate S_0( Size alpha,Size beta) const;
	ext::shared_ptr<SwaptionVolatilityMatrix> getSwaptionVolatilityMatrix ();
	
	%extend{
		LiborForwardModel(
			const ext::shared_ptr<LiborForwardModelProcess> &process,
			const ext::shared_ptr<LmLinearExponentialVolatilityModel> &volaModel,
			const ext::shared_ptr<LmExponentialCorrelationModel> &corrModel)
				{
				return 	new LiborForwardModel(
					ext::dynamic_pointer_cast<LiborForwardModelProcess>(process),
					ext::dynamic_pointer_cast<LmVolatilityModel>(volaModel),
					ext::dynamic_pointer_cast<LmCorrelationModel>(corrModel)
					);
				}
				
    
	
	
		LiborForwardModel(
			const ext::shared_ptr<LiborForwardModelProcess> &process,
			const ext::shared_ptr<LmFixedVolatilityModel> &volaModel,
			const ext::shared_ptr<LmExponentialCorrelationModel> &corrModel)
				{
				return 	new LiborForwardModel(
					ext::dynamic_pointer_cast<LiborForwardModelProcess>(process),
					ext::dynamic_pointer_cast<LmVolatilityModel>(volaModel),
					ext::dynamic_pointer_cast<LmCorrelationModel>(corrModel)
					);
				}

		LiborForwardModel(
			const ext::shared_ptr<LiborForwardModelProcess> &process,
			const ext::shared_ptr<LmExtLinearExponentialVolModel> &volaModel,
			const ext::shared_ptr<LmLinearExponentialCorrelationModel> &corrModel)
				{
				return 	new LiborForwardModel(
					ext::dynamic_pointer_cast<LiborForwardModelProcess>(process),
					ext::dynamic_pointer_cast<LmVolatilityModel>(volaModel),
					ext::dynamic_pointer_cast<LmCorrelationModel>(corrModel)
					);
				}

	
	}

};
#endif
