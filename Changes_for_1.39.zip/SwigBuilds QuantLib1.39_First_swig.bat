REM E:
REM %windir%\System32\cmd.exe /k 
cd /d E:\Shane\QuantLib\QuantLib-1.39\QuantLib-SWIG
set PATH=C:\Users\Shane2\Anaconda3;C:\Users\Shane2\Anaconda3\Scripts;C:\Shane\QuantLib\swigwin-4.2.1;E:\Shane\QuantLib\QuantLib-1.39\QuantLib\lib;%PATH%"
set QL_DIR=E:\Shane\QuantLib\QuantLib-1.39\QuantLib
set INCLUDE=C:\local\boost_1_82_0;%INCLUDE%
set LIB=C:\local\boost_1_82_0\lib64-msvc-14.3;%LIB%
echo [build] > setup.cfg && echo compiler=msvc>>setup.cfg
cd Python
swig
REM PAUSE &^
REM python setup.py test &^
REM PAUSE  &^
REM python setup.py install &^
PAUSE
cmd /k