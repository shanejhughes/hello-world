readme_vc.txt - Readme file for gensrc Visual Studio project
http://www.gensrc.org/

Project "gensrc"
================
gensrc is a collection of Python modules and related data.  There is nothing to
compile or execute here and this Visual Studio C++ workspace is provided as a
convenience for viewing the files.  Client applications implement a script
which imports the gensrc modules and invokes them appropriately.  Client
projects use relative pathnames to locate gensrc scripts.

project "docs"
==============
Build this project in order to generate the gensrc documentation.  You must
have the doxygen documentation generation utility installed on your machine.

